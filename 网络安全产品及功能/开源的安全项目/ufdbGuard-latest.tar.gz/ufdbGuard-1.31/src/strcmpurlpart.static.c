/* 
 * strcmpurlpart.static.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2012 by URLfilterDB with all rights reserved.
 *
 * Parts of the ufdbGuard daemon are based on squidGuard.
 * This module is NOT based on squidGuard.
 *
 * $Id: strcmpurlpart.static.c,v 1.6 2012/05/15 02:42:11 root Exp root $
 */

__inline__ static int strcmpURLpart( char * url, char * table )
{
   if (*table != '/')
   {
#if 0
      /* It is never inlined by gcc since there is no constant string */
      return strcmp( url, table );
#else
      /* inlined: return strcmp( url, table ); */
      while (*url != '\0'  &&  (*url - *table) == 0)
      {
         url++;
	 table++;
      }
      return *url - *table;
#endif
   }

   while (*table != '\0')
   {
      if ((*url - *table) != 0)
         return *url - *table;
      url++;
      table++;
   }

   return 0;
}

