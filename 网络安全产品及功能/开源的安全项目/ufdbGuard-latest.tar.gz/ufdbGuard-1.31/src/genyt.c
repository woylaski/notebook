#include <stdio.h>
#include <stdlib.h>

char * genurl( void )
{
   static char url[128] = "^http://www\\.youtube\\.com/watch?v=";
   static char r[] = "1234567890abcdefghijklmnopqrstuvwxyz";
   int i;

   for (i = 0; i < 11; i++)
   {
      url[34 + i] = r[ random() % 36 ];
   }
   url[34+i] = '\0';

   return url;
}


int main( int argc, char * argv[] )
{
    int i;

    for (i = 0; i < 80000; i++)
    {
       puts( genurl() );
    }
    return 0;
}

