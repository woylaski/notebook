
/* the URL must be encoded, so all values must be escaped.
 */
static void encodeURI( char * newURI, char * URI )
{
   int val;
   int hexdigit;
   int endofpathseen = 0;

   while (*URI != '\0')
   {
      if (!endofpathseen)
      {
	 if (*URI == '?'  ||  *URI == '&')
	    endofpathseen = 1;
	 *newURI++ = *URI++;
      }
      else if (*URI == '?'  ||  *URI == '='  ||  *URI == '&'  ||  *URI == ' '  ||  *URI == '"'  || 
	       *URI == '/'  ||  *URI == ':'  ||  *URI == '%'  ||
               *URI == ';'  ||  *URI == '@'  ||  *URI == '+'  ||  *URI == '$'  ||  *URI == ',')
      {
	 val = *URI++;
	 *newURI++ = '%';
	 hexdigit = val / 16;
	 *newURI++ = (hexdigit >= 10) ? hexdigit - 10 + 'A' : hexdigit + '0';
	 hexdigit = val % 16;
	 *newURI++ = (hexdigit >= 10) ? hexdigit - 10 + 'A' : hexdigit + '0';
      }
      else
	 *newURI++ = *URI++;
   }
   *newURI = '\0';
}

