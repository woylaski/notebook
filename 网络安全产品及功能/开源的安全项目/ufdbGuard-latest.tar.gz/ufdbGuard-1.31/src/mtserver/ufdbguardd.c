/* 
 * ufdbguardd.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2015 by URLfilterDB with all rights reserved.
 * 
 * Parts of the ufdbGuard daemon are based on squidGuard.
 *
 * Multithreaded ufdbGuard daemon
 *
 * $Id: ufdbguardd.c,v 1.124 2015/09/16 20:31:04 root Exp root $
 */

#undef UFDB_FREE_MEMORY

#include "ufdb.h"
#include "sg.h"
#include "ufdbdb.h"
#include "ufdbchkport.h"
#include "httpsQueue.h"
#include "httpserver.h"

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <signal.h>
#include <libgen.h>
#include <stdlib.h>
#include <pwd.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/utsname.h>
#ifdef HAVE_SYS_SYSCALL_H
#include <sys/syscall.h>
#endif
#ifdef __linux__
#include <linux/unistd.h>
#endif
#include <sys/socket.h>
#if HAVE_UNIX_SOCKETS
#include <sys/un.h>
#endif
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#ifdef __linux__
#include <execinfo.h>
#endif

#ifdef _POSIX_PRIORITY_SCHEDULING
#include <sched.h>
#endif

#define FULL 1
#define EMPTY 0

pthread_mutex_t sighup_mutex = UFDB_STATIC_MUTEX_INIT;
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
pthread_rwlock_t TheDatabaseLock;
#endif

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
extern pthread_rwlock_t  TheDynamicSourcesLock;
extern pthread_rwlock_t  TheDynamicCategoriesLock;
#else
extern pthread_mutex_t   TheDynamicSourcesLock;
extern pthread_mutex_t   TheDynamicCategoriesLock;
#endif

#define UFDB_MAX_WORKERS	UFDB_MAX_THREADS
static int     n_workers = 65;

static int     my_argc;
static char ** my_argv;
static char ** my_envp;
static char *  configFile = NULL;
static struct timeval  start_time;

static int       badSignal = 0;
static pthread_t badSignalThread;

char * globalPidFile = UFDBGUARDD_PID_FILE;

extern int globalPid;

extern int globalDebugTimeDelta;
extern int sig_other;
extern char ** globalArgv;
extern char ** globalEnvp;

extern int httpsConnectionCacheSize;

static int        portNumCmdLine = -1;

static int        testConfig = 0;
static int        runAsDaemon = 1;
static int        testMode = 0;
static int        parseOnly = 0;
static pthread_t  threadedSignalHandler = (pthread_t) 837;
static pthread_t  housekeeper = (pthread_t) 837;
static pthread_t  sockethandler = (pthread_t) 837;
static pthread_t  dyn_userlist_handler = (pthread_t) 837;
static pthread_t  dyn_domainlist_handler = (pthread_t) 837;
static pthread_t  workers[UFDB_MAX_WORKERS] = { (pthread_t) 837, (pthread_t) 837 };
static pthread_t  httpsthr[UFDB_NUM_HTTPS_VERIFIERS] = { (pthread_t) 837, (pthread_t) 837 };
static pid_t      httpDaemonPid = 0;
static int        allowedToRemovePidFile = 0;
static time_t     lastUpload = 0;

volatile unsigned long UFDBlookupCounter = 0;
volatile unsigned long UFDBlookupHttpsCounter = 0;
volatile unsigned long UFDBblockCounter = 0;
volatile unsigned long UFDBtestBlockCounter = 0;
volatile unsigned long UFDBuncategorisedCounter = 0;
volatile unsigned long UFDBsafesearchCounter = 0;
volatile unsigned long UFDBedufilterCounter = 0;
volatile unsigned long UFDBuploadSeqNo = 0;

static void uploadStatistics( char * reason );
static void * worker_main( void * ptr );
static void * housekeeper_main( void * ptr );
static void * dynamic_userlist_updater_main( void * ptr );
static void * dynamic_domainlist_updater_main( void * ptr );

#define SECSOF8DAYS  (60*60*24*8)
#define SECSOF2DAYS  (60*60*24*2)

#ifdef UFDB_DEBUG
extern int yydebug;
#endif


static void usage( char option )
{
   if (option != '\0')
      fprintf( stderr, "unknown option '-%c'\n", option );

   fprintf( stderr, "usage: ufdbguardd [-A] [-d] [-v] [-r] [-R] [-T] [-h] [-w 32-129] [-p port] [-c <configfile>]\n" );
   fprintf( stderr, "-v      print version\n" );
   fprintf( stderr, "-c FN   use configuration file FN\n" );
   fprintf( stderr, "-T      test mode; do not block, only log which URLs might be blocked\n" );
   fprintf( stderr, "-w N    use N worker threads (default: %d)\n", n_workers );
   fprintf( stderr, "-p N    use TCP port N to listen on\n" );
   fprintf( stderr, "-U user run with privileges of \"user\"\n" );
   fprintf( stderr, "-d      extra debug information in log file\n" );
   fprintf( stderr, "-R      debug RE matching\n" );
   fprintf( stderr, "-r      log all redirections\n" );
   fprintf( stderr, "-N      do not analyse uncategorised URLs (not recommended)\n" );
   fprintf( stderr, "-h      print this help text\n" );
   fprintf( stderr, "-C verify  verify a configuration file; must be the last option\n" );

   if (option != '\0')
      exit( 1 );
   else
      exit( 0 );
}


static void writePidFile( void )
{
   FILE * fp;
   struct stat dir;

   UFDBraisePrivileges( UFDBglobalUserName, "write pid file" );

   if (stat( DEFAULT_PIDDIR, &dir ) != 0)
   {
      ufdbLogMessage( "directory %s does not exist. creating it...", DEFAULT_PIDDIR );
      if (mkdir( DEFAULT_PIDDIR, S_IRUSR|S_IWUSR|S_IXUSR |S_IRGRP|S_IXGRP |S_IROTH|S_IXOTH ) != 0)
      {
         ufdbLogError( "cannot create %s: %s", DEFAULT_PIDDIR, strerror(errno) );
	 return;
      }

      if (UFDBglobalUserName[0] != '\0')
      {
	 struct passwd * user;
	 user = getpwnam( UFDBglobalUserName );
	 if (user == NULL)
	    ufdbLogError( "WHOEHA: user \"%s\" does not exist.  cannot change ownership of %s", 
			  UFDBglobalUserName, DEFAULT_PIDDIR );
	 else
	 {
	    if (chown( DEFAULT_PIDDIR, user->pw_uid, user->pw_gid ) != 0)
	       ufdbLogError( "cannot change ownership of %s: %s", DEFAULT_PIDDIR, strerror(errno) );
	    if (chmod( DEFAULT_PIDDIR, S_IRUSR|S_IWUSR|S_IXUSR |S_IRGRP|S_IXGRP |S_IROTH|S_IXOTH ) != 0)
	       ufdbLogError( "cannot change mode of %s: %s", DEFAULT_PIDDIR, strerror(errno) );
	 }
      }
   }

   (void) unlink( globalPidFile );
   UFDBdropPrivileges( UFDBglobalUserName );

   fp = fopen( globalPidFile, "w" );
   if (fp == NULL)
      ufdbLogError( "cannot write to PID file %s: %s", globalPidFile, strerror(errno) );
   else
   {
      fprintf( fp, "%d\n", globalPid );
      fclose( fp );
      ufdbLogMessage( "PID %d written to %s", globalPid, globalPidFile );
      allowedToRemovePidFile = 1;
   }
}


static void removePidFile( void )
{
   FILE * fp;
#if HAVE_UNIX_SOCKETS
   char   unixsocket[64];
#endif

   if (UFDBglobalDebug)
      ufdbLogMessage( "removing pid file  allowed=%d", allowedToRemovePidFile );

   /* When the initialisation of the socket failed there is most likely
    * already an ufdbguardd daemon running and we may not remove
    * the pid file nor kill any ufdbhttpd daemon.
    */
   if (!allowedToRemovePidFile)
      return;

#if HAVE_UNIX_SOCKETS
   sprintf( unixsocket, "/tmp/ufdbguardd-%05d", UFDBglobalPortNum );
   if (unlink( unixsocket ) < 0  &&  errno != ENOENT)
      ufdbLogError( "cannot remove socket %s: %s", unixsocket, strerror(errno) );
#endif

   (void) unlink( globalPidFile );

   allowedToRemovePidFile = 0;

   if (UFDBglobalHttpdPort > 0)
   {
      UFDBraisePrivileges( UFDBglobalUserName, "kill ufdbhttpd" );
      fp = fopen( UFDBHTTPD_PID_FILE, "r" );
      if (fp != NULL)
      {
         if (fscanf( fp, "%d", &httpDaemonPid ) == 1)
	 {
	    ufdbLogMessage( "sending TERM signal to the HTTP daemon (pid=%d)", httpDaemonPid );
	    if (kill( httpDaemonPid, SIGTERM ) < 0)
	       ufdbLogError( "cannot kill pid %d: %s", httpDaemonPid, strerror(errno) );
	    /* TODO: find out why ufdbhttpd does not act on the TERM signal... */
	    usleep( 210000 );
	    (void) kill( httpDaemonPid, SIGKILL );
	 }
         fclose( fp );
      }
      UFDBdropPrivileges( UFDBglobalUserName );
   }
}


static void logStatistics( void )
{
   struct Acl *         acl;
   struct Category *    cat;
   struct AclCategory * aclcat;
   struct Source *      src;
   char *               logmsg;
   char                 nbuf[16];

   logmsg = (char *) ufdbMalloc( 256 * 1024 );

   ufdbLogMessage( "statistics: %lu URL lookups (%lu https). %lu URLs blocked. "
		   "%lu tunnels detected. %lu safe searches. %lu Youtube edufilter. %lu uncategorised URLs. %lu clients.",
		   UFDBlookupCounter, 
		   UFDBlookupHttpsCounter,
		   UFDBblockCounter + UFDBtestBlockCounter,
		   UFDBglobalTunnelCounter,
		   UFDBsafesearchCounter,
		   UFDBedufilterCounter,
		   UFDBuncategorisedCounter,
		   UFDBgetNumberOfRegisteredIPs() );

   for (cat = Cat;  cat != NULL;  cat = cat->next)
   {
      ufdbLogMessage( "statistics: category %s was blocked %lu times", cat->name, cat->nblocks );
   }

   for (src = UFDBgetSourceList();  src != NULL;  src = src->next)
   {
      ufdbLogMessage( "statistics: source %s was blocked %lu times", src->name, src->nblocks );
   }

   for (acl = AclList;  acl != NULL;  acl = acl->next)
   {
      char aclname[64];

      if (acl->pass == NULL)
	 continue;

      if (acl->within == UFDB_ACL_ELSE)
         sprintf( aclname, "%s-else", acl->name );
      else if (acl->within == UFDB_ACL_WITHIN)
         sprintf( aclname, "%s-within-%s", acl->name, acl->time->name );
      else if (acl->within == UFDB_ACL_OUTSIDE)
         sprintf( aclname, "%s-outside-%s", acl->name, acl->time->name );
      else
         strcpy( aclname, acl->name );

      logmsg[0] = '\0';
      strcat( logmsg, "acl " );
      strcat( logmsg, aclname );
      strcat( logmsg, ": " );

      for (aclcat = acl->pass;  aclcat != NULL;  aclcat = aclcat->next)
      {
	 switch (aclcat->type)
	 {
	    case ACL_TYPE_TERMINATOR:
	       if (aclcat->access)
		  strcat( logmsg, " all" );
	       else
		  strcat( logmsg, " none" );
	       break;
	    case ACL_TYPE_DEFAULT:
	       strcat( logmsg, " " );
	       if (!aclcat->access)
		  strcat( logmsg, "!" );
	       strcat( logmsg, aclcat->name );
	       break;
	    case ACL_TYPE_INADDR:
	       strcat( logmsg, " in-addr" );
	       break;
	 }
	 strcat( logmsg, ":" );
	 sprintf( nbuf, "%lu", aclcat->nblocks );
	 strcat( logmsg, nbuf );
      }
      ufdbLogMessage( "statistics: %s", logmsg );
   }

   ufdbFree( logmsg );
}


static void startHttpDaemon( void )
{
   int    i;
   char * argv[24];
   struct stat statbuf;
   char   portStr[16];
   char   httpdbin[1024];

   if (UFDBglobalDebug || UFDBglobalDebugHttpd)
      ufdbLogMessage( "going to start ufdbhttpd" );

   sprintf( httpdbin, "%s/%s", DEFAULT_BINDIR, "ufdbhttpd" );
   if (stat( httpdbin, &statbuf ) < 0)
   {
      ufdbLogError( "cannot find the HTTP daemon executable (%s): %s  *****", httpdbin, strerror(errno) );
      return;
   }

   /* go back to user root to allow ufdbhttpd to use privileged ports */
   UFDBraisePrivileges( UFDBglobalUserName, "start ufdbhttpd" );

   httpDaemonPid = fork();
   if (httpDaemonPid == 0)	/* child */
   {
      UFDBcloseFilesNoLog();
      i = 0;
      argv[i++] = httpdbin;
      if (UFDBglobalDebug || UFDBglobalDebugHttpd)
         argv[i++] = "-d";
      argv[i++] = "-p";
      sprintf( portStr, "%d", UFDBglobalHttpdPort );
      argv[i++] = portStr;
      argv[i++] = "-l";
      if (UFDBglobalLogDir == NULL)
	 argv[i++] = DEFAULT_LOGDIR;
      else
	 argv[i++] = UFDBglobalLogDir;
      argv[i++] = "-I";
      if (UFDBglobalHttpdImagesDirectory[0] == '\0')
	 strcpy( UFDBglobalHttpdImagesDirectory, DEFAULT_IMAGESDIR );
      argv[i++] = UFDBglobalHttpdImagesDirectory;
      argv[i++] = "-i";
      argv[i++] = UFDBglobalHttpdInterface;
      if (UFDBglobalUserName[0] != '\0')
      {
	 argv[i++] = "-U";
	 argv[i++] = UFDBglobalUserName;
      }
      argv[i] = NULL;
      ufdbLogMessage( "starting HTTP daemon ..." );
      execv( httpdbin, argv );
      ufdbLogError( "failed starting http daemon: execv failed: %s", strerror(errno) );
      _exit( 2 );
   }

   UFDBdropPrivileges( UFDBglobalUserName );

   if (httpDaemonPid < 0)
   {
      ufdbLogError( "cannot start HTTP daemon: fork failed: %s", strerror(errno) );
      httpDaemonPid = 0;
   }
   else
   {
#if 0
      int        status;
      pid_t      pid;
#endif

      ufdbLogMessage( "ufdbhttpd is started.  port=%d interface=%s images=%s",
                      UFDBglobalHttpdPort, UFDBglobalHttpdInterface, UFDBglobalHttpdImagesDirectory );
#if 0
      usleep( 300000 );
      while ((pid = waitpid( -1, &status, WNOHANG )) > 0)
	 ;
#endif
   }
}


static void adjustNumberOfWorkerThreads( void )
{
   int              i;
   pthread_attr_t   attr;

   /* IF the check_https_tunnel_option is aggressive we need more worker threads */
   /* Note that UFDB_MAX_THREADS is 140 so with the -w option we can have 140 worker threads */
   if (UFDBgetTunnelCheckMethod() == UFDB_API_HTTPS_CHECK_AGGRESSIVE  &&  n_workers < UFDB_MAX_THREADS)
   {
      if (UFDBglobalDebug)
	 ufdbLogMessage( "adjusting #worker threads: starting %d threads", UFDB_MAX_THREADS - n_workers );

      /* create more worker threads */
      pthread_attr_init( &attr );
      pthread_attr_setscope( &attr, PTHREAD_SCOPE_SYSTEM );
      pthread_attr_setstacksize( &attr, 252 * 1024 );
#if HAVE_PTHREAD_ATTR_SETGUARDSIZE && UFDB_DEBUG
      pthread_attr_setguardsize( &attr, 8 * 1024 );
#endif
      for (i = n_workers; i < UFDB_MAX_THREADS; i++)
      {
	 pthread_create( &workers[i], &attr, worker_main, (void *) ((long) i) );
#ifdef _POSIX_PRIORITY_SCHEDULING
	 sched_yield();
#else
	 usleep( 10000 );
#endif
      }
      n_workers = UFDB_MAX_THREADS;
      ufdbLogMessage( "#threads is increased to %d because check-proxy-tunnels is set to \"aggressive\"", n_workers );
   }
}


static void Usr1SignalCaught( int sig )
{
   FILE * fp;
   int    oldStatus;

   ufdbLogMessage( "USR1 signal received for logfile rotation" );
   oldStatus = UFDBchangeStatus( UFDB_API_STATUS_ROLLING_LOGFILE );
   UFDBrotateLogfile();
   if (UFDBglobalHttpdPort > 0)
   {
      fp = fopen( UFDBHTTPD_PID_FILE, "r" );
      if (fp != NULL)
      {
	 if (1 != fscanf( fp, "%d", &httpDaemonPid ))
	    httpDaemonPid = -1;
	 fclose( fp );
      }
      else
	 httpDaemonPid = -1;

      if (httpDaemonPid > 0)
      {
	 int retval;

	 ufdbLogMessage( "sending USR1 signal to ufdbhttpd (pid=%d)", httpDaemonPid );
	 /* TODO: use setreuid() */
	 retval = kill( httpDaemonPid, SIGUSR1 );
	 if (retval != 0)
	    ufdbLogError( "cannot send USR1 signal to httpd daemon: %s", strerror( errno ) );
      }
   }
   ufdbLogMessage( "USR1 signal received for logfile rotation" );
   UFDBchangeStatus( oldStatus );
}


static void Usr2SignalCaught( int sig )
{
   int    oldStatus;

   ufdbLogMessage( "USR2 signal received to trigger monitoring commands" );
   oldStatus = UFDBchangeStatus( UFDB_API_STATUS_UPDATE );
   UFDBchangeStatus( oldStatus );
   ufdbLogMessage( "status update done" );
}


/*
 * OpenBSD is very picky with its implementation of signals and
 * does not allow violation of the POSIX standard that says that
 * a signal handler may NOT raise a signal, so calling pthread_kill
 * is not allowed.  
 * The signal handlers below do nothing.  They are installed to
 * tell the OS to send the signals to the process and the special
 * signal interception threads will handle the signals asynchroneously.
 *
 * These signal handlers can do nothing, not even call 
 * ufdbLogMessage because it uses a mutex.
 */
static void catchHUPSignal( int signal )
{
}


static void catchUSR1Signal( int signal )
{
}


static void catchUSR2Signal( int signal )
{
}


static void catchChildSignal( int signal )
{
   /* For some reason, on OpenBSD the SIGCHLD does not get through
    * to the signal_handler_thread() so we must do a waitpid() here.
    */
#if defined(__OpenBSD__) || defined(__NetBSD__)  || defined(__FreeBSD__)
   int        status;
   pid_t      pid;

   while ((pid = waitpid( -1, &status, WNOHANG )) > 0)
      ;
#endif
}


void catchTermSignal( int signum )
{
   /* do nothing. sigwait() in a thread will deal with the signal */
}


static void TermSignalCaught( int signum )
{
   UFDBglobalTerminating = 1;
   UFDBglobalReconfig = 1;
   (void) alarm( 0 );

   ufdbLogMessage( "received %s signal", signum == SIGINT ? "INT" : "TERM" );
   uploadStatistics( signum == SIGINT ? "INT" : "TERM" );

   UFDBchangeStatus( UFDB_API_STATUS_TERMINATED );

   usleep( 100000 );
   pthread_cancel( sockethandler );

   /* we are inside the signal_handler_thread and prefer that the main thread does all the cleanup */
   /* do 8 short sleeps instead of one large sleep since a few of them will be interrupted by signals */
   sleep( 1 );		
   sleep( 1 );	
   sleep( 1 );	
   sleep( 1 );	
   sleep( 1 );	
   sleep( 1 );	
   sleep( 1 );	
   sleep( 1 );	

   /* close all connections with clients */
   UFDBcloseFilesNoLog();

   removePidFile();
   ufdbLogMessage( "TermSignalCaught: bye bye" );
   _exit( 0 );
}


static char * my_fast_fgets_nonl( char * s, int size, FILE * stream )
{
   char * buf;
   int    ch;

   buf = s;
   while ((ch = getc_unlocked(stream)) != EOF  &&  --size > 0)
   {
      if (ch == '\n'  ||  ch == '\r')
         break;
      *buf++ = ch;
   }
   *buf = '\0';
   if (ch == EOF  &&  buf == s)
      return NULL;
   return s;
}


void interruptPstack( int dummy )
{
   ufdbLogError( "waited too long for output of pstack.... aborting now!" );
   UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
   _exit( 5 );
}


void BadSignalCaught( int signum )	
{
   int       i;
   int       num;
   char      me[48];
   
   /* We desperately want a crash report and repeating signals prevent this so ignore the bad signal */
   ufdbSetSignalHandler( signum, SIG_IGN );

   /* find out which thread has a signal */
   sprintf( me, "pid %d", (int) getpid() );
   if (badSignalThread == threadedSignalHandler)
   {
      strcpy( me, "thread signal-handler" );
   }
   else if (badSignalThread == housekeeper)
   {
      strcpy( me, "thread housekeeper" );
   }
   else if (badSignalThread == sockethandler)
   {
      strcpy( me, "thread socket-handler" );
   }
   else if (badSignalThread == dyn_userlist_handler)
   {
      strcpy( me, "thread dynamic-userlist-handler" );
   }
   else if (badSignalThread == dyn_domainlist_handler)
   {
      strcpy( me, "thread dynamic-domainlist-handler" );
   }
   else 
   {
      num = UFDB_NUM_HTTPS_VERIFIERS;
      for (i = 0; i < num; i++)
         if (badSignalThread == httpsthr[i])
	 {
	    sprintf( me, "thread https-verifier-%02d", i );
	    break;
	 }
      num = n_workers;
      for (i = 0; i < num; i++)
         if (badSignalThread == workers[i])
	 {
	    sprintf( me, "thread worker-%02d", i );
	    break;
	 }
   }
   ufdbLogMessage( "%s caught signal %d.", me, signum );

#if 0
   /* let workers finish their jobs */
   /* NO! we want a stack dump asap to see what they are doing */
   usleep( 500000 );
#endif

   {
      FILE * fp;
      char   cmd[512];
      char   buffer[2048];

      ufdbSetSignalHandler( SIGALRM, interruptPstack );
      alarm( 9 );

      sprintf( cmd, DEFAULT_BINDIR "/ufdb-pstack %d 2>&1", getpid() );

      /* gdb sometimes needs root permissions, so the popen() is done as root */
      UFDBraisePrivileges( UFDBglobalUserName, "open pipe for ufdb-pstack" );
      errno = 0;
      fp = popen( cmd, "r" );
      if (fp == NULL)
         ufdbLogError( "could not open pipe and execute \"%s\": %s", cmd, strerror(errno) );

      while (my_fast_fgets_nonl( buffer, 2040, fp ) != NULL)
      {
         ufdbLogMessage( "pstack  %s", buffer );
      }
      pclose( fp );
      ufdbLogMessage( "pstack  END" );
      UFDBdropPrivileges( UFDBglobalUserName );
   }

   UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
   /* 
    * ufdbguardd is a multithreaded application and other threads may also 
    * call UFDBchangeStatus() ...  We have seen the status being changed 
    * to ERROR and immediately followed by another status change to RELOADED.
    * To try to make it more robust we do a short sleep and set the status again.
    */
   usleep( 500000 );
   UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );

#if 0
   if (UFDBglobalDebug)
      ufdbLogMessage( "BadSignalCaught: going to kill socket-handler..." );
   pthread_cancel( sockethandler );

   /* We prefer that the main thread does all the cleanup. */
   /* So we do 8 short sleeps instead of one large sleep since a few of them will be interrupted by signals. */
   sleep( 2 );		
   sleep( 2 );	
   sleep( 2 );	
   sleep( 2 );	
   sleep( 2 );	
   sleep( 2 );	
   sleep( 2 );	
   sleep( 2 );	
   /* all threads including myself should be dead now */

   ufdbLogMessage( "BadSignalCaught: ufdbguardd aborts" );
   UFDBchangeStatus( UFDB_API_STATUS_TERMINATED );

   removePidFile();
   kill( globalPid, SIGABRT );

   sleep( 2 );
   exit( 2 );
#endif
}


void catchAbortSignal( int signum )
{
   UFDBglobalReconfig = 1;
   UFDBglobalTerminating = 1;
   (void) alarm( 0 );

   ufdbLogMessage( "ABORT signal was sent. exiting..." );
   BadSignalCaught( SIGABRT );

   removePidFile();
   UFDBchangeStatus( UFDB_API_STATUS_TERMINATED );
   exit( 3 );
}


static void crasher( void )
{
   BadSignalCaught( SIGABRT );
   sleep( 1 );
   exit( 9 );
}


void __fortify_fail( const char * msg )
{
   UFDBglobalReconfig = 1;
   UFDBglobalTerminating = 1;
   (void) alarm( 0 );

   ufdbLogMessage( "fortified code failed: %s.  simulating bad signal to call ufdb-pstack...", msg );

   badSignalThread = pthread_self();
   BadSignalCaught( SIGQUIT );
   _exit( 4 );
}


void __assert_fail( const char * assertion, const char * file, unsigned int line, const char * function )
{
   UFDBglobalReconfig = 1;
   UFDBglobalTerminating = 1;
   (void) alarm( 0 );

   ufdbLogMessage( "libc assertion failure: %s line %d: in function %s: %s", file, line, function, assertion );

   badSignalThread = pthread_self();
   BadSignalCaught( SIGQUIT );
   _exit( 4 );
}


void ufdbCatchBadSignal( int signum )	
{
   /* Note that we are inside a signal handler and can do almost nothing. */

   if (badSignal != signum)
   {
      UFDBglobalReconfig = 1;
      UFDBglobalTerminating = 1;
      (void) alarm( 0 );

      ufdbLogMessage( "ufdbCatchBadSignal: received signal %d", signum );

      badSignal = signum;
      badSignalThread = pthread_self();

      /* Cancel the sockethandler thread so that the main thread will wake up and 
       * wind up.
       * But sleep first so that ufdb-pstack can do its job in an other thread.
       */
      sleep( 1 );
      sleep( 1 );
      pthread_cancel( sockethandler );

      /* If for any reason the termination by main fails, we have to call exit() ourselves. */
      sleep( 2 );
      sleep( 2 );
      sleep( 2 );
      sleep( 2 );
      sleep( 2 );
      ufdbLogError( "ufdbCatchBadSignal: calling exit() after waiting for 10 seconds for main to terminate ufdbguardd" );
      exit( 10 );
   }
}


static void HupSignalCaught( int sig )
{
   time_t          t;
   struct tm       thetime;
   int             status;
   pid_t           pid;
   FILE *          fp;
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   int             ret;
   struct timespec DatabaseLockTimeout;
#else
   unsigned int    sleep_period;
#endif

   if (pthread_mutex_trylock( &sighup_mutex ) != 0)
   {
      ufdbLogMessage( "HUP signal is already being processed" );
      return;
   }

   /* going to reload the configuration but first wait for others to finish */
   while (UFDBglobalReconfig)
      usleep( 100000 );

   UFDBglobalReconfig = 1;
   alarm( 0 );

   ufdbLogMessage( "HUP signal received to reload the configuration and database" );
   UFDBchangeStatus( UFDB_API_STATUS_RELOADING );

   uploadStatistics( "HUP" );

   /* To prevent counting 'old' clients: 
    * if today is Wednesday, we reset the IP counters.
    * If reset was more than 8 days ago, we also do a reset now.
    */
   t = time( NULL );
   if (lastUpload != 0  &&  t - lastUpload > SECSOF8DAYS)
      UFDBinitializeIPcounters();
   else
   {
      localtime_r( &t, &thetime );
      if (thetime.tm_wday == 3)
      {
	 UFDBinitializeIPcounters();
      }
   }

   /* Get the pid of the HTTP daemon. It is used later to kill it. */
   httpDaemonPid = -1;
   if (UFDBglobalHttpdPort > 0)
   {
      fp = fopen( UFDBHTTPD_PID_FILE, "r" );
      if (fp != NULL)
      {
	 if (1 != fscanf( fp, "%d", &httpDaemonPid ))
	 {
	    ufdbLogError( "file %s does not have a process id", UFDBHTTPD_PID_FILE );
	    httpDaemonPid = -1;
	 }
	 fclose( fp );
      }
      else
      {
	 ufdbLogError( "cannot open file %s: %s", UFDBHTTPD_PID_FILE, strerror(errno) );
      }
   }

   sleep( 1 );
   sleep( 1 );

   if (UFDBgetTunnelCheckMethod() == UFDB_API_HTTPS_CHECK_AGGRESSIVE)
   {
      /* when using aggressive HTTPS port probing, we need to wait patiently for workers to release the read lock */
      sleep( 1 );
      sleep( 1 );
      sleep( 1 );
   }

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   /* 
    * Synchronise with all worker threads.
    * UFDBglobalReconfig is set for the last 2 seconds so the worker threads have 
    * most likely no read-locks any more.  Try to get a write lock within 0.1 second
    * and if this fails, we will sleep 5 seconds more and acquire the rwlock with
    * pthread_rwlock_wrlock().
    *
    * We use a 0.2-second timeout since we do not want to block readers (workers)
    * too long because the flow of messages back to Squid may not be interrupted too long.
    * Note: 1,000,000,000 nanoseconds make 1 second.
    */
   ufdbLogMessage( "requesting a write lock for the in-memory database (fast mode)..." );

   DatabaseLockTimeout.tv_sec = 0;
   DatabaseLockTimeout.tv_nsec = 200000000;
   ret = pthread_rwlock_timedwrlock( &TheDatabaseLock, &DatabaseLockTimeout );
   if (ret == 0)
      ufdbLogMessage( "lock acquired to reload the URL database" );
   else
   {
      if (ret == ETIMEDOUT  ||  ret == EBUSY)
      {
	 ufdbLogMessage( "Could not obtain a lock quickly to refresh the URL database\n"
	                 "sleeping 5 seconds before attempting to acquire the lock again  *****" );
	 sleep( 1 );
	 sleep( 1 );
	 sleep( 1 );
	 sleep( 1 );
	 sleep( 1 );
	 sleep( 1 );
      }
      else 
	 ufdbLogError( "pthread_rwlock_timedwrlock failed with code %d", ret );

      ufdbLogMessage( "requesting a write lock for the in-memory database (slow mode)..." );

      /* 
       * Wait many seconds for a write lock ...
       * THIS *MAY* DISTURB USERS since Squid may not be getting answers back from some workers.
       * Also ufdbgclient will time out and that may be considered a good thing since it will
       * send a response back to Squid.
       */
      DatabaseLockTimeout.tv_sec = 30;
      DatabaseLockTimeout.tv_nsec = 0;
      ret = pthread_rwlock_timedwrlock( &TheDatabaseLock, &DatabaseLockTimeout );
      if (ret == 0)
	 ufdbLogMessage( "lock acquired to reload the URL database" );
      else
      {
	 if (ret == ETIMEDOUT  ||  ret == EBUSY)
	    ufdbLogError( "HUP signal received but could not acquire a lock on the configuration  *****\n"
	                  "Most likely a dynamic refresh is taking too long or hangs (check all commands used by execuserlist and execdomainlist) *****\n"
			  "Also verify that the system load is normal\n"
			  "Request support from the Support Desk of www.urlfilterdb.com is case there are any doubts." );
	 else
	    ufdbLogError( "pthread_rwlock_wrlock failed with code %d", ret );
	 /*
	  * I am in trouble.  The lock failed, so fallback to the old method of sleeping many seconds.
	  */
	 ufdbLogMessage( "sleeping 45 seconds because I could not get a lock" );
	 sleep( 45 );
      }
   }

   /* We must unlock the lock ASAP since the worker threads must continue handling requests.
    * The workers are now synchronised and all know that UFDBglobalReconfig is set.
    */
   if (ret == 0)
   {
      ufdbLogMessage( "releasing the lock so that the synchronised worker threads can continue" );
      (void) pthread_rwlock_unlock( &TheDatabaseLock );
   }

#else
   /* sleep() is a very crude way to allow worker threads to finish what
    * they were doing, before we remove the database from memory,
    * but it allows us not to use mutexes for a many-reader-one-writer problem.
    */
   sleep_period = n_workers / 2;
   if (sleep_period < 12)
      sleep_period = 12;
   if (sleep_period > 20)
      sleep_period = 20;
   sleep_period -= 3+1+1;		/* we already slept a few seconds */
   if (UFDBgetTunnelCheckMethod() == UFDB_API_HTTPS_CHECK_AGGRESSIVE)
      sleep_period += 15;
   ufdbLogMessage( "sleeping %d seconds to allow worker threads to finish current work", 
		   sleep_period );
   sleep( sleep_period );		
#endif

   /* TODO: reload CA certificates and use TheDatabaseLock */
   /* TODO: clear security cache */

   ufdbLogMessage( "releasing URL database from memory ..." );
   ufdbFreeAllMemory();
   ufdbLogMessage( "reading configuration file and database ..." );
   UFDBglobalFatalError = 0;
   UFDBglobalHttpdPort = 0;
   if (sgReadConfig( configFile ) == 0)
   {
      ufdbLogFatalError( "exiting due to missing configuration file" );
      exit( 3 );
   }
   if (UFDBglobalTerminating)
   {
      ufdbLogMessage( "a fatal error occurred and ufdbguardd is terminating  *****" );
      return;
   }
   if (UFDBglobalFatalError)
   {
      ufdbLogMessage( "A FATAL ERROR OCCURRED: all requests are answered with \"OK\" (see previous lines for more details)  *****" );
   }

   /* TODO: only stop/start ufdbhttpd if the parameters have changed */
   if (httpDaemonPid > 0)
   {
      int retval;

      /* TODO: call setreuid() */
      ufdbLogMessage( "killing old ufdbhttpd (pid=%d)", httpDaemonPid );
      retval = kill( httpDaemonPid, SIGTERM );
      if (retval != 0)
	 ufdbLogError( "cannot send TERM signal to the HTTP daemon (pid=%d): %s", 
		       httpDaemonPid, strerror( errno ) );

      usleep( 400000 );
      /* be sure that the daemon is killed. */
      if (kill( httpDaemonPid, SIGKILL ) == 0)
	 usleep( 100000 );

      while ((pid = waitpid( -1, &status, WNOHANG )) > 0)
	 ;

      if (kill( httpDaemonPid, 0 ) < 0)
	 ufdbLogMessage( "HTTP daemon (pid=%d) terminated to be restarted (OK)", httpDaemonPid );
      else
	 ufdbLogError( "HTTP daemon did not terminate: %s", strerror(errno) );
   }

   if (UFDBglobalHttpdPort > 0)
      startHttpDaemon();

   UFDBlogConfig();

   adjustNumberOfWorkerThreads();

   UFDBlookupCounter = 0;
   UFDBlookupHttpsCounter = 0;
   UFDBblockCounter = 0;
   UFDBtestBlockCounter = 0;
   UFDBuncategorisedCounter = 0;
   UFDBglobalTunnelCounter = 0;
   UFDBsafesearchCounter = 0;
   UFDBedufilterCounter = 0;
   UFDBuploadSeqNo++;

   if (UFDBglobalFatalError)
   {
      UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
   }
   else
   {
      UFDBchangeStatus( UFDB_API_STATUS_RELOAD_OK );
   }

#if 0
   /* delay resetting UFDBglobalReconfig to let the workers finish their loops */
   usleep( 100000 );
#endif 

   ufdbHandleAlarmForTimeEvents( UFDB_PARAM_INIT );
   if (UFDBglobalFatalError)
      ufdbLogMessage( "A FATAL ERROR OCCURRED: all requests are answered with \"OK\" (see previous lines for more details)  *****" );
   else
      ufdbLogMessage( "the new configuration and database are loaded for ufdbguardd " VERSION );

   UFDBglobalReconfig = 0;

   pthread_mutex_unlock( &sighup_mutex );

   pthread_kill( dyn_userlist_handler, SIGHUP );
   pthread_kill( dyn_domainlist_handler, SIGHUP );
}


/* 
 * Communication between the worker and other threads is done via
 * RW-locks and data is passed via a queue.
 *
 * Since this queue is a FIFO we could use a tail queue. But we don't
 * like the malloc() overhead, so therefore we use a static array.
 */

#define UFDB_MAX_FD_QUEUE   UFDB_MAX_THREADS


static struct {
   int    fd;
} q[UFDB_MAX_FD_QUEUE];

volatile static int    ihead = 0;                    /* array index for the head */
volatile static int    itail = 0;                    /* array index for the tail */
volatile static int    n_queued = 0;
static pthread_mutex_t fdq_lock = UFDB_STATIC_MUTEX_INIT;
static pthread_cond_t  empty = PTHREAD_COND_INITIALIZER;


/*
 * enqueue a new fd.
 */
static void putFdQueue( int fd )
{
   int ret;

   ret = pthread_mutex_lock( &fdq_lock );
   if (ret != 0)
#ifdef UFDB_DEBUG
      ufdbLogError( "putFdQueue: mutex_lock failed with code %d *****", ret );
#else
      ;
#endif

   if (n_queued < UFDB_MAX_FD_QUEUE)
   {
      /*
       * insert it at the tail
       */
      q[itail].fd = fd;

      itail = (itail + 1) % UFDB_MAX_FD_QUEUE;
      n_queued++;

      /*
       * leave the critical section
       */
      ret = pthread_mutex_unlock( &fdq_lock );
#ifdef UFDB_DEBUG
      if (ret != 0)
	 ufdbLogError( "putFdQueue: mutex_unlock failed with code %d *****", ret );
#endif

      /*
       * signal anyone who is waiting
       */
      pthread_cond_broadcast( &empty );
   } 
   else    
   {
      ufdbLogFatalError( "connection queue is full.  *****\n"
                         "There are too many ufdbgclient processes !!\n"
                         "the maximum is %d when the -w option is used\n"
      			 "closing fd %d", 
			 UFDB_MAX_FD_QUEUE, fd );
      /* there is no other option than to close the connection */
      /* TO-DO: maybe: close all queued fd's ? */
      close( fd );

      /*
       * leave the critical section
       */
      ret = pthread_mutex_unlock( &fdq_lock );
#ifdef UFDB_DEBUG
      if (ret != 0)
	 ufdbLogError( "putFdQueue: mutex_unlock failed with code %d *****", ret );
#endif
   }
}


/*
 * get a fd where there is new content.
 */
static void getFdQueue( int * fd )
{
   int ret;

allover:
   ret = pthread_mutex_lock( &fdq_lock );
   if (ret != 0)
#ifdef UFDB_DEBUG
      ufdbLogError( "getFdQueue: mutex_lock failed with code %d *****", ret );
#else
      ;
#endif

   while (1)
   {
      /*
       * if there are jobs in the queue
       */
      if (n_queued > 0)
      {
         n_queued--;
         /*
          * get the one at the head
          */
         *fd = q[ihead].fd;
         ihead = (ihead + 1) % UFDB_MAX_FD_QUEUE;

         ret = pthread_mutex_unlock( &fdq_lock );
#ifdef UFDB_DEBUG
	 if (ret != 0)
	    ufdbLogError( "getFdQueue: mutex_unlock failed with code %d *****", ret );
#endif

	 return;
      } 
      else   /* otherwise wait until there are fds available */ 
      {
         pthread_cond_wait( &empty, &fdq_lock );
         /*
          * when I'm here, I've been signaled because there
          * are jobs in the queue.  Go try and get one.
          */
	 ret = pthread_mutex_unlock( &fdq_lock );
#ifdef UFDB_DEBUG
	 if (ret != 0)
	    ufdbLogError( "getFdQueue: mutex_unlock failed with code %d *****", ret );
#endif
	 usleep( ((unsigned long) pthread_self()) % 821 );
	 goto allover;
      }
   }
}


static void daemon_accept_connections( 
   int            s, 
   int            protocol )
{
   int            n;
   int            newfd;
   fd_set         fds;
   struct timeval tv;

   /*
    * Allow that this thread can be cancelled without delays at any time.
    */
   pthread_setcancelstate( PTHREAD_CANCEL_ENABLE, NULL );
   pthread_setcanceltype( PTHREAD_CANCEL_ASYNCHRONOUS, NULL );

   while (!UFDBglobalTerminating)
   {
      FD_ZERO( &fds );
      FD_SET( s, &fds );
      errno = 0;
      n = select( s+1, &fds, (fd_set *) NULL, (fd_set *) NULL, (struct timeval *) NULL );

      if (UFDBglobalTerminating)
	 break;

      if (n > 0) 
      {
	 newfd = accept( s, NULL, NULL );
	 if (newfd < 0)
	 {
	    if (errno == EINTR)
	    {
	       continue;
	    }
	    ufdbLogError( "SRV: accept on socket failed: %s", strerror(errno) );
	    return;
	 }

	 if (protocol == AF_INET)
	 {
	    int sock_parm;

	    sock_parm = 1;
	    setsockopt( newfd, IPPROTO_TCP, TCP_NODELAY, (void *) &sock_parm, sizeof(sock_parm) );
	    sock_parm = 1;
	    setsockopt( newfd, SOL_SOCKET, SO_KEEPALIVE, (void *) &sock_parm, sizeof(sock_parm) );
	    sock_parm = 65536;
	    setsockopt( newfd, SOL_SOCKET, SO_SNDBUF, (void *) &sock_parm, sizeof(sock_parm) );
	    sock_parm = 65536;
	    setsockopt( newfd, SOL_SOCKET, SO_RCVBUF, (void *) &sock_parm, sizeof(sock_parm) );
	 }

	 /*
	  *  In case of troubles, the timeout prevents that a thread will block for ever.
	  */
#if 0
	 tv.tv_sec = 16 * 60;		/* we need unlimited read timeout since we simply wait for input */
	 tv.tv_usec = 0;
	 setsockopt( newfd, SOL_SOCKET, SO_RCVTIMEO, (void *) &tv, sizeof(tv) );
#endif
	 tv.tv_sec = 5;			/* 5 second send timeout */
	 tv.tv_usec = 0;
	 setsockopt( newfd, SOL_SOCKET, SO_SNDTIMEO, (void *) &tv, sizeof(tv) );

	 if (UFDBglobalDebug > 1)
	    ufdbLogMessage( "SRV: accept new fd %2d", newfd );

	 putFdQueue( newfd );
      }
   }
}


void * socket_handler_thread( void * ptr )
{
   int                 protocol;
   sigset_t            sigset;
   int                 i;
   int                 s;
   int                 sock_parm;
   int                 retval;
   long                num_cpus;
   struct utsname      sysinfo;
   pthread_attr_t      attr;
   struct sockaddr_in  addr_in;
#if HAVE_UNIX_SOCKETS
   struct sockaddr_un  addr_un;
#endif

   UFDBglobalReconfig = 1;

   /* Most signals must be blocked.
    * This is a requirement to use sigwait() in a thread.
    */
   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGCHLD );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   gettimeofday( &start_time, NULL );

   globalArgv = my_argv;
   globalEnvp = my_envp;

   ufdbSetGlobalErrorLogFile();
   ufdbResetUnknownURLs();
   UFDBglobalFatalError = 0;
   if (sgReadConfig( configFile ) == 0)
   {
      ufdbLogFatalError( "exiting due to missing configuration file" );
      exit( 3 );
   }

   /* ufdbSetGlobalErrorLogFile(); */
   if (UFDBglobalDebug)
      ufdbLogMessage( "sgReadConfig() finished. fatal=%d", UFDBglobalFatalError );
   UFDBlogConfig();

   ufdbRegisterFatalErrorCrashfun( crasher );

   adjustNumberOfWorkerThreads();	/* create more worker threads if necessary */

   UFDBinitHTTPSchecker();
#ifdef _POSIX_PRIORITY_SCHEDULING
   sched_yield();
#else
   usleep( 50000 );
#endif

   pthread_attr_init( &attr );
   pthread_attr_setscope( &attr, PTHREAD_SCOPE_SYSTEM );
   pthread_attr_setstacksize( &attr, 252 * 1024 );
#if HAVE_PTHREAD_ATTR_SETGUARDSIZE && UFDB_DEBUG
   pthread_attr_setguardsize( &attr, 8 * 1024 );
#endif
   for (i = 0; i < UFDB_NUM_HTTPS_VERIFIERS; i++)
   {
      pthread_create( &httpsthr[i], &attr, UFDBhttpsTunnelVerifier, (void *) ((long) i) );
#ifdef _POSIX_PRIORITY_SCHEDULING
      sched_yield();
#else
      usleep( 10000 );
#endif
   }
   ufdbLogMessage( "%d HTTPS verification threads created.", UFDB_NUM_HTTPS_VERIFIERS );
   usleep( 50000 );

   if (testMode)
      ufdbLogMessage( "-T option is used.  In test mode no URLs are ever blocked." );

   if (UFDBglobalFatalError)
   {
      ufdbLogError( "A FATAL ERROR OCCURRED: ALL REQUESTS ARE ANSWERED WITH \"OK\" (see previous lines for more information)  *****" );
      UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
   }
   else
   {
      ufdbHandleAlarmForTimeEvents( UFDB_PARAM_INIT );
      UFDBchangeStatus( UFDB_API_STATUS_STARTED_OK );
   }

   /*
    * Create the daemon socket that the it accepts connections on.
    * if available, first try a UNIX socket and then an IP socket.
    */
#if HAVE_UNIX_SOCKETS
   protocol = AF_UNIX;
   s = socket( protocol, SOCK_STREAM, 0 );
   if (s < 0)
   {
      protocol = AF_INET;
      s = socket( protocol, SOCK_STREAM, 0 );
   }
#else
   protocol = AF_INET;
   s = socket( protocol, SOCK_STREAM, 0 );
#endif

   if (s < 0)
   {
      ufdbLogError( "cannot create daemon socket: %s", strerror(errno) );
      UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
      pthread_exit( (void *) 0 ); 
   }

   /* 
    * The port number can be specified in the config file (UFDBglobalPortNum is set by the parser)
    * or a command line parameter (portNumCmdLine is set in main).
    * The command line setting has preference.
    */
   if (portNumCmdLine >= 0)
      UFDBglobalPortNum = portNumCmdLine;

#if HAVE_UNIX_SOCKETS
   if (protocol == AF_UNIX)
   {
      sprintf( addr_un.sun_path, "/tmp/ufdbguardd-%05d", UFDBglobalPortNum );
#if 0
      if (unlink( addr_un.sun_path ) < 0  &&  errno != ENOENT)
         ufdbLogError( "cannot remove socket %s: %s", addr_un.sun_path, strerror(errno) );
#endif
      addr_un.sun_family = AF_UNIX;
      /* with anti-aliasing warnings ON, connect/bind cause compiler warnings which we may ignore */
      retval = bind( s, (struct sockaddr *) &addr_un, sizeof(addr_un) );
      /* allow anybody to connect to the socket */
      if (retval >= 0)
      {
         chmod( addr_un.sun_path, S_IRUSR|S_IWUSR| S_IRGRP|S_IWGRP| S_IROTH|S_IWOTH );
	 ufdbLogMessage( "unix socket \"%s\" successfully created", addr_un.sun_path );
      }
   }
   else
#endif
   {
      /*
       * Allow server-side addresses to be reused (don't have to wait for timeout).
       */
      sock_parm = 1;
      setsockopt( s, SOL_SOCKET, SO_REUSEADDR, (void *) &sock_parm, sizeof(sock_parm) );

      addr_in.sin_family = AF_INET;
      addr_in.sin_port = htons( UFDBglobalPortNum );
      if (strcmp( UFDBglobalInterface, "all" ) == 0)
	 addr_in.sin_addr.s_addr = htonl( INADDR_ANY );
      else
      {
	 struct in_addr iaddr;
	 if (inet_pton( AF_INET, UFDBglobalInterface, &iaddr ) == 0)
	 {
	    addr_in.sin_addr.s_addr = htonl( INADDR_ANY );
	    ufdbLogError( "interface parameter '%s' is invalid. I will listen on port %d on ALL interfaces.",
			  UFDBglobalInterface, UFDBglobalPortNum );
	 }
	 else
	    addr_in.sin_addr.s_addr = iaddr.s_addr;
      }
      /* with anti-aliasing warnings ON, connect/bind cause compiler warnings which we may ignore */
      retval = bind( s, (struct sockaddr *) &addr_in, sizeof(addr_in) );
      if (retval >= 0)
	 ufdbLogMessage( "IP socket port %d on interface \"%s\" successfully created", 
	                 UFDBglobalPortNum, UFDBglobalInterface );
   }

   if (retval < 0)
   {
      ufdbLogFatalError( "cannot bind daemon socket: %s (protocol=%s)", strerror(errno), 
                         protocol==AF_INET?"IP":"UNIX" );
      fprintf( stderr, "cannot bind daemon socket: %s (protocol=%s) *****\n", strerror(errno), 
               protocol==AF_INET?"IP":"UNIX" );
      ufdbLogMessage( "check for and kill old daemon processes" );
      fprintf( stderr, "check for and kill old daemon processes\n" );
#if HAVE_UNIX_SOCKETS
      ufdbLogMessage( "and remove UNIX socket file \"%s\"", addr_un.sun_path );
      fprintf( stderr, "and remove UNIX socket file \"%s\"\n", addr_un.sun_path );
#endif
      close( s );
      UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
      pthread_exit( (void *) 0 );
   }
   
   /*
    * According to comment in the Apache httpd source code, these socket
    * options should only be set after a successful bind....
    */
   sock_parm = 1;
   setsockopt( s, SOL_SOCKET, SO_KEEPALIVE, (void *) &sock_parm, sizeof(sock_parm) );

   if (protocol == AF_INET)
   {
      sock_parm = 1;
      setsockopt( s, IPPROTO_TCP, TCP_NODELAY, (void *) &sock_parm, sizeof(sock_parm) );
   }

   if (listen( s, UFDB_MAX_WORKERS ) < 0)
   {
      ufdbLogFatalError( "cannot listen on daemon socket: %s", strerror(errno) );
      close( s );
      UFDBchangeStatus( UFDB_API_STATUS_FATAL_ERROR );
      pthread_exit( (void *) 0 );
   }

   if (protocol == AF_INET)
      ufdbLogMessage( "listening on interface %s port %d", UFDBglobalInterface, UFDBglobalPortNum );
#if HAVE_UNIX_SOCKETS
   else
      ufdbLogMessage( "listening on UNIX socket \"%s\"", addr_un.sun_path );
#endif

   /* Now is the right moment to write out main PID to the pid file
    * that is used by /etc/init.d/ufdb to send signals to ufdbguardd.
    */
   writePidFile();
   atexit( removePidFile );

#ifdef _POSIX_PRIORITY_SCHEDULING
   ufdbLogMessage( "processor yielding is enabled" );
#endif
   ufdbGetSysInfo( &sysinfo );
   num_cpus = ufdbGetNumCPUs();
   ufdbLogMessage( "system: %s %s %s %s on %ld CPU%s", sysinfo.machine, sysinfo.sysname, sysinfo.release, 
                   sysinfo.nodename, num_cpus, num_cpus>1?"s":"" );
   ufdbLogMessage( "ufdbguardd " VERSION " started with %d URL verification threads and %d SSL verification threads", 
                   n_workers, UFDB_NUM_HTTPS_VERIFIERS );
   if (UFDBglobalHttpdPort > 0)
      startHttpDaemon();

   UFDBglobalReconfig = 0;

   daemon_accept_connections( s, protocol );
   close( s );

#if 0
   removePidFile();
#endif
   pthread_exit( NULL );

   return NULL;
}


/*
 * This thread waits and handles the following signals:
 *    HUP, CHLD, USR1, USR2, TERM, INT and ALRM.
 */
void * signal_handler_thread( void * ptr )
{
   sigset_t        sigset;
   int             sig;

   ufdbSetThreadCPUaffinity( 0 );

   /* The HUP and other signals must be blocked.
    * This is a requirement to use sigwait() in a thread.
    */
   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGCHLD );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   sig = 0;
   while (1)
   {
      int        status;
      pid_t      pid;

      /* do not disturb pclose() and let it do its waitpid() */
      if (sig == SIGCHLD)
         usleep( 100000 );

      while ((pid = waitpid( -1, &status, WNOHANG )) > 0)
      {
	 if (UFDBglobalDebug > 1)
	    ufdbLogMessage( "signal handler: child process %d terminated with status %d", pid, status );
      }

      sig = 0;
      if (0 != sigwait( &sigset, &sig ))
      {
         ufdbLogError( "signal_handler_thread: sigwait() failed with %s", strerror(errno) );
	 continue;
      }

      switch (sig)
      {
      case SIGCHLD:   
         break;
      case SIGTERM:
      case SIGINT:
         TermSignalCaught( sig );
	 break;
      case SIGHUP:
	 HupSignalCaught( sig );
	 break;
      case SIGUSR1:
	 Usr1SignalCaught( sig );
         break;
      case SIGUSR2:
	 Usr2SignalCaught( sig );
         break;
      case SIGALRM:
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	 (void) pthread_rwlock_rdlock( &TheDatabaseLock );
#endif
	 ufdbHandleAlarmForTimeEvents( UFDB_PARAM_ALARM );
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	 (void) pthread_rwlock_unlock( &TheDatabaseLock );
#endif
         break;
      default:
         ufdbLogError( "signal handler: unexpected signal %d received", sig );
      }
   }

   return NULL;
}


/*
 * A pseudo-random sample of URLs is checked against all known categories
 * and if it appears to be uncategorised, it is buffered to be sent
 * to URLfilterDB at a later date (when SIGHUP is received).
 *
 * return 0 iff the URL is uncategorised, 1 otherwise.
 */
int ufdbVerifyURLallCats( 
   UFDBrevURL *          revURL,
   char *                URL )
{
   struct Category *     cat;
   struct UFDBmemTable * mt;

   if (UFDBglobalReconfig)
      return 1;

   if (UFDBglobalCheckedDB.table.nNextLevels > 0)
   {
      if (UFDBlookupRevUrl( &(UFDBglobalCheckedDB.table.nextLevel[0]), revURL ))
         return 1;
   }
   if (UFDBglobalCheckedExpressions != NULL)
   {
      if (ufdbRegExpMatch( UFDBglobalCheckedExpressions, URL ) == UFDB_API_MATCH)
         return 1;
   }

   for (cat = Cat;  cat != NULL;  cat = cat->next)
   {
      if (UFDBglobalReconfig)
         return 1;
      if (cat->domainlistDb != NULL)
      {
	 mt = (struct UFDBmemTable *) cat->domainlistDb->dbcp;
	 if (UFDBlookupRevUrl( &(mt->table.nextLevel[0]), revURL ))
	    return 1;
      }
      if (cat->regExp != NULL)
      {
	 if (ufdbRegExpMatch( cat->regExp, URL ) == UFDB_API_MATCH)
	    return 1;
      }
   }

   return 0;
}


/* static volatile int sample = 1; */


static char * _blockReason(
   int reason )
{
   switch (reason)
   { 
   case UFDB_API_BLOCK_NONE:          return "PASS";
   case UFDB_API_BLOCK_ACL:           return "BLOCK";
   case UFDB_API_BLOCK_HTTPS_OPTION:  return "BLOCK";
   case UFDB_API_BLOCK_SKYPE:         return "BLOCK";
   case UFDB_API_BLOCK_SAFESEARCH:    return "REDIR";
   case UFDB_API_BLOCK_LOADING_DB:    return "BLOCK-LD";
   case UFDB_API_BLOCK_FATAL_ERROR:   return "BLOCK-FATAL";
   case UFDB_API_BLOCKR_YOUTUBE_EDUFILTER:     return "REDIR";
   }
   return "BLOCK";
}


/*
 * housekeeper thread
 */
static void * housekeeper_main( void * ptr )
{
   sigset_t                sigset;
   time_t                  t;

   /* The HUP signal must be blocked.
    * This is a requirement to use sigwait() in a thread.
    */
   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGCHLD );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   ufdbSetThreadCPUaffinity( 0 );

   while (1)
   {
      if (UFDBglobalTerminating)
         break;

      pthread_testcancel();

      sleep( 121 );
      t = time( NULL );

      if (lastUpload == 0)
         lastUpload = t;
      if (!UFDBglobalReconfig  &&  t - lastUpload >= SECSOF2DAYS)
      {
	 ufdbLogMessage( "No new URL database was loaded in the past 48 hours.  Run ufdbUpdate or \"/etc/init.d/ufdb reload\"  *****" );
	 if (UFDBglobalDebug)
	    ufdbLogMessage( "housekeeper: generating statistics since it was not done in the past 48 hours" );
	 uploadStatistics( "2DAYS" );
	 UFDBlookupCounter = 0;
	 UFDBlookupHttpsCounter = 0;
	 UFDBblockCounter = 0;
	 UFDBtestBlockCounter = 0;
	 UFDBuncategorisedCounter = 0;
	 UFDBglobalTunnelCounter = 0;
	 UFDBsafesearchCounter = 0;
	 UFDBedufilterCounter = 0;
	 UFDBuploadSeqNo++;
	 if (UFDBlastIPcounterResetDate != 0  &&  t - UFDBlastIPcounterResetDate >= SECSOF8DAYS)
	 {
	    if (UFDBglobalDebug)
	       ufdbLogMessage( "housekeeper: resetting user counters since there was no reset in 8 days" );
	    UFDBinitializeIPcounters();
	 }
      }
   }

   pthread_exit( NULL );
}


static __inline__ int write_answer_ok( int fd )
{
   /* NOTE: the optional channel ID is dealt with by ufdbgclient */

   if (UFDBglobalSquidHelperProtocol == UFDB_SQUID_HELPER_PROTOCOL3)
   {
      return (int) write( fd, "OK\n", 3 );
      /* See also http://wiki.squid-cache.org/Features/AddonHelpers   and
       * http://www.squid-cache.org/Versions/v3/3.4/cfgman/url_rewrite_program.html
       */
   }
   else
   {
      return (int) write( fd, "\n", 1 );
   }
}


static __inline__ int write_answer_rewrite(
   int    fd, 
   char * replyBuf, 
   char * URL, 
   struct SquidInfo * si )
{
   int   replyLen;

   /* NOTE: the optional channel ID is dealt with by ufdbgclient */

   if (UFDBglobalSquidHelperProtocol == UFDB_SQUID_HELPER_PROTOCOL3)
   {
      replyLen = sprintf( replyBuf, "OK rewrite-url=\"%s\"\n", URL );
   }
   else if (UFDBglobalSquidHelperProtocol == UFDB_SQUID_HELPER_PROTOCOL2)
   {
      replyLen = sprintf( replyBuf, "%s\n", URL );
   }
   else
   {
      replyLen = sprintf( replyBuf, "%s %s/%s %s %s\n",
                          URL,
                          si->src[0] ? si->src : "-",
                          si->srcDomain[0] ? si->srcDomain : "-",
                          si->ident[0] ? si->ident : "-",
                          si->method );
   }

   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "redirect with protocol %d: %s", UFDBglobalSquidHelperProtocol, replyBuf );

   return (int) write( fd, replyBuf, replyLen );
}


static __inline__ int write_answer_redir(
   int    fd, 
   char * replyBuf, 
   char * URL, 
   struct SquidInfo * si )
{
   int   replyLen;

   /* NOTE: the optional channel ID is dealt with by ufdbgclient */

   if (UFDBglobalSquidHelperProtocol == UFDB_SQUID_HELPER_PROTOCOL3)
   {
      if (si->blockReason == UFDB_API_BLOCK_SAFESEARCH  ||
          si->blockReason == UFDB_API_BLOCKR_YOUTUBE_EDUFILTER)
      {
	 return write_answer_rewrite( fd, replyBuf, URL, si );
      }

      /* the redirection URL may have a "30N:" prefix */
      if (*URL == '3' && *(URL+1) == '0' && (*(URL+2) >= '0' && *(URL+2) <= '9') && *(URL+3) == ':')
      {
         replyLen = sprintf( replyBuf, "OK status=%3.3s url=\"%s\"\n", URL, URL+4 );
      }
      else
      {
	 if (strcmp( si->method, "CONNECT" ) == 0)
	    replyLen = sprintf( replyBuf, "OK rewrite-url=\"%s\"\n", URL );             /* must force rewrite for HTTPS to make Squid reconnect */
	 else
	    replyLen = sprintf( replyBuf, "OK status=" UFDB_DEFAULT_HTTP_RETURN_CODE " url=\"%s\"\n", URL );
      }
   }
   else if (UFDBglobalSquidHelperProtocol == UFDB_SQUID_HELPER_PROTOCOL2)
   {
      replyLen = sprintf( replyBuf, "%s\n", URL );
   }
   else
   {
      replyLen = sprintf( replyBuf, "%s %s/%s %s %s\n",
                          URL,
                          si->src[0] ? si->src : "-",
                          si->srcDomain[0] ? si->srcDomain : "-",
                          si->ident[0] ? si->ident : "-",
                          si->method );
   }

   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "redirect with protocol %d: %s", UFDBglobalSquidHelperProtocol, replyBuf );

   return (int) write( fd, replyBuf, replyLen );
}


/*
 * main of the worker threads.
 */
static void * worker_main( void * ptr )
{
   sigset_t                sigset;
   UFDBthreadAdmin *       admin;
   int                     tnum;
   int                     fd;
   int                     nbytes;
   unsigned long           num_reqs;
   struct Source *         src;
   struct Acl *            acl;
   char * 	 	   redirect;
   struct SquidInfo        squidInfo;
   char *                  line;
   char *                  answerBuf;
   char *                  tmp;
   int                     reconfiguring = -1;
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   int                     ret;
   int                     lock_used = 0;
#endif

   tnum = (int) ((long) ptr);

   /* The HUP signal must be blocked.
    * This is a requirement to use sigwait() in a thread.
    */
   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGCHLD );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   ufdbSetThreadCPUaffinity( tnum );

   admin = UFDBallocThreadAdmin();
   line = (char *) ufdbCalloc( 1, UFDB_MAX_URL_LENGTH );
   tmp = (char *) ufdbCalloc( 1, UFDB_MAX_URL_LENGTH );
   answerBuf = (char *) ufdbMalloc( UFDB_MAX_URL_LENGTH + 64 );

   while (1)
   {
      if (UFDBglobalTerminating)
         break;

      pthread_testcancel();
      getFdQueue( &fd );
      num_reqs = 0UL;
      if (UFDBglobalDebug)
	 ufdbLogMessage( "W%02d: open fd %2d", tnum, fd );

      while ((nbytes = read( fd, line, UFDB_MAX_URL_LENGTH-2 )) > 0)
      {
	 int access;

	 pthread_testcancel();

         line[nbytes] = '\0';
         num_reqs++;
	 UFDBlookupCounter++;	/* no mutex: faster and we do not care about a few increments less */

         if (UFDBglobalDebug > 1)
	    ufdbLogMessage( "W%02d: line=%s", tnum, line );

	 reconfiguring = UFDBglobalReconfig;
	 if (UFDBglobalTerminating)
	    break;

	 if (strncmp( line, "http://qdaemonstatus.urlfilterdb.com", 36 ) == 0)
	 {
	    (void) sprintf( tmp, "http://cgibin.urlfilterdb.com/cgi-bin/URLblocked.cgi?reconfig=%d", reconfiguring );
	    if (write_answer_redir( fd, answerBuf, tmp, &squidInfo ) < 0)
	    {
	       ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
	       goto write_error;
	    }
	    continue;
	 }

	 /* The strstr() is to prevent loops with redirect 302:... ads and other URLs
	  * that are matched by regular expressions 
	  */
	 if (strstr( line, "/URLblocked.cgi" ) != NULL  ||
	     strncmp( line, "blockedhttps.urlfilterdb.com", 28 ) == 0  ||		/* never block this URL */
	     strncmp( line, "http://cgibin.urlfilterdb.com/", 30 ) == 0)		/* never block this URL */
	 {
	    if (write_answer_ok( fd ) < 0)
	    {
	       ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
	       goto write_error;
	    }
	    continue;
	 }

	 squidInfo.revUrl = NULL;
	 if (parseLine(admin, line, &squidInfo) != 1) 		/* break down input line into struct squidInfo */
	 {
	    line[UFDB_MAX_URL_LENGTH-2] = '\0';
#if 0
	    for (tmp = line; *tmp != '\0'; tmp++)
	       if (!isprint(*tmp))
	          *tmp = '_';
#endif
	    ufdbLogError( "W%02d: error parsing input line: %s", tnum, line );
	    if (write_answer_ok( fd ) < 0)
	    {
	       ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
	       UFDBfreeRevURL( admin, squidInfo.revUrl );
	       goto write_error;
	    }
	    continue;
	 }

	 if (squidInfo.srcDomain[0] == '\0') 
	 {
	    squidInfo.srcDomain[0] = '-';
	    squidInfo.srcDomain[1] = '\0';
	 }

	 if (squidInfo.ident[0] == '\0') 
	 {
	    squidInfo.ident[0] = '-';
	    squidInfo.ident[1] = '\0';
	 }

	 if (strcmp( squidInfo.protocol, "https" ) == 0)
	    UFDBlookupHttpsCounter++;

	 if (reconfiguring == 0)
	    UFDBregisterCountedIP( squidInfo.src );

	 src = NULL;

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	 if (reconfiguring)
	 {
	    lock_used = 0;
	 }
	 else
	 {
	    lock_used = 1;
	    ret = pthread_rwlock_rdlock( &TheDatabaseLock );
	    if (ret != 0)
	       ufdbLogError( "worker_main: pthread_rwlock_rdlock failed with code %d", ret );
#ifdef UFDB_DEBUG_RWLOCK
	    else if (UFDBglobalDebug)
	       ufdbLogMessage( "worker-%02d: rdlock acquired", tnum );
#endif
	    src = UFDBgetSourceList();
	 }
#endif

	 if (strcmp( squidInfo.url, "debug.urlfilterdb.com/debug-thread-crash" ) == 0  && 
	     strcmp( squidInfo.ident, "eviltest" ) == 0)
	 {
	    struct Source * s0;
	    /* test/debug crash handler and ufdb-pstack */
	    s0 = NULL;
	    ufdbLogMessage( "worker-%02d: before forced SEGV", tnum );
	    s0->name = "crash-here-with SEGV-signal";
	    ufdbLogError( "worker-%02d: after forced SEGV", tnum );
	 }

	 for ( ; ; )
	 {
	    char * categoryIdent;
	    char * ACLident;

	    strcpy( tmp, squidInfo.src );			/* TO-DO: find out if strcpy() is necessary... */
	    src = UFDBfindSource( src, tmp, &squidInfo );
	    acl = UFDBfindACLbySource( src );

	    if (parseOnly)
	    {
	       if (write_answer_ok( fd ) < 0)
	       {
		  ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
		  UFDBfreeRevURL( admin, squidInfo.revUrl );
		  goto write_error;
	       }
	       break;
	    }

	    redirect = tmp;
	    access = UFDBCheckACLaccess( reconfiguring, acl, &squidInfo, redirect );	/* DUNNO/ALLOW/BLOCK */

	    if (UFDBglobalDebugRedirect)
	    {
	       ufdbLogMessage( "W%02d:   REDIRECT %s %s %s %s %s", tnum,
			       redirect, 
			       squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
			       squidInfo.ident, 
			       strcmp( squidInfo.method, "CONNECT" ) == 0 ? "CONNECT" : "GET",
			       squidInfo.method );
	    }

	    if (squidInfo.blockReason == UFDB_API_BLOCK_FATAL_ERROR)
	    {
	       ACLident = "config";
	       categoryIdent = "fatal-error";
	    }
	    else if (squidInfo.blockReason == UFDB_API_BLOCK_LOADING_DB)
	    {
	       ACLident = "config";
	       categoryIdent = "loading-database";
	    }
	    else 
	    {
	       if (acl == NULL)
		  ACLident = "acl-null";
	       else
		  ACLident = acl->name;

	       if (UFDBglobalFatalError)
		  categoryIdent = "fatal-error";
	       else if (reconfiguring)
		  categoryIdent = "loading-database";

	       if (squidInfo.aclpass == NULL)
	          categoryIdent = "any";
	       else if (squidInfo.aclpass->name == NULL)
		  categoryIdent = "acl-name-null";
	       else 
		  categoryIdent = squidInfo.aclpass->name;
	    }

	    if (access == UFDB_ACL_ACCESS_DUNNO  &&  src != NULL  &&  src->cont_search)
	    {
	       if (UFDBglobalDebug)
	       {
		  ufdbLogMessage( "      source %s  access DUNNO  cont_search 1  next %s", 
		                  src->name,
				  src->next != NULL ? src->next->name : "default" );
	       }
	       src = src->next;
	       continue;
	    }
	    else if (access == UFDB_ACL_ACCESS_DUNNO  ||  access == UFDB_ACL_ACCESS_ALLOW)
	    {
	       if (src == NULL || src->cont_search == 0) 		/* sources are exhausted */
	       {
								     	/* global SafeSearch */
		  if (access == UFDB_ACL_ACCESS_DUNNO  &&
		      UFDBglobalSafeSearch  &&
		      UFDBaddSafeSearch( squidInfo.domain, squidInfo.surl, squidInfo.orig ) 
			 == UFDB_API_MODIFIED_FOR_SAFESEARCH)
		  {
		     UFDBsafesearchCounter++;
		     if (UFDBglobalLogAllRequests || UFDBglobalLogPass || UFDBglobalDebugRedirect)
		     {
			ufdbLogMessage( "REDIR %-11s %-15s %-10s %-9s %s %s", 
					squidInfo.ident, 
					squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
					ACLident,
					"SAFESEARCH", squidInfo.url2display, squidInfo.method );
		     }

		     /* send a REDIRECT to Squid */
		     if (write_answer_rewrite( fd, answerBuf, squidInfo.orig, &squidInfo ) < 0)
		     {
			ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
			UFDBfreeRevURL( admin, squidInfo.revUrl );
			goto write_error;
		     }
		     break;
		  }

		  /* global edufilter; note that there is also a category-specific edufilter  */
		  if (access == UFDB_ACL_ACCESS_DUNNO  &&
		      UFDBglobalYoutubeEdufilter  &&
		      strcmp( squidInfo.method, "CONNECT" ) != 0  &&
		      UFDBaddYoutubeEdufilter( squidInfo.domain, squidInfo.surl, squidInfo.orig )
		         == UFDB_API_MODIFIED_FOR_YOUTUBE_EDUFILTER)
		  {
		     UFDBedufilterCounter++;
		     if (UFDBglobalLogAllRequests || UFDBglobalLogPass || UFDBglobalDebugRedirect)
		     {
			ufdbLogMessage( "REDIR %-11s %-15s %-10s %-9s %s %s",
					squidInfo.ident, 
			                squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
					ACLident,
					"EDUFILTER", squidInfo.url2display, squidInfo.method );
		     }

		     /* send a REDIRECT to Squid */
		     if (write_answer_rewrite( fd, answerBuf, squidInfo.orig, &squidInfo ) < 0)
		     {
			ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
			UFDBfreeRevURL( admin, squidInfo.revUrl );
			goto write_error;
		     }
		     break;
		  }

		  if (write_answer_ok( fd ) < 0)
		  {
		     ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
		     UFDBfreeRevURL( admin, squidInfo.revUrl );
		     goto write_error;
		  }

		  if (UFDBglobalLogAllRequests ||
		      (UFDBglobalLogPass  &&  strcmp( categoryIdent, "any" ) != 0))
		  {
		     ufdbLogMessage( "PASS  %-11s %-15s %-10s %-9s %s %s",
				     squidInfo.ident, 
			             squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
				     ACLident, categoryIdent, 
				     squidInfo.url2display, squidInfo.method );
		  }

		  if (!reconfiguring  &&  access == UFDB_ACL_ACCESS_DUNNO)
		  {
		     if (squidInfo.dot  &&
			 ( (strncmp( squidInfo.domain, "10.", 3 )==0) ||
			   (strncmp( squidInfo.domain, "127.", 4 )==0) ||
			   (strncmp( squidInfo.domain, "[::1]", 5 )==0) ||
			   (strncmp( squidInfo.domain, "100.100.", 8 )==0) ||
			   (strncmp( squidInfo.domain, "169.254.", 8 )==0) ||
			   (strncmp( squidInfo.domain, "192.168.", 8 )==0) ))
		     {
			/* do NOT check private networks with uncategorised domains */
		     }
		     else
		     {
			if (!ufdbVerifyURLallCats( squidInfo.revUrl, squidInfo.url2display ))
			{
			   ufdbRegisterUnknownURL( squidInfo.domain, squidInfo.port );
			   UFDBuncategorisedCounter++;
			}
		     }
		  }

		  break;
	       }

	       /* source != NULL */
	       if (UFDBglobalDebug)
	       {
		  ufdbLogMessage( "      source %s  access %s  continue %d  next %s", 
		                  src == NULL ? "-" : src->name,
				  access == UFDB_ACL_ACCESS_DUNNO ? "DUNNO" : "ALLOW",
				  src != NULL && src->cont_search ? 1 : 0,
				  src != NULL && src->next != NULL ? src->next->name : "NULL" );
	       }

	       if (access == UFDB_ACL_ACCESS_DUNNO  &&  src->next != NULL) 
	       {
		  src = src->next;
		  continue;
	       }
	       else
	       {
		  if (write_answer_ok( fd ) < 0)
		  {
		     ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
		     UFDBfreeRevURL( admin, squidInfo.revUrl );
		     goto write_error;
		  }
		  break;
	       }
	    }
	    else			/* access == UFDB_ACL_ACCESS_BLOCK */
	    {
	       if (testMode)
	       {
		  ufdbLogMessage( "TEST-%-5s %s %s %s %s %s %s",
				  _blockReason(squidInfo.blockReason),
				  squidInfo.ident, 
			          squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
				  ACLident,
				  categoryIdent, squidInfo.url2display, squidInfo.method );
		  if (write_answer_ok( fd ) < 0)                /* send back an "OK" message */
		  {
		     ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
		     UFDBfreeRevURL( admin, squidInfo.revUrl );
		     goto write_error;
		  }
		  UFDBtestBlockCounter++;
	       }
	       else
	       {
		  char urlgrp[64];

		  if (UFDBglobalSquidHelperProtocol != UFDB_SQUID_HELPER_PROTOCOL1  ||  squidInfo.urlgroup[0] == '#'  ||  squidInfo.urlgroup[0] == '\0')
		     urlgrp[0] = '\0';
		  else
		  {
		     urlgrp[0] = ' ';
		     strncpy( &urlgrp[1], squidInfo.urlgroup, 62 );
		     urlgrp[63] = '\0';
		  }

		  if (UFDBglobalLogBlock || UFDBglobalLogAllRequests)
		     ufdbLogMessage( "%-5s %-11s %-15s %-10s %-9s %s %s",
				     _blockReason(squidInfo.blockReason),
				     squidInfo.ident, 
			             squidInfo.srcDomain[0] != '-' && squidInfo.srcDomain[1] != '\0' ? squidInfo.srcDomain : squidInfo.src, 
				     ACLident,
				     categoryIdent, squidInfo.url2display, squidInfo.method );
		  if (strcmp( squidInfo.method, "CONNECT" ) == 0)
		     redirect = UFDBglobalRedirectHttps;
		  if (write_answer_redir( fd, answerBuf, redirect, &squidInfo ) < 0)
		  {
		     ufdbLogError( "W%02d: write failed: fd=%d %s", tnum, fd, strerror(errno) );
		     UFDBfreeRevURL( admin, squidInfo.revUrl );
		     goto write_error;
		  }
		  if (UFDBglobalDebug > 1)
		     ufdbLogMessage( "   %s is redirected to %s", squidInfo.url2display, redirect );
		  UFDBblockCounter++;
		  if (src != NULL)
		     src->nblocks++;
		  if (squidInfo.aclpass != NULL)
		  {
		     struct Category * cat;
		     squidInfo.aclpass->nblocks++;
		     cat = ufdbCategoryFindName( squidInfo.aclpass->name );
		     if (cat != NULL)
		        cat->nblocks++;
		  }
	       }
	       break;
	    }
	 }

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	 if (lock_used)
	 {
	    ret = pthread_rwlock_unlock( &TheDatabaseLock );
	    if (ret != 0)
	       ufdbLogError( "worker-%2d: error releasing lock: %d", tnum, ret );
#ifdef UFDB_DEBUG_RWLOCK
	    else if (UFDBglobalDebug)
	       ufdbLogMessage( "worker-%02d: rdlock release", tnum );
#endif
	    lock_used = 0;
	 }
#endif

	 UFDBfreeRevURL( admin, squidInfo.revUrl );

	 /* If configured, all traffic is slowed down by introducing an artificial 0.1 second delay.
	  * The effect of this delay is that
	  * 1) the database reload thread gets the CPU more often.
	  * 2) during the database reload only a few URLs are verified (slowly) which means
	  *    that the user experiences a slower internet connection and much less URLs
	  *    are passed through unfiltered.
	  */
         if (reconfiguring  &&  UFDBglobalURLlookupDelayDBreload)
	    usleep( 100000 );

#ifdef _POSIX_PRIORITY_SCHEDULING
	 if (UFDBhttpsVerificationQueued() > 3)
	    sched_yield();	
#endif
	 if (sig_other)
	    break;
      }				/* end of while-read loop */

      if (nbytes < 0  &&  !UFDBglobalTerminating)
      {
         ufdbLogError( "W%02d: read failed: fd=%d %s", tnum, fd, strerror(errno) );
      }
write_error:

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
      if (lock_used)
      {
	 ret = pthread_rwlock_unlock( &TheDatabaseLock );
	 if (ret != 0)
	    ufdbLogError( "worker-%2d: error releasing lock: %d", tnum, ret );
#ifdef UFDB_DEBUG_RWLOCK
	 else if (UFDBglobalDebug)
	    ufdbLogMessage( "worker-%02d: rdlock release", tnum );
#endif
	 lock_used = 0;
      }
#endif

      if (num_reqs > 1UL)
	 ufdbLogMessage( "W%02d: %lu URL verifications", tnum, num_reqs );

      if (UFDBglobalDebug)
	 ufdbLogMessage( "W%02d: close fd %2d", tnum, fd );
      close( fd );
      fd = -1;
   }

   /*NOTREACHED*/
   pthread_exit( NULL );
}


/*
 *  main of thread that deals with dynamic sources 
 *  defined by execuserlist.
 */
static void * dynamic_userlist_updater_main( void * ptr )
{
   sigset_t                sigset;
   struct Source *         src;
   int                     ret;

   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGCHLD );	/* SIGCHLD is used to interrupt nanosleep() */
#endif
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   ufdbSetThreadCPUaffinity( 0 );

   while (1)
   {
      struct timespec  tv;

      pthread_testcancel();

      if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_userlist_updater_main: sleeping for %d minutes", UFDBglobalRefreshUserlistInterval );

      tv.tv_sec = UFDBglobalRefreshUserlistInterval * 60;
      tv.tv_nsec = 0;
      (void) nanosleep( &tv, NULL );

      if (UFDBglobalTerminating)
         break;
      if (UFDBglobalReconfig)
         continue;
      
      if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	 ufdbLogMessage( "dynamic_userlist_updater_main: going to refresh execuserlists" );

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
      ret = pthread_rwlock_rdlock( &TheDatabaseLock );
      if (ret != 0)
	 ufdbLogError( "dynamic_userlist_updater_main: pthread_rwlock_rdlock TheDatabaseLock failed with code %d", ret );
#ifdef UFDB_DEBUG_RWLOCK
      else if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_userlist_updater_main: rdlock TheDatabaseLock acquired" );
#endif
#endif

      src = UFDBgetSourceList();
      while (src != NULL)
      {
         if (src->active  &&  src->userDb != NULL  &&  src->userDb->type == SGDBTYPE_EXECUSERLIST)
	 {
	    struct sgDb * oldudb;
	    struct sgDb * newudb;

	    if (UFDBglobalTerminating)
	       break;
	    if (UFDBglobalReconfig)
	    {
	       ufdbLogMessage( "dynamic_userlist_updater_main: NOT refreshing execuserlist for %s since the whole configuration is being reloaded", src->name );
	       break;
	    }
	    
	    if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	       ufdbLogMessage( "dynamic_userlist_updater_main: refreshing execuserlist for %s (%s)", src->name, src->sarg0 );

	    newudb = UFDBretrieveExecUserlist( src->sarg0 );
	    
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	    ret = pthread_rwlock_wrlock( &TheDynamicSourcesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_userlist_updater_main: pthread_rwlock_wrlock TheDynamicSourcesLock failed with code %d", ret );
#else
	    ret = pthread_mutex_lock( &TheDynamicSourcesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_userlist_updater_main: pthread_mutex_lock TheDynamicSourcesLock failed with code %d", ret );
#endif
	    oldudb = src->userDb;
            src->userDb = newudb;

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	    ret = pthread_rwlock_unlock( &TheDynamicSourcesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_userlist_updater_main: pthread_rwlock_unlock TheDynamicSourcesLock failed with code %d", ret );
#else
	    ret = pthread_mutex_unlock( &TheDynamicSourcesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_userlist_updater_main: pthread_mutex_unlock TheDynamicSourcesLock failed with code %d", ret );
#endif

            UFDBmemDBdeleteDB( (struct UFDBmemDB *) oldudb->dbcp );
	    ufdbFree( oldudb );

	    if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	       ufdbLogMessage( "dynamic_userlist_updater_main: refresh completed for %s", src->name );
	 }
         src = src->next;
      }

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
      ret = pthread_rwlock_unlock( &TheDatabaseLock );
      if (ret != 0)
	 ufdbLogError( "dynamic_userlist_updater_main: error releasing lock: %d", ret );
#ifdef UFDB_DEBUG_RWLOCK
      else if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_userlist_updater_main: rdlock release" );
#endif
#endif

      if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	 ufdbLogMessage( "dynamic_userlist_updater_main: refresh completed for all execuserlists" );
   }

   /*NOTREACHED*/
   pthread_exit( NULL );
}


/*
 *  main of thread that deals with dynamic categories
 *  defined by execdomainlist.
 */
static void * dynamic_domainlist_updater_main( void * ptr )
{
   sigset_t                sigset;
   struct Category *       clist;
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   int                     ret;
#endif

   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGCHLD );	/* SIGCHLD is used to interrupt nanosleep() */
#endif
#if 0
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   ufdbSetThreadCPUaffinity( 0 );

   while (1)
   {
      struct timespec  tv;

      pthread_testcancel();

      if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_domainlist_updater_main: sleeping for %d minutes", UFDBglobalRefreshDomainlistInterval );

      tv.tv_sec = UFDBglobalRefreshDomainlistInterval * 60;
      tv.tv_nsec = 0;
      (void) nanosleep( &tv, NULL );

      if (UFDBglobalTerminating)
         break;
      if (UFDBglobalReconfig)
         continue;
      
      if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	 ufdbLogMessage( "dynamic_domainlist_updater_main: going to refresh execdomainlists" );

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
      ret = pthread_rwlock_rdlock( &TheDatabaseLock );
      if (ret != 0)
	 ufdbLogError( "dynamic_domainlist_updater_main: pthread_rwlock_rdlock TheDatabaseLock failed with code %d", ret );
#ifdef UFDB_DEBUG_RWLOCK
      else if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_domainlist_updater_main: rdlock TheDatabaseLock acquired" );
#endif
#endif

      for (clist = Cat;  clist != NULL;  clist = clist->next)
      {
         if (clist->active  &&  clist->execdomainlist != NULL)
	 {
	    struct sgDb * oldddb;
	    struct sgDb * newddb;

	    if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	       ufdbLogMessage( "dynamic_domainlist_updater_main: refreshing execdomainlist for %s (%s)", 
	                       clist->name, clist->execdomainlist );

	    newddb = UFDBretrieveExecDomainlist( clist );
	    if (newddb == NULL)
	    {
	       if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
		  ufdbLogMessage( "refresh execdomainlist for %s presented no new domainlist", clist->name );
	       continue;
	    }
	    
#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	    ret = pthread_rwlock_wrlock( &TheDynamicCategoriesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_domainlist_updater_main: pthread_rwlock_wrlock TheDynamicCategoriesLock failed with code %d", ret );
#else
	    ret = pthread_mutex_lock( &TheDynamicCategoriesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_domainlist_updater_main: pthread_mutex_lock TheDynamicCategoriesLock failed with code %d", ret );
#endif

	    oldddb = clist->domainlistDb;
            clist->domainlistDb = newddb;

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
	    ret = pthread_rwlock_unlock( &TheDynamicCategoriesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_domainlist_updater_main: pthread_rwlock_unlock TheDynamicCategoriesLock failed with code %d", ret );
#else
	    ret = pthread_mutex_unlock( &TheDynamicCategoriesLock );
	    if (ret != 0)
	       ufdbLogError( "dynamic_domainlist_updater_main: pthread_mutex_unlock TheDynamicCategoriesLock failed with code %d", ret );
#endif

	    ufdbFreeDomainDb( oldddb );

	    if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	       ufdbLogMessage( "dynamic_domainlist_updater_main: refresh execdomainlist for %s completed", clist->name );
	 }
      }

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
      ret = pthread_rwlock_unlock( &TheDatabaseLock );
      if (ret != 0)
	 ufdbLogError( "dynamic_domainlist_updater_main: error releasing lock: %d", ret );
#ifdef UFDB_DEBUG_RWLOCK
      else if (UFDBglobalDebug)
	 ufdbLogMessage( "dynamic_domainlist_updater_main: rdlock release" );
#endif
#endif

      if (UFDBglobalDebug || UFDBglobalDebugExternalScripts)
	 ufdbLogMessage( "dynamic_domainlist_updater_main: refresh completed for all execdomainlists" );
   }

   /*NOTREACHED*/
   pthread_exit( NULL );
}


void doCommand( char * command )
{
   /* There is a serious problem sending signals to ufdbguardd and ufdbhttpd.
    * 1) ufdbguardd cannot send SIGTERM, but can send SIGKILL to ufdbhttpd.
    * 2) ufdbUpdate cannot send SIGHUP to ufdbguardd.
    */

   if (strcmp( command, "verify" ) == 0)
   {
      testConfig = 1;
      runAsDaemon = 0;
      UFDBglobalUploadStats = 0;
      globalErrorLog = stderr;
   }
}


extern char ** environ;

int main( 
   int            argc,
   char **        argv )
{
   int            i;
   pid_t          pid;
   sigset_t       sigset;
   pthread_attr_t attr;
   time_t 	  t;
   void *         dummy_ptr;
   char           niso_str[22];

   char ** envp = environ;

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   pthread_rwlockattr_t mylock_attr;
#endif

   strcpy( progname, "ufdbguardd" );

   /* TODO: unset LC variables; regex cannot deal with multibyte characters */

   while ((i = getopt(argc, argv, "AC:TNdDRPSh?rt:c:L:p:U:vw:")) != EOF)
   {
      switch (i) {
      case 'A':
	 fprintf( stderr, "-A option is obsolete\n");
	 break;
      case 'C':
	 doCommand( optarg );
         break;
      case 'N':
         UFDBglobalAnalyseUncategorisedURLs = -1;
	 break;
      case 'D':
	 runAsDaemon = 0;	/* undocumented -D option to prevent running as daemon */
	 break;
      case 'd':
	 UFDBglobalDebug++;
#ifdef UFDB_DEBUG
	 yydebug = 1;
#endif
	 break;
      case 'c':
	 configFile = optarg;
	 break;
      case 'p':
      	 portNumCmdLine = atoi( optarg );
	 if (portNumCmdLine <= 0) {
	    fprintf( stderr, "port number must be > 0\n" );
	    exit( 1 );
	 }
	 break;
      case 'P':			/* undocumented -P option for development purposes */
	 parseOnly = 1;
	 break;
      case 'R':
         UFDBglobalDebugRegexp = 1;
	 break;
      case 'S':
         UFDBglobalUploadStats = 0;
	 break;
      case 'r':
	 UFDBglobalDebugRedirect = 1;
	 break;
      case 't':			/* undocumented -t option for time-related testing */
	 if ((t = iso2sec(optarg)) == -1) {
	    fprintf( stderr, "-t dateformat error, should be yyyy-mm-ddTHH:MM:SS\n" );
	    exit( 1 );
	 }
	 if (t < 0) {
	    fprintf( stderr, "-t date have to after 1970-01-01T01:00:00\n" );
	    exit( 1 );
	 }
	 niso( t, niso_str );
	 ufdbLogMessage( "ufdbguardd emulating date %s", niso_str );
	 globalDebugTimeDelta = t - start_time.tv_sec;
	 start_time.tv_sec = start_time.tv_sec + globalDebugTimeDelta;
	 break;
      case 'T':
	 testMode = 1;		
	 break;
      case 'U':
	 if (strlen(optarg) <= 31)
	    strcpy( UFDBglobalUserName, optarg );
	 else
	    ufdbLogFatalError( "username supplied with -U option is too long" );
         break;
      case 'L':				/* undocumented -L option for alternate PID file */
	 globalPidFile = optarg;
         break;
      case 'v':
	 fprintf( stderr, "ufdbguardd: %s\n", VERSION );
	 fprintf( stderr, "The ufdbGuard software suite is free and Open Source Software.\n" );
	 fprintf( stderr, "Copyright (C) 2005-2014 by URLfilterDB and others.\n" );
	 exit( 0 );
	 break;
      case 'w':
         n_workers = atoi( optarg );
	 if (n_workers < 32)
	    n_workers = 32;
	 else if (n_workers > UFDB_MAX_WORKERS)
	 {
	    fprintf( stderr, "-w option exceeds the maximum.  The #threads is set to %d\n", UFDB_MAX_WORKERS );
	    n_workers = UFDB_MAX_WORKERS;
	 }
	 break;
      case '?':
      case 'h':
         usage( '\0' );
	 break;
      default:
         usage( i );
      }
   }

   ufdbSetGlobalErrorLogFile();

   if (runAsDaemon)
   {
      if ((pid = fork()) != 0)
	 exit( 0 );        
#ifndef UFDB_DEBUG
      close( 0 );
      close( 1 );
#endif
      setsid();
   }
   globalPid = getpid();

   UFDBdropPrivileges( UFDBglobalUserName );

   UFDBinitializeIPcounters();

   /*
    * Initialise signal handlers.
    * The HUP signal is dealt with on a per thread basis.
    */
   ufdbSetSignalHandler( SIGILL,  ufdbCatchBadSignal );
   ufdbSetSignalHandler( SIGBUS,  ufdbCatchBadSignal );
   ufdbSetSignalHandler( SIGSEGV, ufdbCatchBadSignal );

   ufdbSetSignalHandler( SIGPIPE, SIG_IGN );

   ufdbSetSignalHandler( SIGABRT, catchAbortSignal );

   ufdbSetSignalHandler( SIGTERM, catchTermSignal );
   ufdbSetSignalHandler( SIGINT,  catchTermSignal );

   ufdbSetSignalHandler( SIGHUP,  catchHUPSignal );
   ufdbSetSignalHandler( SIGUSR1, catchUSR1Signal );
   ufdbSetSignalHandler( SIGUSR2, catchUSR2Signal );

   ufdbSetSignalHandler( SIGCHLD, catchChildSignal );

   /* All signals must be blocked.
    * This is a requirement to use sigwait() in a thread.
    */
   sigemptyset( &sigset );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGUSR1 );
   sigaddset( &sigset, SIGUSR2 );
   sigaddset( &sigset, SIGCHLD );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGALRM );
#if 0
   sigaddset( &sigset, SIGILL );
   sigaddset( &sigset, SIGBUS );
   sigaddset( &sigset, SIGSEGV );	/* blocking SEGV with pthread_sigmask has undefined results */
#endif
   pthread_sigmask( SIG_BLOCK, &sigset, NULL );

   my_argc = argc;
   my_argv = argv;
   my_envp = envp;

   ufdbSetGlobalErrorLogFile();

   if (testConfig)
   {
      UFDBglobalFatalError = 0;
      UFDBglobalHttpdPort = 0;
      if (sgReadConfig( configFile ) == 0)
      {
         ufdbLogFatalError( "missing configuration file" );
	 exit( 3 );
      }
      if (UFDBglobalFatalError)
      {
	 ufdbLogMessage( "A FATAL ERROR OCCURRED: (see previous lines for more details)  *****" );
      }
      exit( 0 );
   }

#ifdef UFDB_HAVE_NATIVE_RWLOCK_MUTEX
   pthread_rwlockattr_init( &mylock_attr );
#if HAVE_PTHREAD_RWLOCK_PREFER_WRITER_NP
   pthread_rwlockattr_setkind_np( &mylock_attr, PTHREAD_RWLOCK_PREFER_WRITER_NP );
#endif
   pthread_rwlock_init( &TheDatabaseLock, &mylock_attr );
#endif

   /*
    * create the threads.
    */
   pthread_attr_init( &attr );
   pthread_attr_setscope( &attr, PTHREAD_SCOPE_SYSTEM );
   pthread_attr_setstacksize( &attr, 252 * 1024 );
#if HAVE_PTHREAD_ATTR_SETGUARDSIZE && UFDB_DEBUG
   pthread_attr_setguardsize( &attr, 8 * 1024 );
#endif

   pthread_create( &threadedSignalHandler, &attr, signal_handler_thread, (void *) 0 );
   /* sleep a bit since we really want that signal_handler_thread does its initialisation before going ahead */
   usleep( 100000 );

   for (i = 0; i < n_workers; i++)
   {
      pthread_create( &workers[i], &attr, worker_main, (void *) ((long) i) );
#ifdef _POSIX_PRIORITY_SCHEDULING
      sched_yield();
#else
      usleep( 15000 );
#endif
   }
   usleep( 100000 );
   ufdbLogMessage( "%d worker threads created.", n_workers );

   pthread_create( &dyn_userlist_handler, &attr, dynamic_userlist_updater_main, (void *) 0 );
   pthread_create( &dyn_domainlist_handler, &attr, dynamic_domainlist_updater_main, (void *) 0 );
   pthread_create( &housekeeper, &attr, housekeeper_main, (void *) 0 );

   /* socket_handler_thread() :
    *  initialize SSL library 
    *  create HTTPS verification threads
    *  read the config file
    *  increase number of worker threads if necessary
    *  write the pid file
    *  listen on the socket to pass FDs to workers
    */
   pthread_create( &sockethandler, &attr, socket_handler_thread, (void *) 0 );

   /* prevent an immediate exit */
   sleep( 2 );

   /*
    * exit when the sockethandler thread terminates.
    */
   pthread_join( sockethandler, &dummy_ptr );

   if (UFDBglobalDebug)
      ufdbLogMessage( "Socket handler stopped. ufdbguardd is going to stop." );

   /*
    *  Note: sockethandler terminated because of a signal.
    */
   UFDBglobalReconfig = 1;
   UFDBglobalTerminating = 1;
   alarm( 0 );

   if (badSignal)
   {
      removePidFile();
      BadSignalCaught( badSignal );
   }

   /* cancel (soft termination) and kill (hard and quick termination) threads */
   if (UFDBglobalDebug)
      ufdbLogMessage( "main: going to cancel threads" );
   pthread_cancel( housekeeper );
   pthread_cancel( dyn_userlist_handler );
   pthread_cancel( dyn_domainlist_handler );
   for (i = 0; i < UFDB_NUM_HTTPS_VERIFIERS; i++)
      pthread_cancel( httpsthr[i] );
   for (i = 0; i < n_workers; i++)
      pthread_cancel( workers[i] );

   removePidFile();
   UFDBchangeStatus( UFDB_API_STATUS_TERMINATED );
   ufdbLogMessage( "ufdbGuard daemon stopped" );

#if defined(UFDB_FREE_MEMORY)
   ufdbLogMessage( "freeing all memory ..." );
   ufdbFreeAllMemory();
   ufdbLogMessage( "done freeing memory." );
#endif

   _exit( 0 );

   return 0;
}


static char * makeBlockedCategoriesString( void )
{
   struct Category * cat;
   int               sz;
   static char       blocked[48001];

   sz = 0;
   blocked[0] = '\0';
   for (cat = Cat;  cat != NULL;  cat = cat->next)
   {
      sz += sprintf( &blocked[sz], "%s:%lu ", cat->name, cat->nblocks );
      if (sz > 47000)
      {
         strcat( &blocked[sz], " ..." );
	 break;
      }
   }

   return blocked;
}


static void uploadStatistics( 
   char * reason )
{
   char * URLs;
   char * message;
   int    length;
   int    s;
   int    nbytes;
   int    written;
   int    dummy;
   int    status;
   long   num_cpus;
   unsigned long  num_clients;
   struct utsname sysinfo;

   logStatistics();

   lastUpload = time( NULL );

   num_clients = UFDBgetNumberOfRegisteredIPs();
   if (UFDBglobalCheckedDB.mem == NULL)		/* not a client of URLfilterDB */
   {
      if (UFDBlookupCounter < 200)
	 return;
      if (num_clients == 0)
         return;
   }

   if (UFDBglobalDebug)
      ufdbLogMessage( "uploadStatistics: upload uncategorised URLs: %s,  upload statistics: %s", 
                      UFDBglobalAnalyseUncategorisedURLs>0 ? "yes" : "no",
		      UFDBglobalUploadStats ? "yes" : "no" );

   if (UFDBglobalAnalyseUncategorisedURLs > 0)
   {
      URLs = ufdbGetUnknownURLs();
      if (URLs == NULL)
	 URLs = "example.com|";
   }
   else
      URLs = "example.com|";

   if (UFDBglobalLogUncategorisedURLs)
   {
      if (!UFDBglobalAnalyseUncategorisedURLs)
	 ufdbLogError( "log-uncategorised-urls is ON but analyse-uncategorised-urls is OFF and therefore there are no uncategorised URLs to be logged" );
      else if (UFDBuncategorisedCounter == 0)
      {
         ufdbLogMessage( "there are no uncategorised URLs" );
      }
      else
      {
	 char * u;
         for (u = URLs; *u != '\0'; )
	 {
	    char * sep;
	    int    len;
	    sep = strchr( u, '|' );
	    if (sep == NULL)
	       break;
	    len = (int) (sep - u);
	    ufdbLogMessage( "uncategorised URL: %*.*s", len, len, u );
	    u = sep + 1;
	 }
      }
   }

   length = strlen( URLs );
   if (length <= 1)
   {
      URLs = "example.com|";
      length = strlen( URLs );
   }

   message = (char *) ufdbMalloc( 1500 + length + 48000 );
   if (message == NULL)
   {
      ufdbLogError( "could not malloc %d bytes for upload message. Aborting upload of uncategorised URLs", 1500 + length + 48000 );
      ufdbResetUnknownURLs();
      return;
   }

   ufdbGetSysInfo( &sysinfo );
   num_cpus = ufdbGetNumCPUs();

   if (UFDBglobalUploadStats)
   {
      sprintf( message, 
	       "POST /cgi-bin/uncat.pl HTTP/1.1\r\n"
	       "Host: " UFDB_UPLOAD_UNCATEGORISED_URLS_WEBSITE "\r\n"
	       "User-Agent: ufdbGuardd-" VERSION "\r\n"
	       "Content-Type: text/plain\r\n"
	       "Content-Length: %d\r\n"
	       "Connection: close\r\n"
	       "X-HasURLfilterDB: %s\r\n"
	       "X-DatabaseDate: %s\r\n"
	       "X-SiteInfo: %s %ld %s %s\r\n"
	       "X-NodeName: %s\r\n"
	       "X-SquidVersion: %s\r\n"
	       "X-SquidUsesBumping: %s\r\n"
	       "X-NumClients: %lu\r\n"
	       "X-NumLookups: %lu\r\n"
	       "X-NumHttpsLookups: %lu\r\n"
	       "X-NumTunnelsDetected: %lu\r\n"
	       "X-NumTestBlock: %lu\r\n"
	       "X-NumBlock: %lu\r\n"
	       "X-NumSafeSearch: %lu\r\n"
	       "X-NumEduFilter: %lu\r\n"
	       "X-Uncategorised: %lu\r\n"
	       "X-BlockedCategories: %s\r\n"
	       "X-UploadSeqNo: %lu\r\n"
	       "X-UploadReason: %s\r\n"
	       "\r\n"
	       "%s\r\n",
	       length, 
	       (UFDBglobalCheckedDB.mem == NULL ? "no" : "yes"),
	       (UFDBglobalCheckedDB.mem == NULL ? "void" : UFDBglobalCheckedDB.date),
	       sysinfo.machine, num_cpus, sysinfo.sysname, sysinfo.release, 
	       sysinfo.nodename,
	       UFDBglobalSquidVersion,
	       UFDBglobalSquidUsesSSLbump ? "yes" : "no",
	       num_clients,
	       UFDBlookupCounter,
	       UFDBlookupHttpsCounter,
	       UFDBglobalTunnelCounter,
	       UFDBtestBlockCounter,
	       UFDBblockCounter,
	       UFDBsafesearchCounter,
	       UFDBedufilterCounter,
	       UFDBuncategorisedCounter,
	       makeBlockedCategoriesString(),
	       UFDBuploadSeqNo,
	       reason,
	       URLs );
   }
   else
   {
      sprintf( message, 
	       "POST /cgi-bin/uncat.pl HTTP/1.1\r\n"
	       "Host: " UFDB_UPLOAD_UNCATEGORISED_URLS_WEBSITE "\r\n"
	       "User-Agent: ufdbGuardd-" VERSION "\r\n"
	       "Content-Type: text/plain\r\n"
	       "Content-Length: %d\r\n"
	       "X-HasURLfilterDB: %s\r\n"
	       "X-DatabaseDate: %s\r\n"
	       "X-SiteInfo: %s %ld %s %s\r\n"
	       "X-NodeName: %s\r\n"
	       "X-SquidVersion: %s\r\n"
	       "X-SquidUsesBumping: %s\r\n"
	       "X-NumClients: %lu\r\n"
	       "X-UploadSeqNo: %lu\r\n"
	       "X-UploadReason: %s\r\n"
	       "\r\n",
	       length,
	       (UFDBglobalCheckedDB.mem == NULL ? "no" : "yes"),
	       (UFDBglobalCheckedDB.mem == NULL ? "void" : UFDBglobalCheckedDB.date),
	       sysinfo.machine, num_cpus, sysinfo.sysname, sysinfo.release, 
	       sysinfo.nodename,
	       UFDBglobalSquidVersion,
	       UFDBglobalSquidUsesSSLbump ? "yes" : "no",
	       num_clients,
	       UFDBuploadSeqNo,
	       reason  );
   }
   length = strlen( message );

   /* This function migth be called N times when a bad signal is received.
    * Let's try to execute the upload only once by resetting the unknown URLs quickly.
    */
   ufdbResetUnknownURLs();

   s = UFDBopenSocket( UFDB_UPLOAD_UNCATEGORISED_URLS_WEBSITE, 80 );
   if (s < 0)
   {
      ufdbLogError( "cannot upload statistics/uncategorised URLs  *****\n"
                    "cannot open a communication socket to %s:%d (%s)",
                    UFDB_UPLOAD_UNCATEGORISED_URLS_WEBSITE, 80, strerror(errno) );
      return;
   }

   written = 0;
   while (length > 0)
   {
      nbytes = write( s, message+written, length );
      if (nbytes == 0)
         break;
      if (nbytes < 0)
      {
         if (errno != EINTR)
	    break;
      }
      else
      {
         written += nbytes;
	 length -= nbytes;
      }
   }

   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "upload statistics with HTTP POST: %s", message );

   errno = 0;
   status = 0;
   nbytes = read( s, message, 700 );
   if (nbytes < 0 || nbytes < 9)
   {
      ufdbLogError( "did not receive a HTTP response header. URLs are not uploaded: %s *****", strerror(errno) );
      written = 0;
   }
   else if (sscanf( message, "HTTP/1.%d %d ", &dummy, &status ) != 2)
   {
      ufdbLogError( "received a malformed HTTP response header: URLs are not uploaded *****" );
      written = 0;
   }
   else if (status != 200)
   {
      ufdbLogError( "received an unexpected HTTP response status: code %d. URLs are not uploaded  *****", status );
      written = 0;
   }

   if (UFDBglobalDebug)
   {
      if (nbytes > 0)
      {
         message[nbytes] = '\0';
	 ufdbLogMessage( "URL upload received this HTTP reply:\n%s", message );
	 ufdbLogMessage( "HTTP reply status is %d  (status message has %d bytes)", status, nbytes );
      }
   }

   close( s );
   ufdbFree( message );

   if (written>0  &&  (UFDBglobalDebug  ||  UFDBglobalAnalyseUncategorisedURLs > 0))
      ufdbLogMessage( "uncategorised URLs have been uploaded to URLfilterDB" );
}

