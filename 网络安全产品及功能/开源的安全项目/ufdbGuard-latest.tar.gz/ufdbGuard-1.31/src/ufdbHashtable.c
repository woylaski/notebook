/*
 * ufdbHashtable.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2015 by URLfilterDB with all rights reserved.
 *
 * Parts of the ufdbGuard daemon are based on squidGuard.
 * This module is entirely written by URLfilterDB.
 *
 * RCS $Id: ufdbHashtable.c,v 1.5 2015/09/16 18:17:32 root Exp root $
 */

#include "ufdb.h"
#include "ufdblib.h"
#include "ufdbchkport.h"
#include "httpsQueue.h"
#include "ufdbHashtable.h"

#include <strings.h>
#include <string.h>
#include <stdlib.h>

#define UFDB_DO_DEBUG 0


static void expandHashtable(
   struct UFDBhashtable *  ht  )
{
   unsigned int            newTableSize;
   unsigned int            i, j;
   struct UFDBhte *        hte;
   struct UFDBhte **       newtable;

   /* Whenever expeandHashtable is called, the ht->mutex is already locked,
    * so we do not use it in this function.
    */

   newTableSize = ht->tableSize * 2 - 1;
   newtable = ufdbCalloc( sizeof(struct UFDBhte*), newTableSize );
   if (newtable == NULL)
   {
      /* Oh my god, we ran out of memory.
       * Well, we just return without expanding the table
       * since the memory allocation error is in this stage
       * not severe and the application can go on.
       */

      /* horrible workaround to prevent calling expandTable all the time: */
      ht->optimalMaxEntries = (unsigned int) (ht->tableSize * 0.88);

      return;
   }

   for (i = 0; i < ht->tableSize; i++)
   {
      while ((hte = ht->table[i]) != NULL)
      {
	 ht->table[i] = hte->next;

	 /* put the entry in the new table (at the new position) */
	 j = hte->hash % newTableSize;
	 hte->next = newtable[j];
	 newtable[j] = hte;
      }
   }

   ht->tableSize = newTableSize;
   ht->optimalMaxEntries = (unsigned int) (newTableSize * 0.68);

   ufdbFree( ht->table );
   ht->table = newtable;
}

   
struct UFDBhashtable *
UFDBcreateHashtable( 
   unsigned int           tableSize,
   unsigned int           (*hashFunction) (void*),
   int                    (*keyEqFunction) (void*,void*) )
{
   struct UFDBhashtable * ht;
   pthread_mutexattr_t   attr;

   ht = ufdbMalloc( sizeof( struct UFDBhashtable ) );
   if (ht == NULL)
      return NULL;

   if (tableSize < 23)
      tableSize = 23;
   ht->tableSize = tableSize;
   ht->table = ufdbCalloc( sizeof(struct UFDBhte*), tableSize );
   if (ht->table == NULL)
      return NULL;
   ht->nEntries = 0;
   ht->optimalMaxEntries = (unsigned int) (tableSize * 0.68);
   ht->hashFunction = hashFunction;
   ht->keyEqFunction = keyEqFunction;

   pthread_mutexattr_init( &attr );
   pthread_mutexattr_settype( &attr, UFDBglobalDebug ? PTHREAD_MUTEX_ERRORCHECK : PTHREAD_MUTEX_NORMAL );
   pthread_mutex_init( &(ht->mutex), &attr );

   return ht;
}


void
UFDBinsertHashtable( 
   struct UFDBhashtable * ht,
   void *                 key,
   void *                 value,
   int                    lockSetBySearch )
{
   unsigned int           i;
   int                    ps;
   struct UFDBhte *       hte;

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBinsertHashtable: inserting key '%s'  value %08lx   lockset %d", (char*) key, (unsigned long) value, lockSetBySearch );

   if (!lockSetBySearch)
   {
      if (UFDBglobalDebug > 2)
	 ufdbLogMessage( "      UFDBinsertHashtable: thread %08lx locking mutex", (unsigned long) pthread_self() );

      ps = pthread_mutex_lock( &ht->mutex );
      if (ps != 0)
      {
	 UFDBglobalCrashOnFatal = 1;
         ufdbLogFatalError( "UFDBinsertHashtable: pthread_mutex_lock returned %d", ps );
      }
   }

   hte = ufdbMalloc( sizeof(struct UFDBhte) );
   if (hte == NULL)
   {
      ps = pthread_mutex_unlock( &ht->mutex );
      if (ps != 0)
      {
	 UFDBglobalCrashOnFatal = 1;
         ufdbLogFatalError( "UFDBinsertHashtable: pthread_mutex_unlock/1 returned %d", ps );
      }
      /* TODO: better error handling */
      return;
   }
   hte->hash = ht->hashFunction( key );
   hte->key = key;
   hte->value = value;

   i = hte->hash % ht->tableSize;
   hte->next = ht->table[i];
   ht->table[i] = hte;

   ht->nEntries++;
   if (ht->nEntries > ht->optimalMaxEntries)
      expandHashtable( ht );

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBinsertHashtable: thread %08lx unlocking mutex", (unsigned long) pthread_self() );

   ps = pthread_mutex_unlock( &ht->mutex );
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBinsertHashtable: pthread_mutex_unlock/2 returned %d", ps );
   }
}


/* UFDBlockHashtable:
 * on entry: ht->mutex MUST be unlocked.
 * on exit:  ht->mutex MUST be locked.
 */
void UFDBlockHashtable(
   struct UFDBhashtable * ht  )
{
   int ps;

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBlockHashtable: thread %08lx locking mutex", (unsigned long) pthread_self()  );

   ps = pthread_mutex_lock( &ht->mutex );
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBlockHashtable: pthread_mutex_lock returned %d", ps );
   }
}


void UFDBunlockHashtable( 
   struct UFDBhashtable * ht  )
{
   int ps;

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBunlockHashtable: thread %08lx unlocking mutex", (unsigned long) pthread_self()  );

   ps = pthread_mutex_unlock( &ht->mutex );
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBunlockHashtable: pthread_mutex_unlock returned %d", ps );
   }
}


void *
UFDBsearchHashtable( 
   struct UFDBhashtable * ht,
   void *                 key,
   int                    keepLockForInsert )
{
   unsigned int  	  hash;
   unsigned int  	  i;
   int                    ps;
   void *                 retval;
   struct UFDBhte  *      hte;

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBsearchHashtable: search '%s'  keeplock %d", (char*) key, keepLockForInsert );

   retval = NULL;
   hash = ht->hashFunction( key );

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBsearchHashtable: thread %08lx locking mutex", (unsigned long) pthread_self() );

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBsearchHashtable: searching '%s' ...", (char*) key );

   ps = pthread_mutex_lock( &ht->mutex );		/* =========================================================== */
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBsearchHashtable: pthread_mutex_lock returned %d", ps );
   }

      i = hash % ht->tableSize;
      hte = ht->table[i];
      while (hte != NULL)
      {
	 if (hte->hash == hash  &&  ht->keyEqFunction(key,hte->key))
	 {
	    retval = hte->value;
	    if (UFDBglobalDebug > 2)
	       ufdbLogMessage( "      UFDBsearchHashtable: found '%s'  value %08lx", (char*) key, (unsigned long) retval );
	    break;
	 }
	 hte = hte->next;
      }

   if ( !(retval == NULL  &&  keepLockForInsert) )
   {
      ps = pthread_mutex_unlock( &ht->mutex );		/* =================  CONDITIONAL UNLOCK  ==================== */
      if (UFDBglobalDebug > 2)
	 ufdbLogMessage( "      UFDBsearchHashtable: key '%s'  thread %08lx unlocked mutex", (char*) key, (unsigned long) pthread_self()  );
      if (ps != 0)
      {
	 UFDBglobalCrashOnFatal = 1;
         ufdbLogFatalError( "UFDBsearchHashtable: pthread_mutex_unlock returned %d", ps );
      }
   }

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBsearchHashtable: key '%s'  value %08lx", (char*) key, (unsigned long) retval );

   return retval;
}


void * 
UFDBremoveHashtable( 
   struct UFDBhashtable * ht,
   void *                 key )
{
   unsigned int           hash;
   unsigned int           i;
   struct UFDBhte *       hte;
   struct UFDBhte **      head_hte;
   void *                 retval;

   retval = NULL;
   hash = ht->hashFunction( key );

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBremoveHashtable: key '%s'", (char*) key );

   i = hash % ht->tableSize;
   head_hte = &( ht->table[i] );
   hte = *head_hte;
   while (hte != NULL)
   {
      if (hte->hash == hash  &&  ht->keyEqFunction(key,hte->key))
      {
	 *head_hte = hte->next;
	 retval = hte->value;
	 ufdbFree( hte->key );
	 ufdbFree( hte );
	 ht->nEntries--;
	 break;
      }
      head_hte = &hte->next;
      hte = hte->next;
   }

   if (hte == NULL)
      ufdbLogError( "UFDBremoveHashtable: did not find key %08lx in hashtable  *****", (unsigned long) key );

   return retval;
}


void
UFDBdestroyHashtable( 
   struct UFDBhashtable * ht,
   int                    freeValues )
{
   unsigned int           i;
   int                    ps;
   struct UFDBhte *       hte;
   struct UFDBhte *       next;

   /* Hmmm. The table will be destroyed and it is not
    * very useful to use the mutex.
    * But we use the mutex anyway to wait for any
    * current use of the table to terminate.
    */
   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBdestroyHashtable: thread %08lx locking mutex", (unsigned long) pthread_self() );

   ps = pthread_mutex_lock( &ht->mutex );
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBdestroyHashtable: pthread_mutex_lock returned %d", ps );
   }

      for (i = 0; i < ht->tableSize; i++)
      {
	 hte = ht->table[i];
	 while (hte != NULL)
	 {
	    next = hte->next;
	    ufdbFree( hte->key );
	    if (freeValues)
	       ufdbFree( hte->value );
	    ufdbFree( hte );
	    hte = next;
	 }
      }
      ufdbFree( ht->table );

   if (UFDBglobalDebug > 2)
      ufdbLogMessage( "      UFDBdestroyHashtable: thread %08lx unlocking mutex", (unsigned long) pthread_self() );

   ps = pthread_mutex_unlock( &ht->mutex );
   if (ps != 0)
   {
      UFDBglobalCrashOnFatal = 1;
      ufdbLogFatalError( "UFDBdestroyHashtable: pthread_mutex_unlock returned %d", ps );
   }

   /* ht contains the mutex, so it must be freed after the unlock(mutex) */
   ufdbFree( ht );
}

