/*
 * ufdbdb.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2013 by URLfilterDB with all rights reserved.
 *
 * Parts of ufdbGuard are based on squidGuard.
 * This module is NOT based on squidGuard.
 *
 * RCS $Id: ufdbdb.c,v 1.11 2015/08/20 13:18:25 root Exp root $
 */

/* This module is well tested and stable for a long time.
 * For maximum performance _FORTIFY_SOURCE is undefined.
 */
#undef _FORTIFY_SOURCE

/* to inline string functions with gcc : */
#if defined(__OPTIMIZE__) && defined(__GNUC__)  &&  defined(GCC_INLINE_STRING_FUNCTIONS_ARE_FASTER)
#define __USE_STRING_INLINES  1
#endif

#ifndef UFDB_GEN_API
#include "sg.h"
#endif

#include "ufdb.h"
#include "ufdblib.h"

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <pthread.h>
#include <syslog.h>
/* TODO: evaluate use of syslog() */
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#if HAVE_UNIX_SOCKETS
#include <sys/un.h>
#endif
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <fcntl.h>

#include "bzlib.h"

#if 0 && defined(__linux__) && defined(__GNUC__)
#include <sys/mman.h>
#endif

/* #define  UFDB_DEBUG_IPV6 */

/* #define UFDB_DO_DEBUG 1 */
#define UFDB_DO_DEBUG 0

#if UFDB_DO_DEBUG || 0
#define DEBUG(x) fprintf x 
#else
#define DEBUG(x) 
#endif

static struct UFDBtable * tableIndex;
static int                tableIndex_i;


UFDBthreadAdmin * UFDBallocThreadAdmin( void )
{
   UFDBthreadAdmin * admin;

   admin = (UFDBthreadAdmin *) ufdbCalloc( 1, sizeof(UFDBthreadAdmin) );

   return admin;
}


/* Mutex locks for _allocRevURL() are a thread synchronisation bottleneck */
/* so it is better that each thread has its own array of UFDBrevURL* */

static __inline__ UFDBrevURL * _allocRevURL( 
   UFDBthreadAdmin * admin )
{
   int               i;
   UFDBrevURL *      new;
   
   for (i = 0; i < admin->nAlloced; i++)
   {
      if (admin->myArrayUsage[i] == 0)
      {
         admin->myArrayUsage[i] = 1;
	 new = &(admin->myArray[i]);
	 return new;
      }
   }

   if (admin->nAlloced == MAX_REVURLS)
   {
      new = ufdbMalloc( sizeof(UFDBrevURL) );
   }
   else
   {
      admin->myArrayUsage[admin->nAlloced] = 1;
      new = &(admin->myArray[admin->nAlloced]);
      admin->nAlloced++;
   }

   return new;
}


static __inline__ void _freeRevURL( 
   UFDBthreadAdmin * admin, 
   UFDBrevURL *      old )
{
   int               i;

   for (i = 0; i < admin->nAlloced; i++)
   {
      if (old == &(admin->myArray[i]))
      {
         admin->myArrayUsage[i] = 0;
	 return;
      }
   }

   ufdbFree( old );
}


static UFDBrevURL * parseIPv6URL( 
   UFDBthreadAdmin * admin,
   unsigned char *   URL )
{
   unsigned char *   oldBracket;
   unsigned int      size;
   UFDBrevURL *      newHead;
   UFDBrevURL *      newPath;

#ifdef UFDB_DEBUG_IPV6
   fprintf( stderr, " parseIPv6URL: %s\n", URL );
#endif

   oldBracket = (unsigned char *) strchr( (char *) URL, ']' );
   if (oldBracket == NULL)
   {
      oldBracket = URL;
      while (*oldBracket != '\0'  &&  *(oldBracket+1) != '/')
	 oldBracket++;
      if (oldBracket - URL > sizeof(UFDBurlPart)-2)
         oldBracket = URL + sizeof(UFDBurlPart) - 2;
   }
#if 0
   else
   {
      char normalisedDomain[64];

      *oldBracket = '\0';
      if (UFDBparseIPv6address( URL+1, normalisedDomain ) == NULL)
         *oldBracket = ']';
      else
      {
	 *oldBracket = ']';
	 UFDBnormaliseIPv6Domain( URL, normalisedDomain );
      }
   }
#endif

   newHead = _allocRevURL( admin );
   size = (unsigned char *) oldBracket - URL + 1;
   if (size > sizeof(UFDBurlPart)-2)
      size = sizeof(UFDBurlPart) - 2;
   memccpy( newHead->part, URL, ']', size );
   newHead->part[ size ] = '\0';

   if (*(oldBracket+1) == '/')
   {
      newPath = _allocRevURL( admin );
      newHead->next = newPath;
      memccpy( newPath->part, oldBracket+1, '\0', sizeof(UFDBurlPart)-2 );
      newPath->part[ sizeof(UFDBurlPart)-2 ] = '\0';
      newPath->next = NULL;
   }
   else
      newHead->next = NULL;
   
   return newHead;
}


static UFDBrevURL * parseHostnameRecursive( 
   UFDBthreadAdmin * admin,
   UFDBrevURL *      prevHead, 
   unsigned char *   lastPiece )
{
   char *            dot;
   UFDBrevURL *      newHead;

#if 0
   DEBUG(( stderr, "   parseHostnameRecursive  0x%08x 0x%08x %s\n", prevHead, lastPiece, lastPiece ));  /* */
#endif

   dot = strrchr( (char *) lastPiece, '.' );
   if (dot == NULL)
   {
      newHead = _allocRevURL( admin );

      ufdbStrncpy( (char *) newHead->part, (char *) lastPiece, sizeof(UFDBurlPart) );
      newHead->next = prevHead;
   }
   else
   {
      *dot = '\0';
      newHead = _allocRevURL( admin );

      ufdbStrncpy( (char *) newHead->part, dot+1, sizeof(UFDBurlPart) );
      newHead->next = parseHostnameRecursive( admin, prevHead, lastPiece );
   }

   return newHead;
}


/* Parse the URL and reverse it into a linked list 
 * e.g. my.sex.com becomes "com" -> "sex" -> "my" -> NULL
 *
 * The input parameter, URL, must be a writable array of characters (size = UFDBmaxURLsize).
 */
UFDBrevURL * UFDBgenRevURL( 
   UFDBthreadAdmin * admin,
   unsigned char *   URL )
{
   char *            path;
   char              newStr[UFDB_MAX_URL_LENGTH];

   URL = (unsigned char *) strcpy( newStr, (char *) URL );

   if (URL[0] == '[')
      return parseIPv6URL( admin, URL );

   path = strchr( newStr, '/' );
   if (path != NULL)
   {
      UFDBrevURL * head;

      *path = '\0';
      if (*(path-1) == '.')		/* delete the last dot in the domain www.example.com./index.html */
         *(path-1) = '\0';
      path++;

      head = parseHostnameRecursive( admin, NULL, URL );

      if (*path != '\0')
      {
	 UFDBrevURL * ptr;

	 ptr = head;
	 while (ptr->next != NULL)
	    ptr = ptr->next;

	 ptr->next = _allocRevURL( admin );

	 ptr = ptr->next;
	 ptr->next = NULL;
	 ptr->part[0] = '/';
	 memccpy( (char *) ptr->part + 1, path, '\0', sizeof(UFDBurlPart)-2 );
	 ptr->part[ sizeof(UFDBurlPart)-2 ] = '\0';
      }
      return head;
   }
   else
   {
      unsigned char * end;

      for (end = URL; *end != '\0'; end++)
         ;
      if (*(end-1) == '.')		/* also match www.example.com. */
         *(end-1) = '\0';
      return parseHostnameRecursive( admin, NULL, URL );
   }
}


/* DEBUG: print a revURL to stderr
 */
void UFDBprintRevURL( UFDBrevURL * revURL )
{
   fputs( "   P ", stderr );
   while (revURL != NULL)
   {
      fputs( (char *) revURL->part, stderr );
      if (revURL->next != NULL)
         fputs( " . ", stderr );
      revURL = revURL->next;
   }
   fputs( " \n", stderr );
}


void UFDBfreeRevURL( 
   UFDBthreadAdmin * admin,
   UFDBrevURL *      revURL )
{
   UFDBrevURL *      next;

   while (revURL != NULL)
   {
      next = revURL->next;
      _freeRevURL( admin, revURL );
      revURL = next;
   }
   admin->nAlloced = 0;
}


#define ROUNDUPBY      4
#define ROUNDUP(i)     ( (i) + (ROUNDUPBY - ((i)%ROUNDUPBY) ) )

#define BIGROUNDUPBY   (4 * ROUNDUPBY)
#define BIGROUNDUP(i)  ( (i) + (BIGROUNDUPBY - ((i)%BIGROUNDUPBY) ) )

__inline__ static struct UFDBtable * _reallocTableArray( 
   struct UFDBtable *  ptr,
   int                 nElem )
{
   if (nElem <= ROUNDUPBY)
   {
      ptr = ufdbRealloc( ptr, (size_t) nElem * sizeof(struct UFDBtable) );
   }
   else if (nElem < 4*BIGROUNDUPBY)
   {
      if (nElem % ROUNDUPBY == 1)
	 ptr = ufdbRealloc( ptr, (size_t) ROUNDUP(nElem) * sizeof(struct UFDBtable) );
   }
   else
   {
      if (nElem % BIGROUNDUPBY == 1)
	 ptr = ufdbRealloc( ptr, (size_t) BIGROUNDUP(nElem) * sizeof(struct UFDBtable) );
   }

   return ptr;
}


void UFDBfreeTableIndex_1_2( struct UFDBtable * t )
{
   int i;

   if (t == NULL)
      return;

   for (i = 0; i < t->nNextLevels; i++)
   {
      UFDBfreeTableIndex_1_2( &(t->nextLevel[i]) );
   }

   ufdbFree( &(t->nextLevel[0]) );
}


void ufdbDecompressTable( struct UFDBmemTable * memTable )
{
   char * new_mem;
   int    rv;

#if 0
   fprintf( stderr, "decompress table from %ld original size of %d\n", 
            memTable->tableSize, memTable->numEntries );
#endif

   new_mem = ufdbMalloc( sizeof(struct UFDBfileHeader) + memTable->numEntries );
   if (new_mem == NULL)
   {
      fprintf( stderr, "ufdbDecompressTable: cannot allocate %ld bytes memory for table decompression\n", 
               (long) (sizeof(struct UFDBfileHeader) + memTable->numEntries) );
      exit( 1 );
   }
   memcpy( new_mem, memTable->mem, sizeof(struct UFDBfileHeader) );

   rv = BZ2_bzBuffToBuffDecompress( new_mem + sizeof(struct UFDBfileHeader),
                                    (unsigned int *) &(memTable->numEntries),
			            (char *) memTable->mem + sizeof(struct UFDBfileHeader),
			            memTable->tableSize,
			            0,
			            0 );
   if (rv != BZ_OK)
   {
      fprintf( stderr, "ufdbDecompressTable: decompression failed with code %d\n", rv );
      exit( 1 );
   }

   ufdbFree( memTable->mem );
   memTable->mem = new_mem;
}


/* Parse a binary table header from a memory table.
 */
int UFDBparseTableHeader( struct UFDBmemTable * memTable )
{
   int  retval = UFDB_API_OK;
   int  n;
   int  cksum;
   char prefix[32];
   char tableName[32];
   char key[32];
   char date[32];
   char flags[8+1];
   ufdbCrypt uc;
   unsigned char * mem;

   strcpy( date, "nodate" );
   strcpy( flags, "--------" );
   memTable->version[0] = '\0';
   memTable->numEntries = 0;
   memTable->indexSize = 0;
   cksum = -1;
   n = sscanf( memTable->mem, "%5s %7s %20s %11d key=%30s date=%20s %8s %d %d",
               prefix, &(memTable->version[0]), tableName, &(memTable->numEntries), 
	       key, date, flags, &(memTable->indexSize), &cksum );

#if 0
   if (UFDBglobalDebug)
      ufdbLogMessage( "      UFDBparseTableHeader: n=%d prefix=%-5.5s version=%s name=%s num=%d key=%s date=%s flags=%s indexsize=%d cksum=%05d\n", 
                      n, prefix, memTable->version, tableName, memTable->numEntries, key, date, flags, memTable->indexSize, cksum );
#endif

   if (n < 5  ||  strcmp(prefix,"UFDB") != 0)
   {
      fprintf( stderr, "invalid UFDB header\n" );
      fprintf( stderr, "contact support@urlfilterdb.com\n" );
      syslog( LOG_ALERT, "table %s has an invalid UFDB header", tableName );
      return UFDB_API_ERR_INVALID_TABLE;
   }

   if (memTable->indexSize < 0)
   {
      fprintf( stderr, "error in UFDB header: indexsize < 0\n" );
      fprintf( stderr, "contact support@urlfilterdb.com\n" );
      syslog( LOG_ALERT, "table %s has an erroneous UFDB header: indexsize < 0", tableName );
      return UFDB_API_ERR_INVALID_TABLE;
   }

   if (strcmp( memTable->version, UFDBdbVersion ) > 0)
   {
      fprintf( stderr, "UFDB file for table \"%s\" has data format version \"%s\" while "
      		       "this program\n"
                       "does not support versions higher than \"%s\"\n", 
		       tableName, memTable->version, UFDBdbVersion );
      fprintf( stderr, "Download/install a new version of this program.\n" );
      fprintf( stderr, "Go to http://www.urlfilterdb.com\n" );
      syslog( LOG_ALERT, "table %s has an unsupported data format (%s)", tableName, memTable->version );
      return UFDB_API_ERR_INVALID_TABLE;
   }

   /* starting with version 2.0 we need the indexSize */
   if (strcmp( "2.0", memTable->version ) >= 0)
   {
      if (n < 7)
      {
         fprintf( stderr, "invalid UFDB2 header\n" );
	 fprintf( stderr, "contact support@urlfilterdb.com\n" );
	 syslog( LOG_ALERT, "table %s has an invalid UFDB2 header", tableName );
	 return UFDB_API_ERR_INVALID_TABLE;
      }
      if (strcmp( "2.1", memTable->version ) >= 0)
      {
         /* starting with version 2.1 encrypted tables have
	  * an additional 64 random/dummy bytes at the start of the table and
	  * a 5-digit cksum.
	  */
      }
   }

   if (strlen( key ) < 19)
   {
      fprintf( stderr, "UFDB file for table \"%s\" has an invalid key\n", tableName );
      fprintf( stderr, "contact support@urlfilterdb.com\n" );
      return UFDB_API_ERR_INVALID_KEY;
   }

   memTable->key[0] = key[0];
   memTable->key[1] = key[1];
   memTable->key[2] = key[2];
   memTable->key[3] = key[3];
   /* skip '-' */
   memTable->key[4] = key[5];
   memTable->key[5] = key[6];
   memTable->key[6] = key[7];
   memTable->key[7] = key[8];
   /* skip '-' */
   memTable->key[8] = key[10];
   memTable->key[9] = key[11];
   memTable->key[10] = key[12];
   memTable->key[11] = key[13];
   /* skip '-' */
   memTable->key[12] = key[15];
   memTable->key[13] = key[16];
   memTable->key[14] = key[17];
   memTable->key[15] = key[18];

   strncpy( memTable->flags, flags, 8 );
   strncpy( memTable->date, date, 32 );

   if (strcmp( date, "nodate" ) != 0)
   {
      struct tm   tm;

      if (5 != sscanf( date, "%4d%2d%2d.%2d%2d", 
                       &tm.tm_year, &tm.tm_mon, &tm.tm_mday, &tm.tm_hour, &tm.tm_min ))
      {
         fprintf( stderr, "table %s has an invalid date (date=%13.13s)\n", tableName, date );
         fprintf( stderr, "contact support@urlfilterdb.com\n" );
	 syslog( LOG_ALERT, "table %s has an invalid date", tableName );
	 return UFDB_API_ERR_INVALID_TABLE;
      }
      else
      {
	 time_t      t_now;
	 time_t      t_db;
	 time_t      diff;

	 tm.tm_year -= 1900;
	 tm.tm_mon  -= 1;
	 tm.tm_isdst = 0;
	 tm.tm_sec   = 0;

	 t_db = mktime( &tm );
	 t_now = time( NULL );
	 diff = t_now - t_db;
	 if (diff < -24 * 60 * 60)	/* allow 1 day back for various time zones */
	 {
	    fprintf( stderr, "table %s has an invalid date (%13.13s)\n", tableName, date );
	    fprintf( stderr, "the difference between current system time and database timestamp is %ld seconds\n", diff );
            fprintf( stderr, "contact support@urlfilterdb.com\n" );
	    syslog( LOG_ALERT, "table %s has an invalid date (%13.13s)", tableName, date );
	    ufdbLogError( "table %s has an invalid date (%13.13s)", tableName, date );
	    retval = UFDB_API_ERR_INVALID_TABLE;
	 }
	 else if (diff > 28 * 24 * 60 * 60  &&  flags[1] == 'P')
	 {
	    fprintf( stderr, "table %s is dated %13.13s and has expired\n", tableName, date );
            fprintf( stderr, "contact support@urlfilterdb.com\n" );
	    syslog( LOG_ALERT, "table %s is too old", tableName );
	    ufdbLogFatalError( "table %s is dated %13.13s and has EXPIRED.  *******************\n"
	                       "Check licenses and cron job for ufdbUpdate",
			       tableName, date );
	    retval = UFDB_API_ERR_INVALID_TABLE;
	    UFDBglobalDatabaseStatus = UFDB_API_STATUS_DATABASE_EXPIRED;
	 }
	 else if (diff >  4 * 24 * 60 * 60  &&  flags[1] == 'P')
	 {
	    int days;
	    days = (int) (diff / (24 * 60 * 60));
	    fprintf( stderr, "table %s is dated %13.13s and is %d days old\n", tableName, date, days );
            fprintf( stderr, "contact support@urlfilterdb.com\n" );
	    syslog( LOG_ALERT, "table %s is %d days old. Check the cron job for ufdbUpdate", 
	            tableName, days );
	    ufdbLogError( "table %s is dated %13.13s and is %d days old.  *******************\n"
	                  "Check cron job for ufdbUpdate",
			  tableName, date, days );
	    if (UFDBglobalDatabaseStatus == UFDB_API_STATUS_DATABASE_OK)
	       UFDBglobalDatabaseStatus = UFDB_API_STATUS_DATABASE_OLD;
	 }
#if 0
	 fprintf( stderr, "t_db  %12ld\n", t_db );
	 fprintf( stderr, "t_now %12ld\n", t_now );
	 fprintf( stderr, "diff  %12ld\n", t_now - t_db );
#endif
      }
   }

   if (retval != UFDB_API_OK)
   {
      memTable->table.tag = (unsigned char *) "NEVER";
      memTable->mem = NULL;
      memTable->tableSize = 0;
      memTable->table.nNextLevels = 0;
      memTable->table.nextLevel = NULL;
   }
   else
   {
      ufdbLogMessage( "loading URL category %s with creation date %s", tableName, date );

      if (cksum > 0 && strcmp( "2.1", memTable->version ) >= 0)
      {
         int   mycksum;

	 if (flags[2] == 'Q')
	    mycksum = UFDBcalcCksum( memTable->mem + sizeof( struct UFDBfileHeader ) + 64, memTable->tableSize - 64 );
	 else
	    mycksum = UFDBcalcCksum( memTable->mem + sizeof( struct UFDBfileHeader ), memTable->tableSize );
	 if (mycksum == 0)
	    mycksum = 1;

	 if (cksum >= 0  &&  cksum != mycksum)
	 {
	    memTable->table.tag = (unsigned char *) "NEVER";
	    memTable->mem = NULL;
	    memTable->tableSize = 0;
	    memTable->table.nNextLevels = 0;
	    memTable->table.nextLevel = NULL;
	    ufdbLogError( "URL category %s has a file cksum of %05d but a different memory cksum of %05d", tableName, cksum, mycksum );
#if 0
	    return UFDB_API_ERR_CKSUM_NOT_VALID;
#endif
	 }
      }

      if (flags[2] == 'Q')		/* encrypted table */
      {
	 mem = (unsigned char *) memTable->mem + sizeof( struct UFDBfileHeader );
	 ufdbCryptInit( &uc, (unsigned char *) memTable->key, 16 );
	 ufdbEncryptText( &uc, mem, mem, memTable->tableSize );
	 if (UFDBglobalDebug)
	    ufdbLogMessage( "table %s decrypted", tableName );
      }

      if (memTable->flags[0] == 'C')	/* compressed table */
      {
	 ufdbDecompressTable( memTable );
	 if (UFDBglobalDebug)
	    ufdbLogMessage( "table %s uncompressed", tableName );
      }
   }

   return retval;
}


#include "strcmpurlpart.static.c"


static __inline__ unsigned char * parseNextTag( 
   struct UFDBtable * parent, 
   unsigned char *    mem )
{
   unsigned char *    tag;
   int                tagType;
   int                n;

   while (mem != NULL)
   {
      tag = mem;
      while (*mem >= ' ')
	 mem++;

      tagType = *mem;
      *mem++ = '\0';

      switch (tagType)
      {
      case UFDBsubLevel:
	    DEBUG(( stderr, "   parse  tag = %-10s  sub-level\n", tag )); /* */

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    parent->nextLevel = _reallocTableArray( parent->nextLevel, parent->nNextLevels );
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = NULL;

	    mem = parseNextTag( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsameLevel:
	    DEBUG(( stderr, "   parse  tag = %-10s  same-level\n", tag )); /* */

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    parent->nextLevel = _reallocTableArray( parent->nextLevel, parent->nNextLevels );
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = NULL;

	    break;

      case UFDBprevLevel:
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse  tag = %-10s  prev-level\n", tag )); /* */

	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel = _reallocTableArray( parent->nextLevel, parent->nNextLevels );
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    else 
	    {
	       DEBUG(( stderr, "   parse  tag = %-10s  prev-level\n", "*" )); /* */
	       ;
	    }
	    return mem;
	    break;

      case UFDBendTable:
	    DEBUG(( stderr, "   parse  tag = %-10s  end-of-table\n", tag[0] >= ' ' ? (char*) tag : "NONE" )); /* */
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse  tag = %-10s  end-of-table\n", tag )); /* */

	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel = _reallocTableArray( parent->nextLevel, parent->nNextLevels );
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    return NULL;
	    break;

      default:
            DEBUG(( stderr, "tagType = %d !\n", tagType ));
	    ;
      }
   }

   return NULL;
}


static __inline__ struct UFDBtable * _allocTableIndex( int num )
{
   struct UFDBtable * t;
   
   DEBUG(( stderr, "      _allocTableIndex( %3d )   i = %d\n", num, tableIndex_i ));

   t = &tableIndex[tableIndex_i];
   tableIndex_i += num;

   return t;
}


static unsigned char * parseNextTag_2_0( 
   struct UFDBtable * parent, 
   unsigned char *    mem )
{
   unsigned char *    tag;
   int                tagType;
   int                n;
   unsigned int       num_children;

   while (mem != NULL)
   {
      tag = mem;
      while (*mem >= ' ')
	 mem++;

      tagType = *mem;
      *mem++ = '\0';

      switch (tagType)
      {
      case UFDBsubLevel:
	    num_children = *mem++;
	    if (num_children == 0)
	    {
	       num_children = *mem  +  (*(mem+1) * 256)  +  (*(mem+2) * 65536);
	       mem += 3;
	    }

	    DEBUG(( stderr, "   parse2_0 tag = %-18s  sub-level   %d child(ren)\n", 
	            tag, num_children ));   /* */

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_0( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsameLevel:
	    DEBUG(( stderr, "   parse2_0 tag = %-18s  same-level\n", tag )); /* */

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = NULL;

	    break;

      case UFDBprevLevel:
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse2_0 tag = %-18s  prev-level\n", tag )); /* */

	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    else 
	    {
	       DEBUG(( stderr, "   parse2_0 tag = %-18s  prev-level\n", "*" )); /* */
	       ;
	    }
	    return mem;
	    break;

      case UFDBendTable:
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse2_0 tag = %-18s  end-of-table\n", tag )); /* */
	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    else
	    {
	       DEBUG(( stderr, "   parse2_0 tag = %-18s  end-of-table\n", "END" )); /* */
	       ;
	    }
	    return NULL;
	    break;
      }
   }

   return NULL;
}


static unsigned char * parseNextTag_2_1( 
   struct UFDBtable * parent, 
   unsigned char *    mem )
{
   unsigned char *    tag;
   int                tagType;
   int                n;
   unsigned int       num_children;

   while (mem != NULL)
   {
      tag = mem;
      while (*mem >= ' ')
	 mem++;

      tagType = *mem;
      *mem++ = '\0';

      switch (tagType)
      {
      case UFDBsubLevel:
	    num_children = *mem++;
	    if (num_children == 0)
	    {
	       num_children = *mem  +  (*(mem+1) * 256)  +  (*(mem+2) * 65536);
	       mem += 3;
	    }

	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level   %d child(ren)\n", tag, num_children ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel1:
            num_children = 1;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level1  1 child\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel2:
            num_children = 2;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level2  2 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel3:
            num_children = 3;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level3  3 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel4:
            num_children = 4;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level4  4 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel5:
            num_children = 5;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level5  5 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel6:
            num_children = 6;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level6  6 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevel7:
            num_children = 7;
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-level7  7 children\n", tag ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsubLevelNNN:
	    num_children = *mem  +  (*(mem+1) * 256)  +  (*(mem+2) * 65536);
	    mem += 3;

	    DEBUG(( stderr, "   parse2_1 tag = %-18s  sub-levelNN %d children\n", tag, num_children ));

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    if (parent->nextLevel == NULL)
	    {
	       /* only at the top-level node, the array is not pre-allocated ... */
	       parent->nextLevel = _allocTableIndex( 1 );
	    }
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = _allocTableIndex( num_children );

	    mem = parseNextTag_2_1( &(parent->nextLevel[n]), mem );
	    break;

      case UFDBsameLevel:
	    DEBUG(( stderr, "   parse2_1 tag = %-18s  same-level\n", tag )); /* */

	    n = parent->nNextLevels;
	    parent->nNextLevels++;
	    parent->nextLevel[n].tag = tag;
	    parent->nextLevel[n].nNextLevels = 0;
	    parent->nextLevel[n].nextLevel = NULL;

	    break;

      case UFDBprevLevel:
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse2_1 tag = %-18s  prev-level\n", tag )); /* */

	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    else 
	    {
	       DEBUG(( stderr, "   parse2_1 tag = %-18s  prev-level\n", "*" )); /* */
	       ;
	    }
	    return mem;
	    break;

      case UFDBendTable:
	    if (tag[0] >= ' ')   /* is the code followed by a tag or another code ? */
	    {
	       DEBUG(( stderr, "   parse2_1 tag = %-18s  end-of-table\n", tag )); /* */
	       n = parent->nNextLevels;
	       parent->nNextLevels++;
	       parent->nextLevel[n].tag = tag;
	       parent->nextLevel[n].nNextLevels = 0;
	       parent->nextLevel[n].nextLevel = NULL;
	    }
	    else
	    {
	       DEBUG(( stderr, "   parse2_1 tag = %-18s  end-of-table\n", "END" )); /* */
	       ;
	    }
	    return NULL;
	    break;

      default:
            ufdbLogFatalError( "cannot parse table: tag is %03o", tagType );
	    return NULL;
	    break;
      }
   }

   return NULL;
}


/* Parse a binary table that is loaded into memory.
 */
void UFDBparseTable( struct UFDBmemTable * memTable )
{
   memTable->table.nNextLevels = 0;
   memTable->table.nextLevel = ufdbCalloc( 1, sizeof(struct UFDBtable) );		/* TODO: investigate leak */

   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "UFDBparseTable: version=%s  flags=%8.8s  %d  %ld  %d", 
                      memTable->version, memTable->flags, memTable->numEntries, memTable->tableSize, memTable->indexSize );

   if (strcmp( memTable->version, "2.1" ) >= 0)
   {
      memTable->index = ufdbCalloc( memTable->indexSize+1, sizeof(struct UFDBtable) );
      tableIndex = memTable->index;
      tableIndex_i = 0;
      (void) parseNextTag_2_1( &(memTable->table),
                               memTable->mem + sizeof(struct UFDBfileHeader) + (memTable->flags[2] == 'Q' ? 64 : 0) );
   }
   else if (strcmp( memTable->version, "2.0" ) >= 0)
   {
      memTable->index = ufdbCalloc( memTable->indexSize+1, sizeof(struct UFDBtable) );
      tableIndex = memTable->index;
      tableIndex_i = 0;
      (void) parseNextTag_2_0( &(memTable->table),
                               memTable->mem + sizeof(struct UFDBfileHeader) );
#if 0
      fprintf( stderr, "predicted index size: %d   last index: %d\n", memTable->indexSize, tableIndex_i );
#endif
   }
   else
   {
      memTable->index = NULL;
      (void) parseNextTag( &(memTable->table), 
                           (unsigned char *) memTable->mem + sizeof(struct UFDBfileHeader) );
   }
}


/* perform lookup of revUrl in table t.
 * return 1 iff found, 0 otherwise.
 */
int UFDBlookupRevUrl( 
   struct UFDBtable * t, 
   UFDBrevURL *       revUrl )
{
   int b, e;
#if UFDB_DO_DEBUG
   struct UFDBtable * origtable = t;
#endif

begin:
   DEBUG(( stderr, "    UFDBlookupRevUrl:  table %-14s [%d]  tag %s  :  %s\n", origtable->tag, origtable->nNextLevels, t->tag, revUrl->part ));  /* */

   /* TODO: Random memory access is much slower than sequential memory access.
    * Therefor we choose between sequential search and binary search
    * depending on the number of elements in the array.
    */
   e = t->nNextLevels - 1;
#if 0
   if (e < 8)
   {
      /* sequential search */
      for (b = 0; b <= e; b++)
      {
	 int cmp;
	 cmp = strcmpURLpart( (char *) revUrl->part, (char *) t->nextLevel[b].tag );
	 DEBUG(( stderr, "      strcmpURLpart[%d]  %s  %s  = %d\n", b,
			 revUrl->part, t->nextLevel[b].tag, cmp ));
	 if (cmp == 0)
	 {
	    t = &(t->nextLevel[b]);
	    if (t->nNextLevels == 0)		/* no more levels in table -> MATCH */
	       return 1;
	    revUrl = revUrl->next;
	    if (revUrl == NULL)			/* no more levels in URL -> NO match */
	       return 0;

	    /* optimise the recursive call : */
	    /* return UFDBlookupRevUrl( t, revUrl ); */
	    goto begin;
	 }
	 else if (cmp > 0)
	    return 0;
      }
      return 0;  /* not found */
   }
   else
#endif
   {
      /* binary search */
      b = 0;
      while (b <= e)
      {
	 int i, cmp;

	 i = (b + e) / 2;
	 cmp = strcmpURLpart( (char *) revUrl->part, (char *) t->nextLevel[i].tag );
	 DEBUG(( stderr, "      strcmpURLpart[%d]  %s  %s  = %d\n", i,
			 revUrl->part, t->nextLevel[i].tag, cmp ));
	 if (cmp == 0)
	 {
	    t = &(t->nextLevel[i]);
	    if (t->nNextLevels == 0)		/* no more levels in table -> MATCH */
	       return 1;
	    revUrl = revUrl->next;
	    if (revUrl == NULL)			/* no more levels in URL -> NO match */
	       return 0;

	    /* optimise the recursive call : */
	    /* return UFDBlookupRevUrl( t, revUrl ); */
	    goto begin;
	 }
	 if (cmp < 0)
	    e = i - 1;
	 else
	    b = i + 1;
      }
   }

   return 0;  /* not found */
}


/*
 *  UFDBlookup: lookup a domain/URL in domain and URL databases.  
 *  return 1 if found.
 */
int UFDBlookup( 
   UFDBthreadAdmin *     admin,
   struct UFDBmemTable * mt, 
   char *                request )
{
   int                   result;
   UFDBrevURL *          revUrl;
   
   if (admin == NULL)
   {
      fprintf( stderr, "UFDBlookup admin=NULL\n" );
      return 0;
   }

   revUrl = UFDBgenRevURL( admin, (unsigned char *) request );
   result = UFDBlookupRevUrl( &(mt->table.nextLevel[0]), revUrl );
   DEBUG(( stderr, "  UFDBlookup( %s, %s ) = %d\n", mt->table.nextLevel[0].tag, request, result ));

   UFDBfreeRevURL( admin, revUrl );

   return result;
}


/*
 *  Initialise a database category (open and/or create a .ufdb file) 
 */
int UFDBloadDatabase( 
   struct UFDBmemTable * mtable, 
   char *                file    )
{
   int                   n;
   int                   in;
   struct stat           fileStat;
   char                  f[1024];

   if (file == NULL)
   {
      return UFDB_API_ERR_NULL;
   }

   strcpy( f, file );
   in = open( f, O_RDONLY );
   if (in < 0)
   {
      strcat( f, UFDBfileSuffix );
      in = open( f, O_RDONLY );
   }

   if (UFDBglobalDebug)
      ufdbLogMessage( "   UFDBloadDatabase: file '%s' %s\n", file, in<0 ? "does not exist" : "exists" );

   if (in < 0)
   {
      return UFDB_API_ERR_NOFILE;
   }

   if (fstat(in,&fileStat) < 0)
   {
      close( in );
      return UFDB_API_ERR_NOFILE;
   }

   mtable->table.tag = (unsigned char *) "UNIVERSE";
   mtable->table.nNextLevels = 0;
   mtable->table.nextLevel = NULL;
   mtable->mem = ufdbMalloc( fileStat.st_size + 1 );
   mtable->tableSize = fileStat.st_size - sizeof(struct UFDBfileHeader);
   n = read( in, mtable->mem, fileStat.st_size );
   close( in );
   if (n != fileStat.st_size)
   {
      return UFDB_API_ERR_READ;
   }

   n = UFDBparseTableHeader( mtable );
#if 0
   fprintf( stderr, "   UFDBparseTableHeader returns %d\n", n );
#endif
   if (n != UFDB_API_OK)
      return n;
   UFDBparseTable( mtable );

   return UFDB_API_OK;
}


char * ufdbCategoryName( const char * domain )
{
#ifndef UFDB_GEN_API
   UFDBrevURL *      revurl;
   struct Category * cat;
   char *            buffer;
   UFDBthreadAdmin * myadm;

   if (domain == NULL)
      return "null";
   
   if (UFDBglobalReconfig || UFDBglobalTerminating)
      return "unknown";

   myadm = UFDBallocThreadAdmin();

   buffer = ufdbStrdup( domain );
   revurl = UFDBgenRevURL( myadm, (unsigned char *) buffer );

   for (cat = Cat;  cat != NULL;  cat = cat->next)
   {
      if (cat->domainlistDb != NULL)
      {
	 struct UFDBmemTable * mt;
	 mt = (struct UFDBmemTable *) cat->domainlistDb->dbcp;
	 if (mt != NULL)
	 {
	    if (UFDBlookupRevUrl( &(mt->table.nextLevel[0]), revurl ))
	       break;
	 }
      }
   }

   UFDBfreeRevURL( myadm, revurl );
   ufdbFree( myadm );

   if (cat != NULL)
      return cat->name;
#endif

   return "any";
}

