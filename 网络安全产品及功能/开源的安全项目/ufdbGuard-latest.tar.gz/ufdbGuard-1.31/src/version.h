/*
 * ufdbGuard is copyrighted (C) 2005-2014 by URLfilterDB with all rights reserved.
 *
 * Parts of the ufdbGuard daemon are based on squidGuard.
 * This module is NOT based on squidGuard.
 */

#define UFDB_PATCHLEVEL "-13"

#define VERSION "1.31"

