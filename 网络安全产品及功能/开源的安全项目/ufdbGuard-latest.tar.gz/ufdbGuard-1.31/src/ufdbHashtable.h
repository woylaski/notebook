/*
 * ufdbHashtable.h - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2009 by URLfilterDB with all rights reserved.
 *
 * Parts of the ufdbGuard daemon are based on squidGuard.
 * This module is entirely written by URLfilterDB.
 *
 * RCS $Id: ufdbHashtable.h,v 1.3 2015/08/13 22:43:26 root Exp root $
 */

#ifndef UFDB_UFDBHASHTABLE_H_INCLUDED
#define UFDB_UFDBHASHTABLE_H_INCLUDED

#include <pthread.h>


struct UFDBhte
{
   void *            key;
   void *            value;
   unsigned int      hash;
   struct UFDBhte *  next;
};

struct UFDBhashtable
{
   unsigned int      tableSize;
   unsigned int      nEntries;
   unsigned int      optimalMaxEntries;
   struct UFDBhte ** table;
   unsigned int      (*hashFunction)( void * );
   int               (*keyEqFunction)( void *, void * );
   pthread_mutex_t   mutex;
};


struct UFDBhashtable *
UFDBcreateHashtable( 
   unsigned int           tableSize,
   unsigned int           (*hashFunction)( void * ),
   int                    (*keyEqFunction)( void *, void * ) );

void
UFDBinsertHashtable( 
   struct UFDBhashtable * ht, 
   void *                 key, 
   void *                 value,
   int                    lockSetBySearch );

void *
UFDBsearchHashtable( 
   struct UFDBhashtable * ht,
   void *                 key,
   int                    keepLockForInsert );


void * 
UFDBremoveHashtable( 
   struct UFDBhashtable * ht,
   void *                 key );


void
UFDBdestroyHashtable( 
   struct UFDBhashtable * ht,
   int                    freeValues );

void
UFDBlockHashtable( 
   struct UFDBhashtable * ht  );

void
UFDBunlockHashtable( 
   struct UFDBhashtable * ht  );

#endif 

