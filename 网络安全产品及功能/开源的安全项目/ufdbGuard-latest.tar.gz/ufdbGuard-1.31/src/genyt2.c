#include <stdio.h>
#include <stdlib.h>

char * genurl( void )
{
   static char url[128] = "";
   static char r[] = "1234567890abcdefghijklmnopqrstuvwxyz";
   int i;

   for (i = 0; i < 11; i++)
   {
      url[i] = r[ random() % 36 ];
   }
   url[i] = '\0';

   return url;
}


int main( int argc, char * argv[] )
{
    int i;

    fputs( "^http://www\\.youtube\\.com/watch?v=", stdout );
    fputs( "(", stdout );

    for (i = 0; i < 80000; i++)
    {
       fputs( genurl(), stdout );
       if (i != 79999)
          fputs( "|", stdout );
    }
    fputs( ")", stdout );
    fputs( "\n", stdout );

    return 0;
}

