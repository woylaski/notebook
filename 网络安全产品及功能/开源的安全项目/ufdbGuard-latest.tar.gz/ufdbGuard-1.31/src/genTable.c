/*
 * genTable.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2015 by URLfilterDB with all rights reserved.
 *
 * Parts of the ufdbGuard daemon are based on squidGuard.
 * This module is NOT based on squidGuard.
 *
 * Generate a binary table file (.ufdb) from unordered ASCII files 
 * with domains and urls.
 *
 * usage: ufdbGenTable [-V] [-n] [-C] [-X] [-k <key>] -t <tableName> -d <domains> [-u <urls>]
 *
 * RCS $Id: genTable.c,v 1.79 2015/06/09 01:08:27 root Exp root $
 */

/* ufdbGenTable needs speed! */
#undef _FORTIFY_SOURCE

#if defined(__OPTIMIZE__) && defined(__GNUC__)  &&  defined(GCC_INLINE_STRING_FUNCTIONS_ARE_FASTER)
#define __USE_STRING_INLINES 1
#endif

#if 0
#if defined(__linux__)  &&  defined(__GNUC__)
/* WHY ??  it makes ufdbGenTable slower */
#define _GNU_SOURCE
#endif
#endif

#define OPT_RECURSION

#include "ufdb.h"
#include "ufdblib.h"
#include "ufdbdb.h"

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

#include "bzlib.h"


static FILE * fin;
static char * inFileName;
static char * urlsFileName;
static char * tableName;

static struct UFDBtable * table;

#if 0
int    UFDBglobalDebug = 0;
#endif

static int numEntries = 0;
static int numNodes = 0;
static int numLeafNodes = 0;
static int numIndexNodes = 0;
static int doCrypt = 1;
static int doCompress = 0;
static int doProd = 0;
static int doWarnings = 1;
static int doSanityCheck = 1;
static int stripWWW = 0;
static int skipOptimisations = 0;
static char * format = UFDBdefaultdbVersion;

#if UFDB_DO_DEBUG || 0
#define DEBUG(x) fprintf x 
#else
#define DEBUG(x) 
#endif

#define ROUNDUPBY      8
#define ROUNDUP(i)     ( (i) + (ROUNDUPBY - ((i)%ROUNDUPBY) ) )

#define BIGROUNDUPBY   64
#define BIGROUNDUP(i)  ( (i) + (BIGROUNDUPBY - ((i)%BIGROUNDUPBY) ) )

#define ROUNDUPBYCUTOFF BIGROUNDUPBY


#if 0
pthread_mutex_t ufdb_malloc_mutex = UFDB_STATIC_MUTEX_INIT;
#endif


#if HAVE_PUTC_UNLOCKED

#define myfast_putc(c,fp)   putc_unlocked(c,fp)
#define myfast_getc(fp)     getc_unlocked(fp)

#if defined(__linux__) && defined(_GNU_SOURCE)
#define fast_puts(s,fp)     fputs_unlocked(s,fp)
#else
   __inline__ int fast_puts( const char * s, FILE * fp )
   {
      int retval;

      retval = 1;
      while (*s != '\0'  &&  ((retval = myfast_putc(*s,fp)) != EOF))
	 s++;

      return retval;
   }
#endif

#else

#define myfast_putc(c,fp)  fputc(c,fp)
#define fast_puts(s,fp)    fputs(s,fp)

#define myfast_getc(fp)    fgetc(fp)
#endif


static void usage( void )
{
   fprintf( stderr, "usage: ufdbGenTable [-V] [-n] [-q] [-C] [-k <key>] -t <tableName> -d <domains> [-u <urls>]\n" );
   fprintf( stderr, "flags: -n  no encryption\n" );
   fprintf( stderr, "       -k  16-char encryption key\n" );
   fprintf( stderr, "       -F  1.2|2.0|2.1 (default is %s)\n", UFDBdefaultdbVersion );
   fprintf( stderr, "       -D  debug\n" );
   fprintf( stderr, "       -q  be quiet (suppress warnings)\n" );
   fprintf( stderr, "       -C  use bz2 compression\n" );
   fprintf( stderr, "       -s  sanity check for domain names (obsolete) (check is always done)\n" );
   fprintf( stderr, "       -W  strip \"www.\" from URLs\n" );
   fprintf( stderr, "       -X  skip table optimisations - only for expert users\n" );
   fprintf( stderr, "       -V  print version and exit\n" );
   fprintf( stderr, "       -t  tablename\n" );
   fprintf( stderr, "       -d  domains\n" );
   fprintf( stderr, "       -u  urls\n" );
   exit( 1 );
}


void ufdbLogError( char * format, ... )
{
   va_list ap;
   char    msg[UFDB_MAX_URL_LENGTH];

   va_start( ap, format );
   if (vsnprintf(msg, UFDB_MAX_URL_LENGTH-1, format, ap) > (UFDB_MAX_URL_LENGTH - 2))
      msg[UFDB_MAX_URL_LENGTH-1] = '\0';
   va_end( ap );

   fprintf( stderr, "%s\n", msg );
}


void ufdbLogMessage( char * format, ... )
{
   va_list ap;
   char    msg[UFDB_MAX_URL_LENGTH];

   va_start( ap, format );
   if (vsnprintf(msg, UFDB_MAX_URL_LENGTH-1, format, ap) > (UFDB_MAX_URL_LENGTH - 2))
      msg[UFDB_MAX_URL_LENGTH-1] = '\0';
   va_end( ap );

   fprintf( stderr, "%s\n", msg );
}


void ufdbLogFatalError( char * format, ... )
{
   va_list ap;
   char    msg[UFDB_MAX_URL_LENGTH];

   va_start( ap, format );
   if (vsnprintf(msg, UFDB_MAX_URL_LENGTH-1, format, ap) > (UFDB_MAX_URL_LENGTH - 2))
      msg[UFDB_MAX_URL_LENGTH-1] = '\0';
   va_end( ap );

   fprintf( stderr, "%s *****\n", msg );
}


void ufdbSetGlobalErrorLogFile( void )
{
}


#if 0
#define _STRDUP(s) ufdbStrdup(s)
#else
/* 
 *  Small speed optimisation: allocate memory for strdupped strings in large blocks since they are never freed.
 */
static char * _STRDUP( 
   char * s )
{
   static char * freeMem = NULL;
   static char * last = NULL;

   char * p;
   int    size;

   for (p = s; *p != '\0'; p++)
      ;
   size = ((int) (p - s)) + 1;

   if ((int) (last - freeMem) < size)
   {
      freeMem = malloc( 256 * 1024 );
      last = freeMem + 256 * 1024 - 1;
   }

   p = memcpy( freeMem, s, size );
   freeMem += size;

   return p;
}
#endif


static int UFDBsanityCheckDomainname( char * url )
{
   char * first_slash;
   char * tld;
   int    retval;
   char * oldBracket;

#if 0
   fprintf( stderr, "UFDBsanityCheckDomainname: %s\n", url );
#endif

   if (*url == '[')			/* IPv6 address */
   {
      char normalisedDomain[64];

      oldBracket = strchr( url, ']' );
      if (oldBracket == NULL)
      {
         fprintf( stderr, "error: IPv6 address has no closing ']': %s\n", url );
	 return 0;
      }
      *oldBracket = '\0';
      if (UFDBparseIPv6address( url+1, normalisedDomain ) == NULL)
      {
	 *oldBracket = ']';
	 return 0;
      }
      else
      {
	 *oldBracket = ']';
	 UFDBupdateURLwithNormalisedDomain( url, normalisedDomain );
         return 1;
      }
   }

   first_slash = strchr( url, '/' );
   if (first_slash != NULL)
      *first_slash = '\0';

   tld = strrchr( url, '.' );
   if (tld == NULL)
      tld = url;
   else
      tld++;

   retval = 1;
   if (*tld >= '0'  &&  *tld <= '9')
      retval = 1;
   else
   if (strcmp( tld, "com" ) != 0  &&
       strcmp( tld, "wpad" ) != 0  &&
       strcmp( tld, "net" ) != 0  &&
       strcmp( tld, "us" ) != 0  &&
       strcmp( tld, "uk" ) != 0  &&
       strcmp( tld, "au" ) != 0  &&
       strcmp( tld, "ca" ) != 0  &&
       strcmp( tld, "hk" ) != 0  &&
       strcmp( tld, "ie" ) != 0  &&
       strcmp( tld, "mc" ) != 0  &&
       strcmp( tld, "mt" ) != 0  &&
       strcmp( tld, "nz" ) != 0  &&
       strcmp( tld, "sg" ) != 0  &&
       strcmp( tld, "vi" ) != 0  &&
       strcmp( tld, "ph" ) != 0  &&
       strcmp( tld, "pg" ) != 0  &&
       strcmp( tld, "nl" ) != 0  &&
       strcmp( tld, "be" ) != 0  &&
       strcmp( tld, "aw" ) != 0  &&
       strcmp( tld, "sr" ) != 0  &&
       strcmp( tld, "za" ) != 0  &&
       strcmp( tld, "es" ) != 0  &&
       strcmp( tld, "ar" ) != 0  &&
       strcmp( tld, "bo" ) != 0  &&
       strcmp( tld, "bs" ) != 0  &&
       strcmp( tld, "cr" ) != 0  &&
       strcmp( tld, "cu" ) != 0  &&
       strcmp( tld, "do" ) != 0  &&
       strcmp( tld, "gi" ) != 0  &&
       strcmp( tld, "gt" ) != 0  &&
       strcmp( tld, "mx" ) != 0  &&
       strcmp( tld, "ni" ) != 0  &&
       strcmp( tld, "ve" ) != 0  &&
       strcmp( tld, "uy" ) != 0  &&
       strcmp( tld, "sv" ) != 0  &&
       strcmp( tld, "pa" ) != 0  &&
       strcmp( tld, "pe" ) != 0  &&
       strcmp( tld, "py" ) != 0  &&
       strcmp( tld, "pr" ) != 0  &&
       strcmp( tld, "pt" ) != 0  &&
       strcmp( tld, "br" ) != 0  &&
       strcmp( tld, "mz" ) != 0  &&
       strcmp( tld, "vn" ) != 0  &&
       strcmp( tld, "vu" ) != 0  &&
       strcmp( tld, "fm" ) != 0  &&
       strcmp( tld, "to" ) != 0  &&
       strcmp( tld, "tv" ) != 0  &&
       strcmp( tld, "tk" ) != 0  &&
       strcmp( tld, "nu" ) != 0  &&
       strcmp( tld, "de" ) != 0  &&
       strcmp( tld, "at" ) != 0  &&
       strcmp( tld, "ch" ) != 0  &&
       strcmp( tld, "it" ) != 0  &&
       strcmp( tld, "dk" ) != 0  &&
       strcmp( tld, "fr" ) != 0  &&
       strcmp( tld, "st" ) != 0  &&
       strcmp( tld, "ws" ) != 0  &&
       strcmp( tld, "ru" ) != 0  &&
       strcmp( tld, "cn" ) != 0  &&
       strcmp( tld, "cc" ) != 0  &&
       strcmp( tld, "biz" ) != 0  &&
       strcmp( tld, "ae" ) != 0  &&
       strcmp( tld, "af" ) != 0  &&
       strcmp( tld, "xxx" ) != 0  &&
       strcmp( tld, "aero" ) != 0  &&
       strcmp( tld, "coop" ) != 0  &&
       strcmp( tld, "edu" ) != 0  &&
       strcmp( tld, "gov" ) != 0  &&
       strcmp( tld, "org" ) != 0  &&
       strcmp( tld, "info" ) != 0  &&
       strcmp( tld, "jobs" ) != 0  &&
       strcmp( tld, "museum" ) != 0  &&
       strcmp( tld, "name" ) != 0  &&
       strcmp( tld, "mil" ) != 0  &&
       strcmp( tld, "pro" ) != 0  &&
       strcmp( tld, "tel" ) != 0  &&
       strcmp( tld, "travel" ) != 0  &&
       strcmp( tld, "eu" ) != 0  &&
       strcmp( tld, "int" ) != 0  &&
       strcmp( tld, "info" ) != 0  &&
       strcmp( tld, "asia" ) != 0  &&
       strcmp( tld, "ag" ) != 0  &&
       strcmp( tld, "ai" ) != 0  &&
       strcmp( tld, "al" ) != 0  &&
       strcmp( tld, "am" ) != 0  &&
       strcmp( tld, "an" ) != 0  &&
       strcmp( tld, "ao" ) != 0  &&
       strcmp( tld, "aq" ) != 0  &&
       strcmp( tld, "arpa" ) != 0  &&
       strcmp( tld, "as" ) != 0  &&
       strcmp( tld, "aw" ) != 0  &&
       strcmp( tld, "ax" ) != 0  &&
       strcmp( tld, "az" ) != 0  &&
       strcmp( tld, "ac" ) != 0  &&
       strcmp( tld, "ad" ) != 0  &&
       strcmp( tld, "ba" ) != 0  &&
       strcmp( tld, "bb" ) != 0  &&
       strcmp( tld, "bd" ) != 0  &&
       strcmp( tld, "bf" ) != 0  &&
       strcmp( tld, "bg" ) != 0  &&
       strcmp( tld, "bh" ) != 0  &&
       strcmp( tld, "bi" ) != 0  &&
       strcmp( tld, "bj" ) != 0  &&
       strcmp( tld, "bm" ) != 0  &&
       strcmp( tld, "bn" ) != 0  &&
       strcmp( tld, "bt" ) != 0  &&
       strcmp( tld, "bv" ) != 0  &&
       strcmp( tld, "bw" ) != 0  &&
       strcmp( tld, "by" ) != 0  &&
       strcmp( tld, "bz" ) != 0  &&
       strcmp( tld, "tt" ) != 0  &&
       strcmp( tld, "is" ) != 0  &&
       strcmp( tld, "gg" ) != 0  &&
       strcmp( tld, "tp" ) != 0  &&
       strcmp( tld, "cat" ) != 0  &&
       strcmp( tld, "cd" ) != 0  &&
       strcmp( tld, "cf" ) != 0  &&
       strcmp( tld, "cg" ) != 0  &&
       strcmp( tld, "ci" ) != 0  &&
       strcmp( tld, "ck" ) != 0  &&
       strcmp( tld, "cl" ) != 0  &&
       strcmp( tld, "cm" ) != 0  &&
       strcmp( tld, "co" ) != 0  &&
       strcmp( tld, "cu" ) != 0  &&
       strcmp( tld, "cv" ) != 0  &&
       strcmp( tld, "cx" ) != 0  &&
       strcmp( tld, "cy" ) != 0  &&
       strcmp( tld, "cz" ) != 0  &&
       strcmp( tld, "dj" ) != 0  &&
       strcmp( tld, "dm" ) != 0  &&
       strcmp( tld, "do" ) != 0  &&
       strcmp( tld, "dz" ) != 0  &&
       strcmp( tld, "ec" ) != 0  &&
       strcmp( tld, "ee" ) != 0  &&
       strcmp( tld, "eg" ) != 0  &&
       strcmp( tld, "er" ) != 0  &&
       strcmp( tld, "es" ) != 0  &&
       strcmp( tld, "et" ) != 0  &&
       strcmp( tld, "fi" ) != 0  &&
       strcmp( tld, "fj" ) != 0  &&
       strcmp( tld, "fk" ) != 0  &&
       strcmp( tld, "fm" ) != 0  &&
       strcmp( tld, "fo" ) != 0  &&
       strcmp( tld, "fr" ) != 0  &&
       strcmp( tld, "ga" ) != 0  &&
       strcmp( tld, "gb" ) != 0  &&
       strcmp( tld, "gd" ) != 0  &&
       strcmp( tld, "ge" ) != 0  &&
       strcmp( tld, "gf" ) != 0  &&
       strcmp( tld, "gg" ) != 0  &&
       strcmp( tld, "gh" ) != 0  &&
       strcmp( tld, "gi" ) != 0  &&
       strcmp( tld, "gl" ) != 0  &&
       strcmp( tld, "gm" ) != 0  &&
       strcmp( tld, "gn" ) != 0  &&
       strcmp( tld, "gp" ) != 0  &&
       strcmp( tld, "gq" ) != 0  &&
       strcmp( tld, "gr" ) != 0  &&
       strcmp( tld, "gs" ) != 0  &&
       strcmp( tld, "gt" ) != 0  &&
       strcmp( tld, "gu" ) != 0  &&
       strcmp( tld, "gw" ) != 0  &&
       strcmp( tld, "gy" ) != 0  &&
       strcmp( tld, "hm" ) != 0  &&
       strcmp( tld, "hn" ) != 0  &&
       strcmp( tld, "hr" ) != 0  &&
       strcmp( tld, "ht" ) != 0  &&
       strcmp( tld, "hu" ) != 0  &&
       strcmp( tld, "id" ) != 0  &&
       strcmp( tld, "il" ) != 0  &&
       strcmp( tld, "im" ) != 0  &&
       strcmp( tld, "in" ) != 0  &&
       strcmp( tld, "io" ) != 0  &&
       strcmp( tld, "iq" ) != 0  &&
       strcmp( tld, "ir" ) != 0  &&
       strcmp( tld, "je" ) != 0  &&
       strcmp( tld, "jm" ) != 0  &&
       strcmp( tld, "jo" ) != 0  &&
       strcmp( tld, "jp" ) != 0  &&
       strcmp( tld, "ke" ) != 0  &&
       strcmp( tld, "kg" ) != 0  &&
       strcmp( tld, "kh" ) != 0  &&
       strcmp( tld, "ki" ) != 0  &&
       strcmp( tld, "km" ) != 0  &&
       strcmp( tld, "kn" ) != 0  &&
       strcmp( tld, "kr" ) != 0  &&
       strcmp( tld, "kw" ) != 0  &&
       strcmp( tld, "ky" ) != 0  &&
       strcmp( tld, "kz" ) != 0  &&
       strcmp( tld, "me" ) != 0  &&
       strcmp( tld, "mobi" ) != 0  &&
       strcmp( tld, "mobile" ) != 0  &&
       strcmp( tld, "la" ) != 0  &&
       strcmp( tld, "lb" ) != 0  &&
       strcmp( tld, "lc" ) != 0  &&
       strcmp( tld, "li" ) != 0  &&
       strcmp( tld, "lk" ) != 0  &&
       strcmp( tld, "lr" ) != 0  &&
       strcmp( tld, "ls" ) != 0  &&
       strcmp( tld, "lt" ) != 0  &&
       strcmp( tld, "lu" ) != 0  &&
       strcmp( tld, "lv" ) != 0  &&
       strcmp( tld, "ly" ) != 0  &&
       strcmp( tld, "ma" ) != 0  &&
       strcmp( tld, "md" ) != 0  &&
       strcmp( tld, "mg" ) != 0  &&
       strcmp( tld, "mh" ) != 0  &&
       strcmp( tld, "mk" ) != 0  &&
       strcmp( tld, "ml" ) != 0  &&
       strcmp( tld, "mm" ) != 0  &&
       strcmp( tld, "mn" ) != 0  &&
       strcmp( tld, "mo" ) != 0  &&
       strcmp( tld, "mp" ) != 0  &&
       strcmp( tld, "mr" ) != 0  &&
       strcmp( tld, "ms" ) != 0  &&
       strcmp( tld, "mt" ) != 0  &&
       strcmp( tld, "mu" ) != 0  &&
       strcmp( tld, "mv" ) != 0  &&
       strcmp( tld, "mw" ) != 0  &&
       strcmp( tld, "my" ) != 0  &&
       strcmp( tld, "mz" ) != 0  &&
       strcmp( tld, "na" ) != 0  &&
       strcmp( tld, "nc" ) != 0  &&
       strcmp( tld, "ne" ) != 0  &&
       strcmp( tld, "nf" ) != 0  &&
       strcmp( tld, "ng" ) != 0  &&
       strcmp( tld, "ni" ) != 0  &&
       strcmp( tld, "no" ) != 0  &&
       strcmp( tld, "np" ) != 0  &&
       strcmp( tld, "nr" ) != 0  &&
       strcmp( tld, "nu" ) != 0  &&
       strcmp( tld, "om" ) != 0  &&
       strcmp( tld, "pa" ) != 0  &&
       strcmp( tld, "pf" ) != 0  &&
       strcmp( tld, "pk" ) != 0  &&
       strcmp( tld, "pl" ) != 0  &&
       strcmp( tld, "pm" ) != 0  &&
       strcmp( tld, "pn" ) != 0  &&
       strcmp( tld, "ps" ) != 0  &&
       strcmp( tld, "pw" ) != 0  &&
       strcmp( tld, "py" ) != 0  &&
       strcmp( tld, "qa" ) != 0  &&
       strcmp( tld, "re" ) != 0  &&
       strcmp( tld, "ro" ) != 0  &&
       strcmp( tld, "rs" ) != 0  &&
       strcmp( tld, "rw" ) != 0  &&
       strcmp( tld, "sa" ) != 0  &&
       strcmp( tld, "sb" ) != 0  &&
       strcmp( tld, "sc" ) != 0  &&
       strcmp( tld, "sd" ) != 0  &&
       strcmp( tld, "se" ) != 0  &&
       strcmp( tld, "sh" ) != 0  &&
       strcmp( tld, "si" ) != 0  &&
       strcmp( tld, "sj" ) != 0  &&
       strcmp( tld, "sk" ) != 0  &&
       strcmp( tld, "sl" ) != 0  &&
       strcmp( tld, "sm" ) != 0  &&
       strcmp( tld, "sn" ) != 0  &&
       strcmp( tld, "so" ) != 0  &&
       strcmp( tld, "su" ) != 0  &&
       strcmp( tld, "sy" ) != 0  &&
       strcmp( tld, "sz" ) != 0  &&
       strcmp( tld, "tc" ) != 0  &&
       strcmp( tld, "td" ) != 0  &&
       strcmp( tld, "tf" ) != 0  &&
       strcmp( tld, "tg" ) != 0  &&
       strcmp( tld, "th" ) != 0  &&
       strcmp( tld, "tj" ) != 0  &&
       strcmp( tld, "tl" ) != 0  &&
       strcmp( tld, "tm" ) != 0  &&
       strcmp( tld, "tn" ) != 0  &&
       strcmp( tld, "tr" ) != 0  &&
       strcmp( tld, "tw" ) != 0  &&
       strcmp( tld, "tz" ) != 0  &&
       strcmp( tld, "ua" ) != 0  &&
       strcmp( tld, "ug" ) != 0  &&
       strcmp( tld, "um" ) != 0  &&
       strcmp( tld, "uz" ) != 0  &&
       strcmp( tld, "va" ) != 0  &&
       strcmp( tld, "vc" ) != 0  &&
       strcmp( tld, "vg" ) != 0  &&
       strcmp( tld, "wf" ) != 0  &&
       strcmp( tld, "ye" ) != 0  &&
       strcmp( tld, "yt" ) != 0  &&
       strcmp( tld, "yu" ) != 0  &&
       strcmp( tld, "zm" ) != 0  &&
       strcmp( tld, "zw" ) != 0)
      retval = 0;

   if (UFDBglobalDebug  &&  retval == 0)
      fprintf( stderr, "TLD '%s' not matched for '%s'\n", tld, url );

   if (first_slash != NULL)
      *first_slash = '/';

   return retval;
}


void initTable( char * tableName )
{
   table = (struct UFDBtable *) malloc( sizeof( struct UFDBtable ) + sizeof(struct UFDBtable*) );
   table->tag = (unsigned char *) _STRDUP( tableName );
   table->nNextLevels = 0;
   table->nextLevel = NULL;

   numIndexNodes = 0;
}


static __inline__ void * _trealloc( void * p, int n )
{
   int nup;

   if (n < ROUNDUPBYCUTOFF)
   {
      nup = ROUNDUP(n);
      if (nup == ROUNDUP(n-1))
         return p;
   }
   else
   {
      nup = BIGROUNDUP(n);
      if (nup == BIGROUNDUP(n-1))
         return p;
   }

   return realloc( p, nup * sizeof(struct UFDBtable) );
}

#include "strcmpurlpart.static.c"

int UFDBinsertURL( struct UFDBtable * t, UFDBrevURL * revURL, UFDBurlType type )
{
   /*
    * find the index where our URL has to be inserted before or is equal to
    * e.g. the level "net" is either "< nl" or "= net".
    */
   int b, e, i;
   int cmp;
   int rv;

   cmp = i = 0;

again:
   rv = 0;
   DEBUG(( stderr, "      UFDBinsertURL( 0x%08x, 0x%08x )\n", t, revURL )); /* */

   if (revURL == NULL)
   {
      if (t != NULL)
      {
         DEBUG(( stderr, "        revURL=NULL t: nNextLevels=%d, tag=%s\n", t->nNextLevels, t->tag ));
	 if (t->nNextLevels > 0)
	 {
	    /* interesting... we are trying to insert "xxx.com" while the tree already
	     * has one or more members with subdomains like yyy.xxx.com.
	     * Lets optimise this and get rid of the subdomains !
	     */
	    if (!skipOptimisations)
	    {
	       rv = 1;
	       t->nNextLevels = 0;
	       free( t->nextLevel );	/* TO-DO: should free() a tree ! */
	       t->nextLevel = NULL;
	    }
	 }
      }
      else
         DEBUG(( stderr, "        revURL=NULL t=NULL\n" ));
      return rv;
   }

   /* if the input file is already mostly sorted, almost all insertions take place at the end.
    * So lets optimise this by first looking at the end before doing a binary search.
    */

   if (t->nNextLevels > 0)		/* the very first entry at this level */
   {
      b = 0;
      e = i = t->nNextLevels - 1;
      cmp = strcmpURLpart( (char *) revURL->part, (char *) t->nextLevel[i].tag );

      if (cmp < 0)			/* nope, the entry is not at the end of the array */
      {
         e--;
	 				/* start binary search */
	 while (b <= e)
	 {
	    i = (b + e) / 2;
	    cmp = strcmpURLpart( (char *) revURL->part, (char *) t->nextLevel[i].tag );
	    /* DEBUG(( stderr, "       %d = strcmp( %s, %s )\n", cmp, revURL->part, t->nextLevel[i]->tag )); */
	    if (cmp == 0)
	       break;			/* found an exact match */
	    if (cmp < 0)
	       e = i - 1;
	    else
	       b = i + 1;
	 }
      }
      DEBUG(( stderr, "      UFDBinsertURL after bsearch: part=%s, cmp=%d, i=%d, b=%d, e=%d, nNextLevels=%d\n", 
	      (revURL==NULL ? (unsigned char *)"NULL" : revURL->part), cmp, i, b, e, t->nNextLevels ));
   }

   /* implemented optimisations: 
    * do not add subdom.abc.com/aurl if abc.com is already in the tree
    * do not add subdom.abc.com if abc.com is already in the tree
    * remove subdom.abc.com from tree if abc.com is being inserted
    */

   if (t->nNextLevels == 0)		/* the very first entry at this level */
   {
      DEBUG(( stderr, "      UFDBinsertURL after bsearch: part=%s nNextLevels=0\n", 
	      (revURL==NULL ? (unsigned char *)"NULL" : revURL->part) ));

      t->nNextLevels = 1;
      t->nextLevel = malloc( ROUNDUP(1) * sizeof(struct UFDBtable) );
      t->nextLevel[0].tag = (unsigned char *) _STRDUP( (char *) revURL->part );
      t->nextLevel[0].nNextLevels = 0;
      t->nextLevel[0].nextLevel = NULL;

#ifdef OPT_RECURSION
      t = &(t->nextLevel[0]);  revURL = revURL->next;  goto again;
#else
      rv = UFDBinsertURL( &(t->nextLevel[0]), revURL->next, type );
#endif
   }
   else if (cmp > 0)					/* this entry > nextLevel[i] */
   {
      i++;
      
      t->nNextLevels++;
      t->nextLevel = _trealloc( t->nextLevel, t->nNextLevels );

      /* make space in the array */
      if (t->nNextLevels > i)
      {
	 memmove( &(t->nextLevel[i+1]), &(t->nextLevel[i]), (t->nNextLevels-i) * sizeof(struct UFDBtable) );
      }

      /* insert the current revURL into the array */
      t->nextLevel[i].nNextLevels = 0;
      t->nextLevel[i].tag = (unsigned char *) _STRDUP( (char *) revURL->part );
      t->nextLevel[i].nextLevel = NULL;

      /* process the tail of revURL */
#ifdef OPT_RECURSION
      t = &(t->nextLevel[i]);  revURL = revURL->next;  goto again;
#else
      rv = UFDBinsertURL( &(t->nextLevel[i]), revURL->next, type );
#endif
   }
   else if (cmp == 0)				/* an exact match at this level */
   {
      /* optimisation: do not add site.com/foo if site.com is in the table */
      if (type == UFDBurl)
      {
         if (skipOptimisations  ||  t->nextLevel[i].nNextLevels != 0)
	 {
#ifdef OPT_RECURSION
            t = &(t->nextLevel[i]);  revURL = revURL->next;  goto again;
#else
	    rv = UFDBinsertURL( &(t->nextLevel[i]), revURL->next, type );
#endif
	 }
      }
      else
      {
#ifdef OPT_RECURSION
	 t = &(t->nextLevel[i]);  revURL = revURL->next;  goto again;
#else
	 rv = UFDBinsertURL( &(t->nextLevel[i]), revURL->next, type );
#endif
      }
   }
   else if (cmp < 0)				/* this entry < nextLevel[i] */
   {
      t->nNextLevels++;
      t->nextLevel = _trealloc( t->nextLevel, t->nNextLevels );

      /* make space in the array */
      if (t->nNextLevels >= i)
      {
	 memmove( &(t->nextLevel[i+1]), &(t->nextLevel[i]), (t->nNextLevels-i) * sizeof(struct UFDBtable) );
      }

      /* insert the current revURL into the array */
      t->nextLevel[i].nNextLevels = 0;
      t->nextLevel[i].tag = (unsigned char *) _STRDUP( (char *) revURL->part );
      t->nextLevel[i].nextLevel = NULL;

      /* process the tail of revURL */
#ifdef OPT_RECURSION
      t = &(t->nextLevel[i]);  revURL = revURL->next;  goto again;
#else
      rv = UFDBinsertURL( &(t->nextLevel[i]), revURL->next, type );
#endif
   }

   return rv;
}


/* Generate a binary table file format v1.2
 */
void writeTableToFile_1_2( struct UFDBtable * t, FILE * output )
{
   int i;

   fast_puts( (char *) t->tag, output );
   if (t->nNextLevels > 0)
   {
      myfast_putc( UFDBsubLevel, output );
   }

   for (i = 0; i < t->nNextLevels; i++)
   {
      writeTableToFile_1_2( &(t->nextLevel[i]), output );
      if (t->nextLevel[i].nNextLevels == 0)
      {
	 if (i < t->nNextLevels - 1)
	    myfast_putc( UFDBsameLevel, output );
      }
      else
	 myfast_putc( UFDBprevLevel, output );
   }
}


static void calcIndexSize( struct UFDBtable * t )
{
   int i;

   numNodes++;
   if (t->nNextLevels == 0)
      numLeafNodes++;

   for (i = 0; i < t->nNextLevels; i++)
      calcIndexSize( &(t->nextLevel[i]) );
}


/* generate a binary table file, database table format 2.0
 */
void writeTableToFile_2_0( struct UFDBtable * t, FILE * output )
{
   int i;

   fast_puts( (char *) t->tag, output );

   if (t->nNextLevels > 0)
   {
      myfast_putc( UFDBsubLevel, output );

      /* write the number of child nodes in a 1-byte or 4-byte code */
      if (t->nNextLevels <= 255)
         myfast_putc( t->nNextLevels, output );
      else
      {
         myfast_putc( 0, output );
         i = t->nNextLevels;
         myfast_putc( i % 256, output );
	 i = i / 256;
         myfast_putc( i % 256, output );
	 i = i / 256;
         myfast_putc( i % 256, output );
	 if (i > 32)
	    fprintf( stderr, "**** LARGE number of child nodes: %d for tag %s\n", t->nNextLevels, t->tag );
      }
      DEBUG(( stderr, "      tag = %-18s sub-level   %d child(ren)\n", 
                      t->tag, t->nNextLevels ));
   }
   else
   {
      numLeafNodes++;
      DEBUG(( stderr, "      tag = %-18s leaf \n", t->tag ));
   }

   for (i = 0; i < t->nNextLevels; i++)
   {
      writeTableToFile_2_0( &(t->nextLevel[i]), output );
      if (t->nextLevel[i].nNextLevels == 0)
      {
	 if (i < t->nNextLevels - 1)
	    myfast_putc( UFDBsameLevel, output );
      }
      else
	 myfast_putc( UFDBprevLevel, output );
   }
}


/* generate a binary table file, database table format 2.1
 */
void writeTableToFile_2_1( struct UFDBtable * t, FILE * output )
{
   int i;

   fast_puts( (char *) t->tag, output );

   if (t->nNextLevels == 1)
   {
      myfast_putc( UFDBsubLevel1, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   1 child\n", t->tag ));
   }
   else if (t->nNextLevels == 2)
   {
      myfast_putc( UFDBsubLevel2, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   2 children\n", t->tag ));
   }
   else if (t->nNextLevels == 3)
   {
      myfast_putc( UFDBsubLevel3, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   3 children\n", t->tag ));
   }
   else if (t->nNextLevels == 4)
   {
      myfast_putc( UFDBsubLevel4, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   4 children\n", t->tag ));
   }
   else if (t->nNextLevels == 5)
   {
      myfast_putc( UFDBsubLevel5, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   5 children\n", t->tag ));
   }
   else if (t->nNextLevels == 6)
   {
      myfast_putc( UFDBsubLevel6, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   6 children\n", t->tag ));
   }
   else if (t->nNextLevels == 7)
   {
      myfast_putc( UFDBsubLevel7, output );
      DEBUG(( stderr, "      tag = %-18s sub-level   7 children\n", t->tag ));
   }
   else if (t->nNextLevels > 0)
   {
      /* write the number of child nodes in a 2-byte or 4-byte code */
      if (t->nNextLevels <= 255)
      {
	 myfast_putc( UFDBsubLevel, output );
         myfast_putc( t->nNextLevels, output );		/* between 8 and 255 */
      }
      else
      {
	 myfast_putc( UFDBsubLevelNNN, output );	/* more than 255 */
         i = t->nNextLevels;
         myfast_putc( i % 256, output );
	 i = i / 256;
         myfast_putc( i % 256, output );
	 i = i / 256;
         myfast_putc( i % 256, output );
	 if (i > 32)
	    fprintf( stderr, "**** LARGE number of child nodes: %d for tag %s\n", t->nNextLevels, t->tag );
      }
      DEBUG(( stderr, "      tag = %-18s sub-level   %d children\n", t->tag, t->nNextLevels ));
   }
   else
   {
      numLeafNodes++;
      DEBUG(( stderr, "      tag = %-18s leaf \n", t->tag ));
   }

   for (i = 0; i < t->nNextLevels; i++)
   {
      writeTableToFile_2_1( &(t->nextLevel[i]), output );
      if (t->nextLevel[i].nNextLevels == 0)
      {
	 if (i < t->nNextLevels - 1)
	    myfast_putc( UFDBsameLevel, output );
      }
      else
	 myfast_putc( UFDBprevLevel, output );
   }
}


static __inline__ void addDomain( 
   UFDBthreadAdmin * admin,
   char *   	     domain, 
   UFDBurlType       type )
{
   char *            t;
   UFDBrevURL *      revUrl;
   int               rv;
   int               portnumber;
   char              protocol[16];
   char              strippedURL[UFDB_MAX_URL_LENGTH];
   char              strippedDomain[1024];
   
   /* strip starting and trailing spaces */
   while (*domain == ' ' || *domain == '\t')
      domain++;
   for (t = domain;  *t != '\0' && *t != '\n';  t++)
      ;
   t--;
   while (t > domain  &&  (*t == ' ' || *t == '\t'))
   {
      *t = '\0';
      t--;
   }
   /* skip empty lines */
   if (*domain == '\0')
      return;

   if (UFDBglobalDebug > 1)
      fprintf( stderr, "addDomain( %s )\n", domain );
      
   numEntries++;

   UFDBstripURL2( (char *) domain, stripWWW, strippedURL, strippedDomain, protocol, &portnumber );

#if 0
   if (UFDBglobalDebug)
   {
      ufdbLogMessage( "domain: %s\nstrippedurl: %s\nstripeddomain: %s\n%s %d", domain, strippedURL, strippedDomain, protocol, portnumber );
   }
#endif

   revUrl = UFDBgenRevURL( admin, (unsigned char *) strippedURL );

   /* first do a lookup of the domain, and if it already matches, it should
    * not be added !
    */
   if (skipOptimisations)
      rv = 0;
   else
      rv = UFDBlookupRevUrl( table, revUrl );
   if (rv)
   {
      if (doWarnings)
	 fprintf( stderr, "url/domain %s is not added because it was already matched.\n", domain );
   }
   else
   {
      rv = UFDBinsertURL( table, revUrl, type );
      if (rv)
      {
	 if (doWarnings)
	    fprintf( stderr, "url/domain %s has optimised subdomains.\n", domain );
      }
   }

   UFDBfreeRevURL( admin, revUrl );
}


static char randomChar( void )
{
   static char * a = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
   return a[random() % 62];
}


static void generateRandomKey( char * encryptKey )
{
   srandom( (getpid() << 12) + time(NULL) );

   encryptKey[0]  = randomChar();
   encryptKey[1]  = randomChar();
   encryptKey[2]  = randomChar();
   encryptKey[3]  = randomChar();
   encryptKey[4]  = randomChar();
   encryptKey[5]  = randomChar();
   encryptKey[6]  = randomChar();
   encryptKey[7]  = randomChar();
   encryptKey[8]  = randomChar();
   encryptKey[9]  = randomChar();
   encryptKey[10] = randomChar();
   encryptKey[11] = randomChar();
   encryptKey[12] = randomChar();
   encryptKey[13] = randomChar();
   encryptKey[14] = randomChar();
   encryptKey[15] = randomChar();
   encryptKey[16] = '\0';
}


static void copyKey( char * key, char * encryptKey )
{
   key[0]  = encryptKey[0];
   key[1]  = encryptKey[1];
   key[2]  = encryptKey[2];
   key[3]  = encryptKey[3];
   key[4]  = '-';
   key[5]  = encryptKey[4];
   key[6]  = encryptKey[5];
   key[7]  = encryptKey[6];
   key[8]  = encryptKey[7];
   key[9]  = '-';
   key[10] = encryptKey[8];
   key[11] = encryptKey[9];
   key[12] = encryptKey[10];
   key[13] = encryptKey[11];
   key[14] = '-';
   key[15] = encryptKey[12];
   key[16] = encryptKey[13];
   key[17] = encryptKey[14];
   key[18] = encryptKey[15];
   key[19] = '\0';
}


static void encryptMemory( char * to, char * from, long n, unsigned char * key )
{
   ufdbCrypt uc;

   if (UFDBglobalDebug)
      fprintf( stderr, "encryptMemory( %08lx %08lx %ld %16.16s )\n", (unsigned long)to, (unsigned long)from, n, key );

   ufdbCryptInit( &uc, key, 16 );
   ufdbEncryptText( &uc, (unsigned char *) to, (unsigned char *) from, n );
}


static long compressMemory( char * to, char * from, long size )
{
   unsigned int new_size;

   new_size = (unsigned int) (size + 2048);
   if (BZ_OK != BZ2_bzBuffToBuffCompress( to, &new_size, from, size, 7, 0, 30 ))
   {
      fprintf( stderr, "compression failed.\n" );
      exit( 1 );
   }

   if (UFDBglobalDebug)
      fprintf( stderr, "compressMemory from size %ld to %d\n", size, new_size );

   return new_size;
}


static void updateSizeInHeader( 
   FILE * f, 
   long   size,
   int    cksum  )
{
   int    n;
   int    _indexSize;
   char   version[8];
   char   prefix[32];
   char   tableName[32];
   char   key[32];
   char   date[32];
   char   flags[8+1];
   struct UFDBfileHeader header;

   if (UFDBglobalDebug)
      fprintf( stderr, "updateSizeInHeader %ld\n", size );

   fseek( f, 0, SEEK_SET );
   if (8 != fscanf( f, "%5s %7s %20s %11d key=%30s date=%20s %8s %d",
                    prefix, version, tableName, &n, key, date, flags, &_indexSize ))
   {
      return;
   }

   fseek( f, 0, SEEK_SET );
   sprintf( header.string, "%s %s %s %ld key=%s date=%s %8s %d %d\n\n",
            "UFDB", version, tableName, size, key, date, flags, _indexSize, cksum );
   fprintf( f, "%s", header.string );
   for (n = sizeof(header.string) - strlen(header.string); n > 0; n--)
      myfast_putc( '\0', f );
   fflush( f );

   fseek( f, 0, SEEK_END );
}


static void randomisebuf64( char * buf )
{
   int    n;
   unsigned int   seed;
   FILE * fp;

   seed = 0x05ac7326;

   if (doProd)
   {
      fp = popen( "w | cksum", "r" );
      if (fp != NULL)
      {
	 fscanf( fp, "%u", &seed );
	 fclose( fp );
      }
   }

#if 0
   printf( "random seed is %08x\n", seed );
#endif

   seed = (seed + 1309) ^ (((getpid() << 3) ^ (time(NULL) << 19)) + (getppid() << 26));
   srandom( seed );

   for (n = 0; n < 64; n++)
   {
      *buf++ = randomChar();
   }
}


static void doCryptCompress( 
   FILE * f, 
   char * encryptKey,
   char * format )
{
   long   size;
   long   orig_size;
   int    cksum;
   char * buffer1;
   char * buffer2;

   fflush( f );
   fseek( f, 0, SEEK_END );
   orig_size = size = ftell( f ) - sizeof(struct UFDBfileHeader);
   cksum = 0;

   if (UFDBglobalDebug)
      fprintf( stderr, "doCryptCompress orig_size %ld bytes  doCrypt=%d  doCompress=%d  format=%s\n", 
               orig_size, doCrypt, doCompress, format );

   buffer1 = malloc( size + 2048 );
   buffer2 = malloc( size + 2048 );
   if (buffer1 == NULL  ||  buffer2 == NULL)
   {
      fprintf( stderr, "cannot allocate memory for encryption and/or compression (size=%ld)\n", size );
      exit( 1 );
   }

   fseek( f, sizeof(struct UFDBfileHeader), SEEK_SET );

   if (doCrypt  &&  strcmp( format, "2.1" ) >= 0)
   {
      /* starting with format 2.1 there are 64 random bytes inserted at the beginning 
       * of the crypted table to prevent brute force decryption attempts.
       */

      randomisebuf64( buffer1 );

      /* read file into buffer1+64 */
      if (1 != fread( buffer1+64, size, 1, f ))
      {
	 fprintf( stderr, "cannot read temporary file for encryption and/or compression.\n" );
	 exit( 1 );
      }

      if (UFDBglobalDebug)
      {
	 fprintf( stderr, "crypt=yes and format=%s: read table and created randomised header: size was %ld\n", format, size );
      }

      size += 64;
      orig_size += 64;
   }
   else
   {
      /* read file into buffer1 */
      if (1 != fread( buffer1, size, 1, f ))
      {
	 fprintf( stderr, "cannot read file for encryption and/or compression.\n" );
	 exit( 1 );
      }

      if (UFDBglobalDebug)
         fprintf( stderr, "crypt=%d and format=%s: read table with size %ld\n", doCrypt, format, size );
   }

   /* make sure the 'result' is in buffer2 */
   if (doCompress)
      size = compressMemory( buffer2, buffer1, size );
   else
   {
      memcpy( buffer2, buffer1, size );
      if (UFDBglobalDebug)
         fprintf( stderr, "copied %ld bytes to buffer2\n", size );
   }

   /* crypt from buffer2 into buffer1 */
   if (doCrypt)
   {
      encryptMemory( buffer1, buffer2, size, (unsigned char *) encryptKey );
      if (UFDBglobalDebug)
         fprintf( stderr, "crypted %ld bytes from buffer2 to buffer1\n", size );
   }
   else
   {
      memcpy( buffer1, buffer2, size );
      if (UFDBglobalDebug)
         fprintf( stderr, "copied %ld bytes to buffer1\n", size );
   }

#if 0
   /* TODO fix the problem with 2.1 cksum */
   if (strcmp( format, "2.1" ) >= 0)
   {
      if (doCrypt)
	 cksum = UFDBcalcCksum( buffer1+64, size );
      else
	 cksum = UFDBcalcCksum( buffer1, size );
   }
#endif

   /* rewrite the file header and put the original size in there for the decompression function */
   updateSizeInHeader( f, orig_size, cksum );

   /* write buffer1 to the file */
   fseek( f, sizeof(struct UFDBfileHeader), SEEK_SET );

   if (1 != fwrite( buffer1, size, 1, f ))
   {
      fprintf( stderr, "cannot write crypted/compressed table to file: fwrite failed.\n" );
      exit( 2 );
   }
   fflush( f );

   if (UFDBglobalDebug)
      fprintf( stderr, "%ld bytes written back to file\n", size );

   /* truncate the file (if we did compression) */
   if (doCompress  &&  size < orig_size)
   {
      if (ftruncate( fileno(f), size + sizeof(struct UFDBfileHeader) ) < 0)
         fprintf( stderr, "failed to truncate compressed file to size %ld", (long) size + sizeof(struct UFDBfileHeader) );
   }

   free( buffer1 );
   free( buffer2 );
}


void convertSpecialCharacters( unsigned char * domain )
{
   unsigned char * s;
   unsigned char * d;

   for (s = domain, d = domain; *s != '\0'; s++)
   {
      if (*s == '%')
      {
         unsigned int hex;
	 unsigned int h1, h2;

	 h1 = *(s+1);
	 h2 = *(s+2);
	 if (isxdigit(h1) && isxdigit(h2))
	 {
	    hex  = (h1 <= '9') ? h1 - '0' : h1 - 'a' + 10;
	    hex *= 16;
	    hex += (h2 <= '9') ? h2 - '0' : h2 - 'a' + 10;
	    if (hex == 0)
	    {
	       s += 2;
	       continue;
	    }
	    else if (hex <= 0x20)
	    {
	       if (hex != '\t'  &&  hex != '\r'  &&  hex != '\n'  &&  hex != '\f')
		  hex = ' ';
	    }
	    else
	    {
	       if (hex == 0x7f  ||  hex == 0xff)
		  hex = ' ';
	       else
		  if (hex <= 'Z'  &&  hex >= 'A')
		     hex += 'a' - 'A';
	    }
	    *d++ = hex;
	    s += 2;
	 }
	 else
	    *d++ = *s;
      }
      else
      {
         *d++ = *s;
      }
   }
   *d = '\0';
}


int main( int argc, char * argv[] )
{
   int               n;
   int               opt;
   time_t            t;
   struct tm *       tm;
   char              encryptKey[16+1];
   char              key[16+3+1];
   char              flags[8+1];
   FILE *            fout;
   char *            fout_buffer;
   struct UFDBfileHeader header;
   UFDBthreadAdmin * admin;
   char              date[64];
   char              outFileName[512];
   char              tempOutFileName[512];
   unsigned char     domain[4096];

   UFDBappInit();
   admin = UFDBallocThreadAdmin();
   inFileName = NULL;
   urlsFileName = NULL;
   tableName = "defaulttable";
   encryptKey[0] = '\0';

   while ((opt = getopt( argc, argv, "DF:k:t:d:u:nCqPsVW?X" )) > 0)
   {
      switch (opt)
      {
      case 'D':
      	 UFDBglobalDebug++;
	 break;
      case 'F':
         format = optarg;
	 if (strcmp( format, "1.2" ) != 0  &&  
	     strcmp( format, "2.0" ) != 0  &&
	     strcmp( format, "2.1" ) != 0)
	 {
	    fprintf( stderr, "-F option only accepts 1.2, 2.0 and 2.1 as format specifiers\n" );
	    usage();
	 }
	 break;
      case 't':
         tableName = optarg;
	 break;
      case 'd':
         inFileName = optarg;
	 break;
      case 's':
      	 doSanityCheck = 1;
	 break;
      case 'u':
         urlsFileName = optarg;
	 break;
      case 'k':
         strncpy( encryptKey, optarg, 16 );
	 encryptKey[16] = '\0';
	 if (strlen( encryptKey ) != 16)
	 {
	    fprintf( stderr, "key \"%s\" is not valid.\n", encryptKey );
	    usage();
	 }
	 break;
      case 'n':
         doCrypt = 0;
	 break;
      case 'P':
         doProd = 1;
	 break;
      case 'C':
         doCompress = 1;
	 break;
      case 'q':
         doWarnings = 0;
	 break;
      case 'V':
         printf( "ufdbGenTable version " VERSION "\n" );
	 printf( "The ufdbGuard software suite is free and Open Source Software.\n" );
	 printf( "Copyright (C) 2005-2015 by URLfilterDB and others.\n" );
	 exit( 0 );
      case 'W':
         stripWWW = 1;
	 break;
      case 'X':
         skipOptimisations = 1;
	 break;
      case '?':
	 fprintf( stderr, "help:\n" );
         usage();
	 break;
      default:
	 fprintf( stderr, "internal error: getopt returned \"%c\"\n", opt );
         usage();
	 break;
      }
   }

   if (strlen(tableName) > 15)
   {
      tableName[15] = '\0';
      fprintf( stderr, "warning: the tableName is truncated to \"%s\"\n", tableName );
   }

   if (inFileName == NULL)
   {
      fprintf( stderr, "the input file name is not specified: use the -d option\n" );
      usage();
   }

   fin = fopen( inFileName, "r" );
   if (fin == NULL)
   {
      fprintf( stderr, "cannot read from \"%s\": %s\n", inFileName, strerror(errno) );
      usage();
   }
   if (UFDBglobalDebug)
      fprintf( stderr, "processing domains from file \"%s\"\n", inFileName );

   strcpy( outFileName, inFileName );
   strcat( outFileName, UFDBfileSuffix );

   strcpy( tempOutFileName, outFileName );
   strcat( tempOutFileName, ".temp" );

   fout = fopen( tempOutFileName, "w+" );
   if (fout == NULL)
   {
      fprintf( stderr, "cannot write to \"%s\": %s\n", tempOutFileName, strerror(errno) );
      usage();
   }
   if (UFDBglobalDebug)
      fprintf( stderr, "opened temporary file \"%s\"\n", tempOutFileName );
   fout_buffer = malloc( 16384 );
   setvbuf( fout, fout_buffer, _IOFBF, 16384 );

   /* setlinebuf( stderr ); */
   initTable( tableName );


   /* process the domains ********************************************/
   n = 0;
readdomains:
   while (!feof(fin))
   {
      int             last_char;
      unsigned char * ptr;

      ptr = domain;

      while ((*ptr = last_char = myfast_getc(fin)) != '\n')
      {
	 /* check for a last line without \n */
         if (last_char == EOF)
	 {
	    if (ptr != domain)
	       break;
	    goto eof;
	 }
	 if (last_char == '\r')
	    continue;
	 if (last_char <= 'Z'  &&  last_char >= 'A')
	    *ptr = last_char + ('a' - 'A');
	 else if (last_char < ' ')			/* illegal control character in URL */
	 {
	    if (doWarnings)
	       fprintf( stderr, "illegal control character in URL: %s\n", domain );
	    *ptr = '\0';
	    while (!feof(fin) && myfast_getc(fin) != '\n')
	       ;
	    break;
	 }
	 ptr++;
	 if (ptr > &domain[4090])
	 {
	    *ptr = '\0';
	    fprintf( stderr, "URL too long: %s\n", domain );
	    while (!feof(fin) && myfast_getc(fin) != '\n')
	       ;
	    goto readdomains;
	 }
      }
      *ptr = '\0';

      if (domain[0] != '\0'  &&  domain[0] != '#')
      {
	 char * first_slash;

         if (domain[0] == 'w' && domain[1] == 'w' && domain[2] == 'w' && domain[3] == '.' && strchr( (char*) domain+4, '.' ) != NULL)
	 {
	    if (stripWWW)
	    {
	       if (doWarnings)
		  fprintf( stderr, "notice: \"www.\" is stripped for %s\n", domain );
	    }
	    else if (doWarnings)
	    {
	       fprintf( stderr, "warning: domain name starts with \"www.\": %s (use -W option ?)\n", domain );
	    }
	 }

	 if (doWarnings)
	 {
	    if (ptr - domain > 66)
	       fprintf( stderr, "warning: long domain name: %s\n", domain );
	 }

	 first_slash = strchr( (char *) domain, '/' );
	 if (first_slash != NULL)
	    fprintf( stderr, "warning: domain name (%s) has a '/' ?!?!\n", domain );
	 if (doWarnings  &&  !UFDBsanityCheckDomainname( (char *) domain ))
	    fprintf( stderr, "warning: illegal domain name: %s\n", domain );
	 addDomain( admin, (char *) domain, UFDBdomain );
      }
   }
eof:
   fclose( fin );

   /* process the urls ***********************************************/
   if (urlsFileName != NULL)
   {
      fin = fopen( urlsFileName, "r" );
      if (fin == NULL)
      {
	 fprintf( stderr, "cannot read from \"%s\": %s\n", urlsFileName, strerror(errno) );
	 usage();
      }
      if (UFDBglobalDebug)
	 fprintf( stderr, "processing urls from file \"%s\"\n", urlsFileName );

readurls:
      while (!feof(fin))
      {
         int             last_char;
	 unsigned char * ptr;
	 unsigned char * first_slash;

	 ptr = domain;

	 while ((*ptr = last_char = myfast_getc(fin)) != '\n')
	 {
	    /* check for a last line without \n */
	    if (last_char == EOF)
	    {
	       if (ptr != domain)
		  break;
	       goto eof2;
	    }
	    if (last_char == '\r')		/* Skip '\r' */
	       continue;
	    if (last_char <= 'Z'  &&  last_char >= 'A')
	       *ptr = last_char + ('a' - 'A');
	    else if (last_char < ' ')			/* illegal control character in URL */
	    {
	       if (doWarnings)
		  fprintf( stderr, "illegal control character in URL: %s\n", domain );
	       *ptr = '\0';
	       while (!feof(fin) && myfast_getc(fin) != '\n')
		  ;
	       break;
	    }
	    ptr++;
	    if (ptr > &domain[4090])
	    {
	       *ptr = '\0';
	       fprintf( stderr, "URL too long: %s\n", domain );
	       while (!feof(fin) && myfast_getc(fin) != '\n')
		  ;
	       goto readurls;
	    }
	 }
	 *ptr = '\0';

	 if (domain[0] != '\0'  &&  domain[0] != '#')
	 {
	    convertSpecialCharacters( domain );

	    first_slash = (unsigned char *) strchr( (char *) domain, '/' );
	    if (first_slash == NULL)
	    {
	       if (doWarnings) 
	       {
	          fprintf( stderr, "warning: URL has no '/': %s\n", domain );
		  if (strlen( (char *) domain ) > 66)
		     fprintf( stderr, "warning: long domainname in URL: %s\n", domain );
	       }
	    }
	    else
	    {
	       char * sep;
	       int    pathlen;

	       if (doWarnings)
	       {
		  sep = strchr( (char *) first_slash, '?' );
		  if (sep != NULL)
		  {
		     fprintf( stderr, "warning: URL has a dynamic structure with '?'.  URL: %s\n", domain );
		  }
#if 0
		  else
		  {
		     sep = strchr( (char *) first_slash, ';' );
		     if (sep != NULL)
		     {
			fprintf( stderr, "warning: URL has a dynamic structure with '?', ';' and '&'.  URL: %s\n", domain );
		     }
		     else
		     {
			sep = strchr( (char *) first_slash, '&' );
			if (sep != NULL)
			{
			   fprintf( stderr, "warning: URL has a dynamic structure with '?', ';' and '&'.  URL: %s\n", domain );
			}
		     }
		  }
#endif
	       }

	       pathlen = strlen( (char *) first_slash );
	       if (doWarnings) 
	       {
		  if (first_slash - &domain[0] > 66)
		     fprintf( stderr, "warning: long domainname in URL: %s\n", domain );
		  if (pathlen > 127)
		     fprintf( stderr, "warning: long path in URL: %s\n", domain );
	       }
	       if (pathlen >= sizeof(UFDBurlPart))
	       {
		  if (doWarnings)
		  {
		     fprintf( stderr, "*** very long URL: %s\n", domain );
		     fprintf( stderr, "*** the long URL is being truncated (max path length = %d) !\n", (int) sizeof(UFDBurlPart)-1 );
		  }
		  *( first_slash + sizeof(UFDBurlPart) - 1 - 1) = '\0';
	       }
	    }

            if (domain[0] == 'w' && domain[1] == 'w' && domain[2] == 'w' && domain[3] == '.' && strchr( (char*) domain+4, '.' ) != NULL)
	    {
	       if (stripWWW)
	       {
		  if (doWarnings)
		     fprintf( stderr, "notice: \"www.\" is stripped for %s\n", domain );
	       }
	       else if (doWarnings)
	       {
		  fprintf( stderr, "warning: URL name starts with \"www.\": %s (use -W option ?)\n", domain );
	       }
	    }

	    if (doWarnings  &&  !UFDBsanityCheckDomainname( (char *) domain ))
	       fprintf( stderr, "warning: illegal domain name: %s\n", domain );
	    addDomain( admin, (char *) domain, UFDBurl );
	 }
      }
eof2:
      fclose( fin );
   }

   if (encryptKey[0] == '\0')
      generateRandomKey( encryptKey );
   copyKey( key, encryptKey );

   if (format[0] != '1')
   {
      calcIndexSize( table );
      numIndexNodes = numNodes - numLeafNodes;
      if (UFDBglobalDebug)
	 fprintf( stderr, "#nodes: %9d   #leafs: %9d   #index: %9d\n",
		  numNodes, numLeafNodes, numIndexNodes );
   }

   /* write the table header to the output file */
   strcpy( flags, "--------" );
   if (doCompress)
      flags[0] = 'C';
   if (doProd)
      flags[1] = 'P';
   if (doCrypt)
      flags[2] = 'Q';
   t = time( NULL );
   tm = gmtime( &t );
   sprintf( date, "%4d%02d%02d.%02d%02d", 
            tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday, tm->tm_hour, tm->tm_min );
   sprintf( header.string, "%s %s %s %d key=%s date=%s %8s %d \n",
            "UFDB", format, tableName, numEntries, key, date, flags, numNodes );
   fprintf( fout, "%s", header.string );
   for (n = sizeof(header.string) - strlen(header.string); n > 0; n--)
      myfast_putc( '\0', fout );

   /* write the table in binary format to the output file */
   if (strcmp( format, "1.2" ) == 0)
      writeTableToFile_1_2( table, fout );
   else if (strcmp( format, "2.0" ) == 0)
      writeTableToFile_2_0( table, fout );
   else
      writeTableToFile_2_1( table, fout );
   myfast_putc( UFDBendTable, fout );

   /* when SSE and AVX/AVX2 instructions are used we need a 16-byte safeguard */
   for (n = 0; n < 32; n++)
      myfast_putc( UFDBendTable, fout );

   /* encrypt and compress the table: rewind, read, compress, crypt and write */
   if (doCrypt || doCompress)
   {
      doCryptCompress( fout, encryptKey, format );
   }

   fclose( fout );
   free( fout_buffer );

   /* to get around some permission problems: unlink before rename */
   if (unlink( outFileName ) < 0  &&  errno != ENOENT)
      fprintf( stderr, "cannot remove \"%s\": %s\n", outFileName, strerror(errno) );
   if (rename( tempOutFileName, outFileName ) != 0)
   {
      fprintf( stderr, "cannot rename '%s' into '%s': %s\n", tempOutFileName, outFileName, strerror(errno) );
      (void) unlink( tempOutFileName );
   }
   else if (UFDBglobalDebug)
      fprintf( stderr, "temporary file \"%s\" renamed to \"%s\"\n", tempOutFileName, outFileName );

   return 0;
}


/* since ufdbguard (single-threaded) and ufdbguardd (multi-threaded)
 * share source code, we put some pthread dummys here since we don't need/want pthreads.
 */
int pthread_mutex_lock( pthread_mutex_t * mutex )
{
   return 0;
}

int pthread_mutex_trylock( pthread_mutex_t * mutex )
{
   return 0;
}

int pthread_mutex_unlock( pthread_mutex_t * mutex )
{
   return 0;
}


int pthread_cond_signal(pthread_cond_t *cond)
{
   return 0;
}

int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex)
{
   return 0;
}

