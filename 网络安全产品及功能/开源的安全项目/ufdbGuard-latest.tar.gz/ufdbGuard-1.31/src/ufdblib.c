/*
 * ufdblib.c - URLfilterDB
 *
 * ufdbGuard is copyrighted (C) 2005-2013 by URLfilterDB with all rights reserved.
 *
 * Parts of ufdbGuard are based on squidGuard.
 * This module is NOT based on squidGuard.
 *
 * RCS $Id: ufdblib.c,v 1.107 2015/06/09 02:23:28 root Exp root $
 */

/* This module is well tested and stable for a long time.
 * For maximum performance _FORTIFY_SOURCE is undefined.
 */
#undef _FORTIFY_SOURCE

/* to inline string functions with gcc : */
#if defined(__OPTIMIZE__) && defined(__GNUC__)  &&  defined(GCC_INLINE_STRING_FUNCTIONS_ARE_FASTER)
#define __USE_STRING_INLINES  1
#endif

#include "ufdb.h"
#include "ufdblib.h"

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <pthread.h>
#include <syslog.h>
#include <time.h>
/* TODO: evaluate use of syslog() */
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#if HAVE_UNIX_SOCKETS
#include <sys/un.h>
#endif
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/ip6.h>
#include <arpa/inet.h>


/* #define  UFDB_DEBUG_IPV6 */

/* #define UFDB_DO_DEBUG 1 */
#define UFDB_DO_DEBUG 0

#if UFDB_DO_DEBUG || 0
#define DEBUG(x) fprintf x 
#else
#define DEBUG(x) 
#endif


void UFDBappInit( void )
{
   ;
}


void UFDBtimerInit( struct tms * t )
{
   (void) times( t );
}


void UFDBtimerStop( struct tms * t )
{
   struct tms te;

   (void) times( &te );

   t->tms_utime  = te.tms_utime  - t->tms_utime;
   t->tms_stime  = te.tms_stime  - t->tms_stime;
   t->tms_cutime = te.tms_cutime - t->tms_cutime;
   t->tms_cstime = te.tms_cstime - t->tms_cstime;
}


void UFDBtimerPrintString( char * line, struct tms * t, char * tag )
{
   double  numTicks;

   numTicks = (double) sysconf( _SC_CLK_TCK );

   if (tag == NULL)
      tag = "UFDB timer";

   sprintf( line, "%s:  %5.2f user  %5.2f sys  %5.2f total", 
	    tag,
            (double) t->tms_utime / numTicks, 
	    (double) t->tms_stime / numTicks, 
	    (double) (t->tms_utime+t->tms_stime) / numTicks );
}


void UFDBtimerPrint( struct tms * t, char * tag )
{
   char    line[256];

   UFDBtimerPrintString( line, t, tag );
   fprintf( stderr, "%s\n", line );
   fflush( stderr );
}


static pthread_mutex_t mutex_url_history = UFDB_STATIC_MUTEX_INIT;
static char *          url_history = NULL;
static volatile long   url_history_index = 0;


/* Store the name of a webserver in the url_history buffer.
 * Return 1 if the buffer is full, 0 otherwise.
 */
int ufdbRegisterUnknownURL( 
   char * webserver,
   int    portnumber )
{
   int    length;
   char   b[UFDB_MAX_URL_LENGTH+5];

   if (url_history_index >= URL_HIST_SIZE - 8)
      return 1;

   /* webserver names that do not have a dot (.) have no domain name          */
   /* and can never be incorporated in the URL database and are skipped here. */
   if (webserver == NULL  ||  strchr( webserver, '.' ) == NULL)
      return 0;

   b[0] = '\0';
   length = strlen( webserver );

   pthread_mutex_lock( &mutex_url_history );

   if (url_history == NULL)
   {
      url_history = ufdbMalloc( URL_HIST_SIZE );
      url_history[0] = '\0';
   }

   /* check for buffer overflow */
   if (url_history_index + length >= URL_HIST_SIZE - 8)
   {
      url_history_index = URL_HIST_SIZE;
      pthread_mutex_unlock( &mutex_url_history );
      return 1;
   }

   /* almost perfect optimisation for duplicates */
   if (length <= 500)
   {
      if (portnumber == 80)
	 (void) sprintf( b, "|%s|", webserver );
      else
	 (void) sprintf( b, "|%s:%d|", webserver, portnumber );
      if (strstr( url_history, b ) != NULL)
      {
	 pthread_mutex_unlock( &mutex_url_history );
	 return 0;
      }
   }
   else
   {
      /* TODO: deal with very long URLs in ufdbRegisterUnknownURL */
      pthread_mutex_unlock( &mutex_url_history );
      return 0;
   }

   strcpy( &(url_history[url_history_index]), webserver );
   url_history_index += length;
   if (portnumber != 80)
   {
      url_history_index += sprintf( &(url_history[url_history_index]), ":%d", portnumber );
   }
   url_history[url_history_index] = '|';
   url_history_index++;
   url_history[url_history_index] = '\0';

   pthread_mutex_unlock( &mutex_url_history );

   return 0;
}


/*
 * Retrieve all registered uncategorised URLs.
 * This must be followed by a ufdbResetUnknownURLs().
 */
char * ufdbGetUnknownURLs( void )
{
   pthread_mutex_lock( &mutex_url_history );
   url_history_index = URL_HIST_SIZE + 2;		/* prevent additions until reset */
   pthread_mutex_unlock( &mutex_url_history );

   return url_history;
}


void ufdbResetUnknownURLs( void )
{
   pthread_mutex_lock( &mutex_url_history );

   if (url_history == NULL)
      url_history = ufdbMalloc( URL_HIST_SIZE );
   url_history[0] = '\0';
   url_history_index = 0;

   pthread_mutex_unlock( &mutex_url_history );
}


int UFDBopenSocket( char * serverName, int port )
{
   int                 s;
   int                 ret;
   int                 sock_parm;
   long                oldflags;
   struct sockaddr_in  addr;
   struct timeval      tv;
   time_t              t0, t;
#if HAVE_GETADDRINFO==0  &&  defined(__linux__) && HAVE_GETHOSTBYNAME_R>0
   char                buffer[1024];
   struct hostent *    result;
#endif
#if HAVE_GETADDRINFO
   struct addrinfo     addrinfo_hints;
   struct addrinfo *   addrinfo;
#endif

#if HAVE_GETADDRINFO
   addrinfo = NULL;
   addrinfo_hints.ai_flags = 0;
   addrinfo_hints.ai_family = AF_INET;
   addrinfo_hints.ai_socktype = SOCK_STREAM;
   addrinfo_hints.ai_protocol = IPPROTO_TCP;
   addrinfo_hints.ai_addrlen = 0;
   addrinfo_hints.ai_addr = NULL;
   addrinfo_hints.ai_canonname = NULL;
   addrinfo_hints.ai_next = NULL;

   t0 = time( NULL );
   ret = getaddrinfo( serverName, NULL, &addrinfo_hints, &addrinfo );
   if (ret != 0)
   {
      t = time( NULL );
      if (t - t0 >= 4)
	 ufdbLogError( "cannot resolve hostname %s: %s.  getaddrinfo took %ld seconds to return. Is the DNS server OK?", serverName, gai_strerror(ret), (t - t0) );
      else
	 ufdbLogError( "cannot resolve hostname %s: %s", serverName, gai_strerror(ret) );
      return -1;
   }

   memcpy( (void *) &addr, (void *) addrinfo->ai_addr, sizeof(addr) );  
   addr.sin_family = AF_INET;
   addr.sin_port = htons( port );

   if (UFDBglobalDebug > 1  ||  UFDBglobalPeek)
   {
      char addrbuf[INET_ADDRSTRLEN+1];

      if (inet_ntop( AF_INET, &((struct sockaddr_in *) addrinfo->ai_addr)->sin_addr, addrbuf, INET_ADDRSTRLEN+1 ) == NULL)
         strcpy( addrbuf, "unknown" );
      ufdbLogMessage( "UFDBopenSocket: '%s' resolved to '%s'", serverName, addrbuf );
   }

   freeaddrinfo( addrinfo );

#else

#if defined(__linux__) && HAVE_GETHOSTBYNAME_R>0
   {
      struct hostent      server;
      int                 my_errno;

      /* 
       * check the server name.
       */
      my_errno = 0;
      ret = gethostbyname_r( serverName, &server, buffer, sizeof(buffer)-1, &result, &my_errno );
      if (ret != 0)
      {
	 ufdbLogError( "cannot resolve hostname %s: %s", serverName, strerror(my_errno) );
	 return -1;
      }

      addr.sin_family = AF_INET;
      memcpy( (void *) &addr.sin_addr, (void *) server.h_addr_list[0], sizeof(addr.sin_addr) );  
      addr.sin_port = htons( port );
   }

#else

#if HAVE_GETIPNODEBYNAME
   {
      struct hostent *    server_ptr;
      int                 my_errno;

      my_errno = 0;
      server_ptr = getipnodebyname( serverName, AF_INET, 0, &my_errno );
      if (server_ptr == NULL)
      {
	 ufdbLogError( "cannot resolve hostname %s: %s", serverName, strerror(my_errno) );
	 return -1;
      }

      addr.sin_family = AF_INET;
      memcpy( (void *) &addr.sin_addr, (void *) server_ptr->h_addr_list[0], sizeof(addr.sin_addr) );  
      addr.sin_port = htons( port );

      freehostent( server_ptr );
      /* #error *TEST* HAVE_GETIPNODEBYNAME   TODO */
   }

#else

   {
      struct hostent *       server_ptr;
      static pthread_mutex_t gethostbyname_mutex = UFDB_STATIC_MUTEX_INIT;

      ret = pthread_mutex_lock( &gethostbyname_mutex );
#ifdef UFDB_DEBUG
      if (ret != 0)
	 ufdbLogError( "UFDBopenSocket: mutex_lock failed" );
#endif

      /*
       * check the server name.
       */
      errno = 0;
      server_ptr = gethostbyname( serverName );		/* obsolete and not threadsafe */
      if (server_ptr == NULL)
      {
	 ufdbLogError( "cannot resolve hostname %s: %s", serverName, hstrerror(h_errno) );
	 ret = pthread_mutex_unlock( &gethostbyname_mutex );
#ifdef UFDB_DEBUG
	 if (ret != 0)
	    ufdbLogError( "UFDBopenSocket: mutex_unlock failed" );
#endif
	 return -1;
      }

      addr.sin_family = AF_INET;
      memcpy( (void *) &addr.sin_addr, (void *) server_ptr->h_addr_list[0], sizeof(addr.sin_addr) );  
      addr.sin_port = htons( port );

      ret = pthread_mutex_unlock( &gethostbyname_mutex );
#ifdef UFDB_DEBUG
      if (ret != 0)
	 ufdbLogError( "UFDBopenSocket: mutex_unlock failed" );
#endif
   }

#endif
#endif
#endif

   /*
    * create the socket to connect to the daemon.
    */
   s = socket( AF_INET, SOCK_STREAM, 0 );
   if (s < 0)
      return -1;

   /*
    *  Prevent that the connect takes ages.  Use an aggressive timeout of 5 seconds.
    */
   tv.tv_sec = 5;
   tv.tv_usec = 0;
   setsockopt( s, SOL_SOCKET, SO_RCVTIMEO, (void *) &tv, sizeof(tv) );
   tv.tv_sec = 5;
   tv.tv_usec = 0;
   setsockopt( s, SOL_SOCKET, SO_SNDTIMEO, (void *) &tv, sizeof(tv) );

   sock_parm = 180 * 1024;
   setsockopt( s, SOL_SOCKET, SO_SNDBUF, (void *) &sock_parm, sizeof(sock_parm) );

   /* The RCVTIMEO and SNDTIMEO do not work on all OSes (e.g. Solaris) so
    * we will set the socket in non-blocking mode, use select with a timeout and 
    * check the socket status for successful connection.
    * After this, the socket goes back to blocking mode.
    */
   oldflags = fcntl( s, F_GETFL, NULL );
   if (oldflags < 0)
      oldflags = 0;	/* ignore errors */
   if (fcntl( s, F_SETFL, oldflags|O_NONBLOCK ))
      ;

   /* with anti-aliasing warnings ON, connect/bind cause compiler warnings which we may ignore */
   if (connect( s, (struct sockaddr *) &addr, sizeof(addr) ) < 0)
   {
      if (errno == EINPROGRESS)
      {
	 int rv;
	 fd_set fdset;
	 /* tv is already set to 5 seconds */
	 FD_ZERO( &fdset );
	 FD_SET( s, &fdset );
	 errno = 0;
         rv = select( s+1, NULL, &fdset, NULL, &tv );
	 if (rv < 0)
	 {
	    /* error; fall through */
	 }
	 else if (rv == 0)
	 {
	    /* timed out; fall through */
	    errno = ETIMEDOUT;
	 }
	 else
	 {
	    /* select() signalled that there is I/O. check socket error status */
	    int errorStatus;
	    socklen_t len;
	    len = sizeof(int);
	    if (getsockopt( s, SOL_SOCKET, SO_ERROR, (void *) &errorStatus, &len ) == 0)
	    {
	       if (!errorStatus)
	       {
		  /* go back to blocking mode */
		  if (fcntl( s, F_SETFL, oldflags ))
		     ;
	          goto socket_ok;
	       }
	       /* error; fall through */
	       if (errno == 0)
		  errno = ECONNREFUSED;
	    }
	    else
	    {
	       /* error; fall through */
	    }
	 }
      }
      if (errno == EINPROGRESS)
         errno = EAGAIN;
      ufdbLogError( "cannot connect to %s port %d: %s", serverName, port, strerror(errno) );
      close( s );
      s = -1;
   }

   if (s >= 0)
   {
socket_ok:
      /*
       *  Prevent long blocking on communication with the daemon.
       */
      tv.tv_sec = 20;
      tv.tv_usec = 0;
      setsockopt( s, SOL_SOCKET, SO_RCVTIMEO, (void *) &tv, sizeof(tv) );

      tv.tv_sec = 20;
      tv.tv_usec = 0;
      setsockopt( s, SOL_SOCKET, SO_SNDTIMEO, (void *) &tv, sizeof(tv) );
   }

   return s;
}


static int UFDBnormaliseIPv6( 
   const char * address,
   char *       normalised )
{
   struct in6_addr ipv6;

   *normalised = '\0';

   if (inet_pton( AF_INET6, address, (void *) &ipv6 ) <= 0)
      return 0;

   if (inet_ntop( AF_INET6, (void *) &ipv6, normalised, INET6_ADDRSTRLEN ) == NULL)
      return 0;

#ifdef UFDB_DEBUG_IPV6
   fprintf( stderr, "      UFDBnormaliseIPv6  %s  ->  %s\n", address, normalised );
#endif

   return 1;	/* successful */
}


char * UFDBparseIPv6address( 
   char * url,
   char * domain )
{
   char * url_start;
   char * d;
   char   normalisedAddress[INET6_ADDRSTRLEN];

#ifdef UFDB_DEBUG_IPV6
   fprintf( stderr, "   UFDBparseIPv6address: url: %s\n", url );
#endif

   url_start = url;
   *domain = '\0';
   d = domain;
   if (*url == '[')
   {
      url++;
   }
   
   while (*url != '\0')
   {
      if (*url == ']')
      {
	 *d++ = ']';
	 *d = '\0';
	 if (UFDBnormaliseIPv6( domain, normalisedAddress ))
	    strcpy( domain, normalisedAddress );
	 else
	 {
	    if (UFDBglobalDebug)
	        ufdbLogMessage( "URL has invalid IPv6 address: %s", *url_start=='[' ? url_start+1 : url_start );
	    return NULL;
	 }
	 /* TODO: handle IPv4 in IPv6 addresses e.g.  ::127.0.0.1 */
	 return url;
      }

      if (*url == ':'  ||  *url == '.'  ||  isxdigit(*url))
      {
         *d++ = *url++;
      }
      else	/* URL address error */
      {
	 *d = '\0';
	 if (UFDBglobalDebug)
	     ufdbLogMessage( "URL has invalid IPv6 address: %s", *url_start=='[' ? url_start+1 : url_start );
         return NULL;
      }
   }
   *d = '\0';

#ifdef UFDB_DEBUG_IPV6
   fprintf( stderr, "   UFDBparseIPv6address: domain: %s\n", domain );
#endif

   if (UFDBnormaliseIPv6( domain, normalisedAddress ))
   {
#ifdef UFDB_DEBUG_IPV6
      fprintf( stderr, "      IPv6 domain '%s' normalised to '%s'\n", domain, normalisedAddress );
#endif
      strcpy( domain, normalisedAddress );
   }
   else
   {
      if (UFDBglobalDebug)
	  ufdbLogMessage( "URL has invalid IPv6 address: %s", *url_start=='[' ? url_start+1 : url_start );
      return NULL;  /* address error */
   }

   /* TODO: handle IPv4 in IPv6 addresses e.g.  ::127.0.0.1 */
   return url;
}


void UFDBupdateURLwithNormalisedDomain(
   char * url,
   char * newDomain )
{
#ifdef UFDB_DEBUG_IPV6
   char * oldURL;
#endif
   char * oldEnd;
   int    n;
   int    nbytes;

#ifdef UFDB_DEBUG_IPV6
   oldURL = url;
   fprintf( stderr, "      UFDBupdateURLwithNormalisedDomain: %s\n", url );
#endif

   if (*url != '[')
   {
      ufdbLogError( "UFDBupdateURLwithNormalisedDomain: URL does not start with '[': %s", url );
      return;
   }
   url++;

   oldEnd = strchr( url, ']' );
   if (oldEnd == NULL)
   {
      ufdbLogError( "UFDBupdateURLwithNormalisedDomain: URL does not have a ']': %s", url );
      return;
   }

   while (1)
   {
      if (*url == ']')
      {
         if (*newDomain == '\0')	/* the normalised domain name has equal length */
	    return;
	 /* the newDomain string is longer than the original */
	 n = strlen( newDomain );
	 nbytes = strlen( url ) + 1;
	 memmove( url+n, url, nbytes );
	 while (*newDomain != '\0')
	    *url++ = *newDomain++;
	 return;
      }

      if (*newDomain == '\0')
      {
         /* the newDomain string is shorter than the original */
	 nbytes = strlen( oldEnd ) + 1;
	 memmove( url, oldEnd, nbytes );
#ifdef UFDB_DEBUG_IPV6
         fprintf( stderr, "      UFDBupdateURLwithNormalisedDomain: %s\n", oldURL );
#endif
	 return;
      }

      *url++ = *newDomain++;
   }
}


void UFDBnormaliseIPv4( char * domain )
{
   char *       d;
   char *       orig;
   unsigned int octetvalue;
   char         dbuf[512];

   orig = domain;
   d = dbuf;
   while (*domain != '\0')
   {
      if (*domain == '0')
      {
	 domain++;
	 octetvalue = 0;
         if (*domain == 'x')				/* obfuscated hexadecimal octet */
	 {
	    domain++;
	    while (isxdigit(*domain))
	    {
	       octetvalue *= 16;
	       if (*domain >= '0' && *domain <= '9')
	          octetvalue += (*domain - '0');
	       else
	          octetvalue += (*domain - 'a' + 10);
	       domain++;
	    }
	    if (*domain != '\0'  &&  *domain != '.')
	    {
	       ufdbLogError( "IPv4 address has illegal hexadecimal octet: %s", orig );
	       return;
	    }
	 }
	 else if (*domain >= '0'  &&  *domain <= '7')	/* obfuscated octal octet */
	 {
	    while (*domain >= '0'  &&  *domain <= '7')
	    {
	       octetvalue *= 8;
	       octetvalue += (*domain - '0');
	       domain++;
	    }
	    if (*domain != '\0'  &&  *domain != '.')
	    {
	       ufdbLogError( "IPv4 address has illegal octal octet: %s", orig );
	       return;
	    }
	 }
	 else
	 {
	    ufdbLogError( "IPv4 address has illegal octet: %s", orig );
	    return;
	 }
	 if (octetvalue > 255)
	 {
	    ufdbLogError( "obfuscated IPv4 address has illegal octet value: %s", orig );
	    return;
	 }
	 /* convert the octetvalue to a decimal string */
	 d += sprintf( d, "%u", octetvalue );
      }
      else				/* octet is not obfuscated */
      {
         while (*domain != '\0'  &&  *domain != '.')
	    *d++ = *domain++;
      }

      if (*domain == '.')
	 *d++ = *domain++;
   }
   *d = '\0';

   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "obfuscated domain %s rewritten to %s", orig, dbuf );

   strcpy( orig, dbuf );
}


int UFDBaddYoutubeEdufilter(
   char * domain,
   char * strippedURL,
   char * originalURL  )
{
   char * dot;

   if (strcmp( domain, "youtube.com" ) == 0)
   {
#if 0
      ufdbLogMessage( "   YouTube Edufilter: %s %s", domain, strippedURL );
#endif
      dot = strrchr( strippedURL, '.' );
      if (dot == NULL)
      {
	 if (strchr( strippedURL, '?' ) == NULL)
	    strcat( originalURL, "?edufilter=" );
	 else
	    strcat( originalURL, "&edufilter=" );
	 strcat( originalURL, UFDBglobalYoutubeEdufilterID );

	 return UFDB_API_MODIFIED_FOR_YOUTUBE_EDUFILTER;
      }
      else
      {
	 if (strcmp( dot+1, "css" ) != 0  &&
	     strcmp( dot+1, "ico" ) != 0  &&
	     strcmp( dot+1, "gif" ) != 0  &&
	     strcmp( dot+1, "jpg" ) != 0  &&
	     strcmp( dot+1, "png" ) != 0  &&
	     strcmp( dot+1, "js" )  != 0  &&
	     strcmp( dot+1, "xml" ) != 0)
	 {
	    if (strchr( dot, '?' ) == NULL)
	       strcat( originalURL, "?edufilter=" );
	    else
	       strcat( originalURL, "&edufilter=" );
	    strcat( originalURL, UFDBglobalYoutubeEdufilterID );

	    return UFDB_API_MODIFIED_FOR_YOUTUBE_EDUFILTER;
	 }
      }
   }

   return UFDB_API_OK;
}


/*
 * UFDBaddSafeSearch - modify a URL for a search which requires SafeSearch
 *
 * return UFDB_API_OK for unmodified URLs and UFDB_API_MODIFIED_FOR_SAFESEARCH
 *
 * parameters: domain - the domainname
 *             strippedURL - the stripped URL including the domainname
 *             originalURL - the unmodified user-supplied URL
 *	       The originalURL must be of type char[UFDB_MAX_URL_LENGTH]
 *	       and may be modified to force SafeSearch.
 */
int UFDBaddSafeSearch(
   char * domain,
   char * strippedURL,
   char * originalURL  )
{
   char * slash;

   originalURL[UFDB_MAX_URL_LENGTH-28] = '\0';

   slash = strchr( strippedURL, '/' );
   if (slash == NULL)
      strippedURL = "";
   else
      strippedURL = slash;

#if 0
   printf( "   SS: %s %s\n", domain, strippedURL );
#endif

   if (strstr( domain, "similar-images.googlelabs." ) != NULL  &&	/* Google images */
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active&safeui=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "images.google." ) != NULL  &&			/* Google images */
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active&safeui=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "youtube.com" ) != NULL  &&			/* Youtube */
       strstr( strippedURL, "search_query=") != NULL)
   {
      strcat( originalURL, "&safety_mode=true" );			/* unfortunately this does not work since */
      UFDB_API_num_safesearch++;					/* also need to set Cookie: (.*) PREF=f2=8000000 */
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((domain[0] <= '9' && domain[0] >= '0')  &&			/* google-related sites like www.google-tr.info */
       strstr( strippedURL, "cx=partner" ) != NULL  &&
       strstr( strippedURL, "/cse" ) != NULL  &&
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((domain[0] <= '9' && domain[0] >= '0')     &&			/* google.com, google.de, google.ws etc. */
       strncmp( strippedURL, "/search", 7 ) == 0  &&
       strstr( strippedURL, "q=" ) != NULL        &&
       (strncmp( domain, "74.125.", 7 ) == 0  ||
        strncmp( domain, "173.194.", 8 ) == 0))
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((strstr( domain, "google." ) != NULL  ||				/* SAFESEARCH: google.* */
        strcmp( domain, "ajax.googleapis.com" ) == 0  ||
        strstr( domain, "googleusercontent.com" ) != NULL)  &&		/* Google */
       strstr( strippedURL, "q=" ) != NULL  &&
       ((strncmp( strippedURL, "/insights", 9 ) != 0  &&  strstr( strippedURL, "/search" ) != NULL)  ||
        strstr( strippedURL, "/uds/afs" ) != NULL ||
        strstr( strippedURL, "/uds/gwebsearch" ) != NULL ||
        strstr( strippedURL, "/uds/gvideosearch" ) != NULL ||
        strstr( strippedURL, "/uds/gimagesearch" ) != NULL ||
        strstr( strippedURL, "/uds/gblogsearch" ) != NULL ||
        strstr( strippedURL, "/videosearch" ) != NULL ||
        strstr( strippedURL, "/blogsearch" ) != NULL ||
        strstr( strippedURL, "/gwebsearch" ) != NULL ||
        strstr( strippedURL, "/groups" ) != NULL ||
        strstr( strippedURL, "/cse" ) != NULL ||
        strstr( strippedURL, "/products" ) != NULL ||
        strstr( strippedURL, "/images" ) != NULL ||
        strstr( strippedURL, "/custom" ) != NULL) )
   {
      char * safe;
      /* search for 'safe=off' and replace by 'safe=active' */
      safe = strstr( originalURL, "&safe=off" );
      if (safe != NULL)
      {
         safe += 6;
	 *safe++ = 'a';		/* 'o' */
	 *safe++ = 'c';		/* 'f' */
	 *safe++ = 't';		/* 'f' */
	 (void) memmove( safe+3, safe, strlen(safe)+1 );
	 *safe++ = 'i';
	 *safe++ = 'v';
	 *safe   = 'e';
      }
      strcat( originalURL, "&safe=active&safeui=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "webmenu.com" ) != NULL  &&		/* SAFESEARCH: webmenu.com */
       (strstr( strippedURL, "q_or=") != NULL  ||
        strstr( strippedURL, "q_and=") != NULL  ||
        strstr( strippedURL, "ss=") != NULL  ||
        strstr( strippedURL, "keyword=") != NULL  ||
	strstr( strippedURL, "query=") != NULL) )
   {
      char * p;
      /* TODO: fix problem of cookie override; a user can set preferences to turn the filter OFF
       * in the user preferences.
       */
      while ((p = strstr( originalURL, "&ss=n" )) != NULL)
         *(p+4) = 'y';
      strcat( originalURL, "&ss=y" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "blekko.com" ) != NULL &&		/* SAFESEARCH: blekko.com */
       strncmp( strippedURL, "/ws/", 4 ) == 0)
   {
      if (strchr( strippedURL, '?' ) == NULL)
	 strcat( originalURL, "?safesearch=2" );
      else
	 strcat( originalURL, "&safesearch=2" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "izito." ) != NULL  &&			/* SAFESEARCH: izito.* */
       (strstr( strippedURL, "query=" ) != NULL  ||
        strstr( strippedURL, "q=" ) != NULL))
   {
      strcat( originalURL, "&ss=y" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "zapmeta." ) != NULL  &&			/* SAFESEARCH: zapmeta.* */
       strstr( strippedURL, "vid=" ) != NULL  &&
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&ss=y" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "bing.com" ) != NULL  &&			/* SAFESEARCH: bing.com */
       strstr( strippedURL, "q=" ) != NULL)    			/* bing */
   {
      strcat( originalURL, "&ADLT=STRICT&filt=all" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "bing.co.uk" ) != NULL  &&		/* SAFESEARCH: bing.co.uk */
       strstr( strippedURL, "q=" ) != NULL)    			/* bing */
   {
      strcat( originalURL, "&ADLT=STRICT&filt=all" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "api.bing.net" ) == 0  &&		/* Safesearch: bing API */
       strncmp( strippedURL, "/json.aspx", 10 ) == 0  &&	/* called by searchgby.com */
       strstr( strippedURL, "query=" ) != NULL)
   {
      strcat( originalURL, "&Adult=Strict" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "search.searchcompletion.com" ) == 0  &&		/* SAFESEARCH: searchcompletion.com */
       strncmp( strippedURL, "/localsearchresults.aspx", 10 ) == 0  &&		/* search.searchcompletion.com/LocalSearchResults.aspx */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&safe=on" );			/* TODO: fix this */
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "pageset.com" ) != NULL  &&		/* pageset.com */
       strstr( strippedURL, "q=" ) != NULL)
   {
      char * t;
      t = strstr( strippedURL, "adt=1" );
      if (t != NULL)
         *(t+4) = '0';
      else
	 strcat( originalURL, "&adt=0" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "trovator.com" ) != NULL  &&		/* searchcompletion.com trovator.com */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&fil=si" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, ".yauba.com" ) != NULL  &&		/* SAFESEARCH: yauba.com */
       strstr( strippedURL, "query=") != NULL)
   {
      strcat( originalURL, "&ss=y" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "forestle.org" ) != NULL  &&		/* SAFESEARCH: forestle.org */
       (strstr( strippedURL, "settings") != NULL  ||
        strstr( strippedURL, "q=") != NULL))
   {
      strcat( originalURL, "&adultfilter=noadult" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "zombol.com" ) != NULL  &&		/* SAFESEARCH: zombol.com */
       strstr( strippedURL, "/results") != NULL  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "kalooga.com" ) != NULL  &&		/* SAFESEARCH: kalooga.com */
       strstr( strippedURL, "search") != NULL  &&
       strstr( strippedURL, "query=") != NULL)
   {
      strcat( originalURL, "&filter=default" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "muuler.com" ) != NULL  &&		/* SAFESEARCH: muuler.com */
       strstr( strippedURL, "/result") != NULL  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "foozir.com" ) != NULL  &&		/* SAFESEARCH: foozir.com */
       strstr( strippedURL, "/result") != NULL  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "moons.it" ) != NULL  &&			/* SAFESEARCH: moons.it */
       strstr( strippedURL, "/ricerca") != NULL  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "wotbox.com" ) != NULL  &&		/* SAFESEARCH: wotbox.com */
       (strstr( strippedURL, "q=") != NULL  ||
        strstr( strippedURL, "op0=") != NULL) )
   {
      strcat( originalURL, "&a=true" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "ripple.org" ) != NULL  &&		/* SAFESEARCH: ripple.org */
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "ant.com" ) != NULL  &&			/* SAFESEARCH: ant.com */
       strstr( strippedURL, "antq=") != NULL)
   {
      strcat( originalURL, "&safe=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((strstr( domain, "duck.co" ) != NULL ||			/* SAFESEARCH: duck.co */
        strstr( domain, "duckduckgo.com" ) != NULL)  &&         /* SAFESEARCH: duckduckgo.com  */
       strncmp( strippedURL, "/d.js", 5 ) == 0  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&p=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "duckduckgo.org" ) != NULL  &&		/* SAFESEARCH: duckduckgo.org */
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&kp=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "zoower.com" ) != NULL  &&		/* SAFESEARCH: zoower.com */
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((strstr( domain, "qbyrd.com" ) != NULL  ||  		/* SAFESEARCH: qbyrd.com */
        strstr( domain, "search-results.com" ) != NULL)  &&	/* SAFESEARCH: search-results.com */
       strstr( strippedURL, "q=") != NULL)
   {
      char * adt;
      adt = strstr( originalURL, "adt=1" );
      if (adt != NULL)
         *(adt+4) = '0';
      else
	 strcat( originalURL, "&adt=0" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "easysearch.org.uk" ) != NULL  &&	/* SAFESEARCH: easysearch.org.uk */
       strstr( strippedURL, "search") != NULL)
   {
      strcat( originalURL, "&safe=on" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "dly.net" ) != NULL  &&			/* SAFESEARCH: dly.net */
       (strstr( strippedURL, "/search?") != NULL  ||  strstr( strippedURL, "/custom?") != NULL)  &&
       strstr( strippedURL, "q=") != NULL)
   {
      strcat( originalURL, "&safe=active" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "ask.com" ) != NULL  &&
       strchr( strippedURL, '?' ) != NULL)    			/* SAFESEARCH: ask.com */
   {
      strcat( originalURL, "&adt=0" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "api.search.yahoo.", 17 ) == 0  &&	/* Safesearch: API yahoo.* */
       strstr( strippedURL, "query=" ) != NULL)
   {
      strcat( originalURL, "&adult_ok=0" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((strcmp( domain, "search.aol.com" ) == 0  ||
        strstr( domain, ".aolsearch.com" ) != NULL)  &&		/* Safesearch: AOL */
       strncmp( strippedURL, "/search", 7 ) == 0  &&
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&safesearch=1&sp_ss=1" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if ((strstr( domain, ".terra." ) != NULL  &&  		/* SAFESEARCH: terra.* */
        strstr( domain, "busca" ) != NULL)  &&
       (strstr( strippedURL, "query=" ) != NULL  ||  
        strstr( strippedURL, "source=" ) != NULL) )	  /* .ar .br .cl .co .ec .es */
   {
      strcat( originalURL, "&npl=%26safe%3dhigh" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "search.alot.com" ) == 0  &&		/* SAFESEARCH: alot.com */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&f=1" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "searchalot.com" ) != NULL  &&		/* SAFESEARCH: searchalot.com */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&safesearch=high" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "alltheinternet.com" ) != NULL  &&	/* SAFESEARCH: alltheinternet.com */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&safesearch=high" );				
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "search.yahoo." ) != NULL  &&		/* SAFESEARCH: yahoo.* */
       strstr( strippedURL, "p=" ) != NULL)
   {
      strcat( originalURL, "&vm=r" );				
      /* TODO: investigate http://www.yahoo.com/r/sx/ *-http://search.yahoo.com/search */
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "excite." ) != NULL  &&			/* SAFESEARCH: excite.* */
       strstr( strippedURL, "search" ) != NULL  &&
       strchr( strippedURL, '?' ) != NULL)  			/* Excite */
   {
      strcat( originalURL, "&familyfilter=1&splash=filtered" );
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "search.msn.", 11 ) == 0)		/* SAFESEARCH: msn.* */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&adlt=strict" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "search.live.", 12 ) == 0  &&		/* SAFESEARCH: live.* */
       strstr( strippedURL, "q=" ) != NULL)
   {
      strcat( originalURL, "&adlt=strict" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "api.search.live.net" ) == 0  &&		/* Safesearch: live API */
       strstr( strippedURL, "sources=" ) != NULL)
   {
      strcat( originalURL, "&adlt=strict" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "yauba.co.in" ) != NULL  &&		/* SAFESEARCH: yauba.co.in */
       strstr( strippedURL, "query=" ) != NULL)
   {
      strcat( originalURL, "&ss=y" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "blinkx.com" ) != NULL  &&		/* SAFESEARCH: blinkx.com */
       strchr( strippedURL, '?' ) != NULL)
   {
      strcat( originalURL, "&safefilter=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "busca.ya.", 9 ) == 0  &&		/* SAFESEARCH: ya.* */
       strstr( strippedURL, "buscar=" ) != NULL)
   {
      strcat( originalURL, "&filtrofamiliar=Activado&safe=active" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "search.lycos.", 13 ) == 0)		/* SAFESEARCH: lycos.* */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&contentFilter=strict&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "suche.lycos.", 12 ) == 0)		/* Lycos .de .at  .ch */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "buscador.lycos.es" ) == 0)		/* Lycos .es */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "vachercher.lycos.fr" ) == 0)		/* Lycos .fr */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "cerca.lycos.it" ) == 0)			/* Lycos .it */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "webpile.it" ) != NULL  &&		/* webpile.it */
       strncmp( strippedURL, "search", 6 ) == 0)
   {
      strcat( originalURL, "&filtro=4" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "alltheweb.com" ) == 0)			/* SAFESEARCH: alltheweb.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&copt_offensive=on&nooc=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "dogpile.com" ) != NULL  ||		/* SAFESEARCH: dogpile.com */
       strstr( domain, "dogpile.co.uk" ) != NULL)		/* SAFESEARCH: dogpile.co.uk  */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&adultfilter=heavy" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "a9.com" ) == 0)				/* SAFESEARCH: a9.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&qsafe=high" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strcmp( domain, "hotbot.com" ) == 0)			/* SAFESEARCH: hotbot.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&adf=on&family=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "infospace.com" ) != NULL)		/* SAFESEARCH: infospace.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "metacrawler.com" ) != NULL)		/* SAFESEARCH: metacrawler.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "metaspy.com" ) != NULL)			/* SAFESEARCH: metaspy.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "webfetch.com" ) != NULL  ||		/* SAFESEARCH: webfetch.com */
       strstr( domain, "webfetch.co.uk" ) != NULL)		/* SAFESEARCH: webfetch.co.uk */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "webcrawler.com" ) != NULL)		/* SAFESEARCH: webcrawler.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "buscamundo.com" ) != NULL  &&		/* SAFESEARCH: buscamundo.com */
       strstr( strippedURL, "qu=") != NULL)
   {
      strcat( originalURL, "&filter=on" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strncmp( domain, "search", 6 ) == 0  &&
       strstr( domain, "foxnews.com" ) != NULL)			/* Safesearch: foxnews.com */
   {
      if (slash == NULL)
         strcat( originalURL, "/" );
      strcat( originalURL, "&familyfilter=1" );
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }
   else
   if (strstr( domain, "altavista.com" ) != NULL  &&		/* SAFESEARCH: altavista.com */
       (strstr( strippedURL, "q=" ) != NULL  ||  strstr( strippedURL, "aqa=" ) != NULL))
   {
      /* Altavista redirects to Yahoo */
      char * dis;
      dis = strstr( strippedURL, "dis=1" );
      if (dis != NULL)						/* replace dis=1 by dis=0 */
         *(dis+4) = '0';
      else
	 strcat( originalURL, "&dis=0" );				/* OR add "dis=0" */
      UFDB_API_num_safesearch++;
      return UFDB_API_MODIFIED_FOR_SAFESEARCH;
   }

   return UFDB_API_OK;
}


static __inline__ int squeeze_html_char( 
   char * p,  
   int *  hex )
{
   int    length;

   length = 0;
   *hex = 0;
   while (*p != '\0'  &&  isxdigit( (int) *p ))
   {
      int h;
      h = (*p <= '9') ? *p - '0' : *p - 'a' + 10;
      *hex = *hex * 16 + h;
      p++;
      length++;
   }

#if 0
   fprintf( stderr, "   squeeze_html_char hex=%04x  length=%d  *p=%c\n", *hex, length, *p );
#endif

   if (*p != ';')
      return -1;		/* '&#xxx' without trailing ';' is not a valid HTML character */

   if (*hex == 0)
      return length;

   if (*hex < 0x0020)
   {
      if (*hex != '\t'  &&  *hex != '\n'  &&  *hex != '\r'  &&  *hex != '\f')
	 *hex = ' ';
   }
   else if (*hex == 0x007f  ||  *hex >= 0x00ff)
   {
      *hex = ' ';
   }
   else if (*hex <= 'Z'  &&  *hex >= 'A')
   {
      *hex += 'a' - 'A';
   }

   return length;
}


__inline__ static char * findDomainEnd( char * url )
{
   while (*url != '\0')
   {
      if (*url == '/'  ||  *url == '?'  ||  *url == '&'  ||  *url == ';'  ||  *url == '#')
         return url;
      url++;
   }

   return url;
}


__inline__ static char * strchr_before( char * str, char * maxstr, char chr )
{
   return (char *) memchr( str, chr, maxstr - str );
}


__inline__ static char * findProtocolEnd( char * URL )
{
   {
      URL++;    /* protocol name must have at least 1 character */

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
      URL++;

      if (*URL == ':'  &&  *(URL+1) == '/'  &&  *(URL+2) == '/')
         return URL;
   }

   return NULL;
}


/*
 * strip a URL:
 * remove http:// prefix, 
 * remove www[0-9*]. prefix,
 * remove port number, 
 * remove username and password,
 * remove IP address obfuscations (numbers with leading zeroes)
 * convert hex codes (%61 = 'a') to characters,
 * convert HTML character codes (&#61; = 'a') to characters,
 * convert special characters to void or space,
 * convert characters to lower case.
 * substitute // by / in a URL
 * substitute /./ by / in a URL
 * substitute /foo/../bar by /bar in a URL
 */
void UFDBstripURL2( 
   char * URL, 			/* input URL string */
   int    stripwwwprefix,	/* input flag for stripping "www." prefix from URL */
   char * strippedUrl,  	/* output char array (must be UFDB_MAX_URL_LENGTH bytes) */
   char * domain,       	/* output char array (must be 1024 bytes) */
   char * protocol,		/* output char array (must be 16 bytes) */
   int  * portnumber )		/* output integer */
{
   char * up;
   char * p;
   char * tmp;
   char * domain_start;
   char * domain_end;
   char * optional_token;
   char * origStrippedUrl;
   int    is_ip_address;
   int    is_ipv6;
   int    obfuscated;
   char   buffer[UFDB_MAX_URL_LENGTH];

   *portnumber = 80;
   is_ipv6 = 0;

   UFDB_API_num_url_lookups++;

   /* strip http: and ftp: protocol header */
   p = findProtocolEnd( URL );
   if (p != NULL)
   {
      int n;
      n = p - URL;
      if (n == 0  ||  n > 14)
      {
	 /* WHOEHA a very large protocol name. It cannot be true. The URL does not start with a protocol. 
	  * skip it!
	  */
	 strcpy( protocol, "http" );
	 p = URL;
      }
      else
      {
	 memcpy( protocol, URL, n );
	 protocol[n] = '\0';
	 if (n == 5  &&  strcasecmp( protocol, "https" ) == 0)
	    *portnumber = 443;
	 p += 3;
      }
   }
   else 
   {
      p = URL;
      strcpy( protocol, "http" );
   }

   domain_end = findDomainEnd( p );				/* might not be accurate and skipped the ':port' */

   optional_token = strchr_before( p, domain_end, '@' );	/* strip user:password@ */
   if (optional_token != NULL)
      p = optional_token + 1;

   domain_start = p;

#if 0
   if (UFDBglobalDebug > 1)
      ufdbLogMessage( "   UFDBstripURL2: p: %s\n", p );
#endif

   if (*p == '[')			/* IPv6 URL: http://[::1]:80/index.html */
   {
      char * end;
      char * oldBracket;

      is_ipv6 = 1;
      oldBracket = strchr( p, ']' );
      if (oldBracket != NULL)
         *oldBracket = '\0';
      end = UFDBparseIPv6address( p, domain );
      if (oldBracket != NULL)
         *oldBracket = ']';
      if (end != NULL)
      {
	 UFDBupdateURLwithNormalisedDomain( p, domain );
	 /* uh-oh: the normalised domain is usually smaller and our pointers have moved */
	 domain_end = findDomainEnd( p );
	 oldBracket = strchr( p, ']' );
	 if (oldBracket == NULL)
	    oldBracket = domain_end - 1;

	 optional_token = strchr_before( oldBracket, domain_end, ':' );
#if 0
	 if (UFDBglobalDebug > 1)
	    ufdbLogMessage( "    UFDBstripURL2:  domain_end: %08x oldBracket: %08x  token: %08x\n", 
		     domain_end, oldBracket, optional_token );
#endif
      }
      else
	 optional_token = NULL;
   }
   else
   {
      if (stripwwwprefix)					    /* strip www[0-9]{0,2}. */
      {
	 if ((p[0] == 'w' || p[0] == 'W')  &&
             (p[1] == 'w' || p[1] == 'W')  &&
             (p[2] == 'w' || p[2] == 'W'))
	 {
	    tmp = p + 3;
#if 1
	    if (*tmp <= '9' && *tmp >= '0')
	       tmp++;
	    if (*tmp <= '9' && *tmp >= '0')
	       tmp++;
#endif
	    if (*tmp == '.'  &&  strchr_before( tmp+1, domain_end, '.' ) != NULL)
	    {
#if 0
	       if (UFDBglobalDebug > 1)
		  ufdbLogMessage( "    UFDBstripURL2: www stripped p '%s'  p %08x  tmp %08x  domain_end %08x", 
			          p, p, tmp, domain_end );
#endif
	       p = tmp + 1;
            }
	 }
      }
      optional_token = strchr_before( p, domain_end, ':' );
   }

   						/* parse&strip :<portnum> */
   if (optional_token != NULL)
   {
      tmp = buffer;				/* copy domain name */
      while (p < optional_token)
         *tmp++ = *p++;
      *tmp = '\0';

      p++;					/* parse :<portnum> */
      *portnumber = 0;
      while (*p <= '9' && *p >= '0')
      {
	 *portnumber = *portnumber * 10 + (*p - '0');
         p++;
      }

      memccpy( tmp, p, '\0', UFDB_MAX_URL_LENGTH-16-6-1 );	/* copy rest of the URL */
   }
   else
   {
      memccpy( buffer, p, '\0', UFDB_MAX_URL_LENGTH-16-1 );
   }
   buffer[UFDB_MAX_URL_LENGTH-1] = '\0';	/* maximise the length of the URL */

   if (!is_ipv6) 				/* save the original domainname */
   {
      int n;

      if (optional_token != NULL)
	 domain_end = optional_token;
      n = domain_end - domain_start;
      memcpy( domain, domain_start, n );
      domain[n] = '\0';
   }

   /*
    * Now a temporary URL is in the buffer.
    * The temporary URL has no protocol, portnum, username/password.
    */
   up = buffer;
   while (*up != '\0')				/* convert URL to lower case */
   {
      if (*up <= 'Z'  &&  *up >= 'A')
	 *up += 'a' - 'A';
      up++;
   }
   *up++ = '\0';				/* prevent problems with % at end of URL */
   *up = '\0';
   
   /* scan for IP address obfuscations */
   obfuscated = (buffer[0] == '0');
   is_ip_address = 1;
   for (tmp = buffer;  *tmp != '\0' && *tmp != '/';  tmp++)
   {
      if (*tmp != '.'  &&  !(*tmp >= '0'  && *tmp <= '9'))
      {
         is_ip_address = 0;
	 break;
      }
      if (*tmp == '.'  &&  *(tmp+1) == '0')
         obfuscated = 1;
   }
   if (is_ip_address  &&  obfuscated)
   {
      char * d;
      char * s;

      /* rewrite the URL to remove the obfuscation */
      d = s = buffer;
      /* remove obfuscating leading zeroes */
      /* leading zeroes in parts make the number octal! */
      /* leading 0x in parts make the number hexadecimal! */
      while (*s == '0'  &&  *(s+1) != '.'  &&  *(s+1) != '/'  &&  *(s+1) != '\0')
         s++;
      while (*s != '\0'  &&  *s != '/')
      {
         if (*s == '.'  &&  *(s+1) == '0')
	 {
	    *d++ = '.';
	    s++;
	    /* remove obfuscating zeroes */
	    while (*s == '0'  &&  *(s+1) != '.'  &&  *(s+1) != '/'  &&  *(s+1) != '\0')
	       s++;
	 }
	 else
	 {
	    *d = *s;
	    d++;
	    s++;
	 }
      }
      /* copy the URI */
      while (*s != '\0')
      {
         *d = *s;
	 d++;
	 s++;
      }
      *d = '\0';
   }

   /*
    *  Copy the buffer to strippedUrl, while converting hex codes to characters.
    */
   origStrippedUrl = strippedUrl;
   p = buffer;
   while (*p != '\0')
   {
      if (*p == ':'  &&  *(p+1) == '/'  &&  *(p+2) == '/')		/* do not replace :// by :/  */
      {
         *strippedUrl++ = *p++;
         *strippedUrl++ = *p++;
         *strippedUrl++ = *p++;
      }
      else if (*p == '%')				/* start of a HEX code */
      {
         if (isxdigit(*(p+1)) && isxdigit(*(p+2)))
	 {
	    char   h;
	    int    hex;

	    h = *(p+1);
	    hex  = (h <= '9') ? h - '0' : h - 'a' + 10;
	    hex *= 16;
	    h = *(p+2);
	    hex += (h <= '9') ? h - '0' : h - 'a' + 10;
	    /* be careful with control characters */
	    if (hex < 0x20)
	    {
	       if (hex == 0)
	       {
	          p += 3;
		  continue;
	       }
	       if (hex != '\t'  &&  hex != '\r'  &&  hex != '\n'  &&  hex != '\f')
	          hex = ' ';
	       *strippedUrl++ = hex;
	       p += 3;
	    }
	    else
	    {
	       if (hex <= 'Z'  &&  hex >= 'A')
		  hex += 'a' - 'A';
	       else if (hex == 0x7f  ||  hex == 0xff)
	          hex = ' ';

	       *strippedUrl++ = hex;
	       p += 3;
	    }
	 }
	 else 					/* erroneous code */
	 {
	    *strippedUrl++ = *p++;		/* just copy one character */
	 }
      }
      else if (*p == '&'  &&  *(p+1) == '#')	/* start of HTML character code */
      {
         int  hex;
	 int  length;

	 length = squeeze_html_char( p+2, &hex );
	 if (length >= 0)
	 {
	    if (hex != 0)
	       *strippedUrl++ = hex;
	    p += length + 3;
	 }
	 else					/* not a valid HTML character code */
	 {
	    *strippedUrl++ = *p++;              /* just copy one character */
	 }
      }
      else					/* plain character */
      {
	 while (*p == '/')
	 {
	    if (*(p+1) == '/')					/* substitute // by /    but not in "xxx://" */
	       p++;
	    else if (*(p+1) == '.'  && *(p+2) == '/')		/* substitute /./ by / */
	       p += 2;
	    else if (*(p+1) == '.'  &&  *(p+2) == '.'  &&  *(p+3) == '/')    /* substitute /xxxx/../ by / */
	    {
	       /* try to find the previous directory... */
	       char * tmp;
	       tmp = strippedUrl - 1;
	       while (*tmp != '/'  &&  tmp > origStrippedUrl)
		  tmp--;
	       if (tmp > origStrippedUrl)
	       {
		  strippedUrl = tmp;
		  p += 3;
	       }
	       else
		  break;
	    }
	    else
	       break;
	 }
         *strippedUrl++ = *p++;
      }
   }
   *strippedUrl = '\0';
}


void UFDBstripURL( 
   char * URL, 			/* input URL string */
   char * strippedUrl,  	/* output char array (must be UFDB_MAX_URL_LENGTH bytes) */
   char * domain,       	/* output char array (must be 1024 bytes) */
   char * protocol,		/* output char array (must be 16 bytes) */
   int  * portnumber )		/* output integer */
{
   UFDBstripURL2( URL, 1, strippedUrl, domain, protocol, portnumber );
}


char * UFDBprintable( char * string )
{
   char * p;

   if (string == NULL)
      return "NULL";

   p = string;
   while (*p != '\0')
   {
      if (*p < 32  ||  *p > 126)
         *p = '?';
      p++;
   }

   return string;
}


char * UFDBfgets( 
   char * requestBuffer, 
   int    bufferSize, 
   FILE * fp )
{
   char * b;
   int    ch;
   int    size;

   b = requestBuffer;
   size = 1;

   while ((ch = getc_unlocked(fp)) != EOF)
   {
      *b++ = ch;
      if (ch == '\n')
         goto end;
      if (++size == bufferSize)
         goto end;
   }

   if (b == requestBuffer  &&  (feof(fp) || ferror(fp)))
      return NULL;

end:
   *b = '\0';
   return requestBuffer;
}


/*
 * Setting functions
 */
void ufdbSetting( 
   char * name, 
   char * value )
{
   struct ufdbSetting * sp;

   if (strcmp( name, "administrator" ) == 0)
   {
      char * p;

      while ((p = strchr( value, '?' )) != NULL)
         *p = '_';
      while ((p = strchr( value, '&' )) != NULL)
         *p = '_';
   }

   if (strcmp( name, "port" ) == 0)
   {
      UFDBglobalPortNum = atoi( value );
      ufdbFree( value );
      if (UFDBglobalPortNum <= 0)
      {
         ufdbLogError( "port number must be > 0, using default port %d", UFDB_DAEMON_PORT );
	 UFDBglobalPortNum = UFDB_DAEMON_PORT;
      }
      return;
   }

   if (Setting != NULL)
   {
      if (ufdbSettingFindName(name) != NULL)
      {
         ufdbLogFatalError( "%s: setting %s is defined multiple times in configuration file %s",
		            progname, name, UFDBglobalConfigFile );
	 ufdbFree( value );
         return;
      }
   }

   sp = (struct ufdbSetting *) ufdbMalloc( sizeof(struct ufdbSetting) );
   sp->name = ufdbStrdup( name );
   sp->value = value;
   sp->next = NULL;

   if (Setting == NULL) 
   {
      Setting = sp;
      lastSetting = sp;
   }
   else
   {
      lastSetting->next = sp;
      lastSetting = sp;
   }

   if (strcmp(name,"dbhome") == 0) 
   {
      struct stat dirbuf;

      if (stat( value, &dirbuf ) != 0)
      {
         ufdbLogFatalError( "dbhome: directory does not exist or "
	                    "access rights are insufficient (value is \"%s\")", 
		            value );
      }
      else
      {
         if (!S_ISDIR(dirbuf.st_mode))
	    ufdbLogFatalError( "dbhome: %s is not a directory", value );
      }
   }

   if (strcmp(name,"logdir") == 0) 
   {
      if (UFDBglobalLogDir != NULL)
	 ufdbFree( UFDBglobalLogDir );
      UFDBglobalLogDir = ufdbStrdup( value );
      ufdbSetGlobalErrorLogFile();
   }
}


struct ufdbSetting * ufdbSettingFindName( 
   char * name )
{
   struct ufdbSetting * p;

   for (p = Setting; p != NULL; p = p->next)
   {
      if (strcmp(name,p->name) == 0)
         return p;
   }
   return NULL;
}


char * ufdbSettingGetValue( 
   char * name )
{
   struct ufdbSetting * p;

   p = ufdbSettingFindName( name );
   if (p != NULL)
      return p->value;
   return NULL;
}


void ufdbGetSysInfo( 
   struct utsname * si )
{
   if (uname( si ) < 0)
   {
      strcpy( si->machine, "M?" );
      strcpy( si->release, "R?" );
      strcpy( si->nodename, "unknown" );
      strcpy( si->sysname, "sysname" );
   }
   else
   {
      si->machine[ sizeof(si->machine)-1 ] = '\0';
      si->release[ sizeof(si->release)-1 ] = '\0';
      si->sysname[ sizeof(si->sysname)-1 ] = '\0';
      
      (void) gethostname( si->nodename, sizeof(si->nodename) );
      si->nodename[ sizeof(si->nodename)-1 ] = '\0';
   }
}


long ufdbGetNumCPUs( void ) 
{
   long num_cpus;

#if defined(_SC_NPROCESSORS_ONLN)
   num_cpus = sysconf( _SC_NPROCESSORS_ONLN );

#elif defined(__NR_sched_getaffinity)
   /* sched_setaffinity() is buggy on linux 2.4.x so we use syscall() instead */
   cpu = syscall( __NR_sched_getaffinity, getpid(), 4, &cpu_mask );
   /* printf( "sched_getaffinity returned %d %08lx\n", cpu, cpu_mask ); */
   if (cpu >= 0)
   {
      num_cpus = 0;
      for (cpu = 0; cpu < 32; cpu++)
         if (cpu_mask & (1 << cpu))
            num_cpus++;
      /* printf( "   found %d CPUs in the cpu mask\n", num_cpus ); */
   }
   else
#else
      num_cpus = 0;
#endif

   return num_cpus;
}


char * UFDBfgetsNoNL( char * s, int size, FILE * stream )
{
   char * buf;
   int    ch;

   buf = s;
   while ((ch = getc_unlocked(stream)) != EOF  &&  --size > 0)
   {
      if (ch == '\n'  ||  ch == '\r')
         break;
      *buf++ = ch;
   }
   *buf = '\0';
   if (ch == EOF  &&  buf == s)
      return NULL;

   return s;
}


int UFDBcalcCksum( char * mem, long size )
{
   unsigned int cksum = 17;

   while (--size >= 0)
   {
      cksum = cksum * 13 + ((unsigned int) *mem++) * 3;
   }
   return (int) (cksum % 100000);
}

