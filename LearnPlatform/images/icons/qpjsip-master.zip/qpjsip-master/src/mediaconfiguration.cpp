#include "mediaconfiguration.h"

namespace qpjsua {

MediaConfiguration::MediaConfiguration()
{
}

MediaConfiguration MediaConfiguration::build()
{
    return MediaConfiguration();
}

} // namespace qpjsua
