#ifndef QPJSUA_MEDIACONFIGURATION_H
#define QPJSUA_MEDIACONFIGURATION_H

namespace qpjsua {

class MediaConfiguration
{
public:
    static MediaConfiguration build();

private:
    MediaConfiguration();
};

} // namespace qpjsua

#endif // QPJSUA_MEDIACONFIGURATION_H
