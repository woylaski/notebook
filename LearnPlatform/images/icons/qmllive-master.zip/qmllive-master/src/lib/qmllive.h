#ifndef QMLLIVELIB_H
#define QMLLIVELIB_H

#include "qmllive_global.h"

class QMLLIVESHARED_EXPORT QmlLive
{
public:
    QmlLive();
};

#endif // QMLLIVELIB_H
