#include "qmllive.h"


QmlLive::QmlLive()
{
}
