.pragma library

var counter = 0
