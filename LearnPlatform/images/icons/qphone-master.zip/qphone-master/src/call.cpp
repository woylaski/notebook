#include "call.h"

namespace qphone {

Call::Call(QObject *parent) :
    QObject(parent)
{
}

} // namespace qphone
